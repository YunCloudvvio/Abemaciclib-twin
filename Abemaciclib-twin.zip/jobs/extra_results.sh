#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=01:00:00
#PBS -N abema_extra
#PBS -j oe
cd "${PBS_O_WORKDIR:-.}"
export PYTHONNOUSERSITE=1
${PYTHON:-python} scripts/analysis/extra_results.py
