#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=06:00:00
#PBS -N abema_analysis
#PBS -j oe

# Analysis pipeline in two stages (test-population evaluation in between, jobs/test_eval.sh):
#   qsub -v STAGE=pre,RES=results,OUT=analysis jobs/analysis.sh     cross-check + collect
#   qsub -v STAGE=post,OUT=analysis,NCHUNKS=8,FIG=paper/figures jobs/analysis.sh   merge, metrics, e3, figures
set -e
cd "${PBS_O_WORKDIR:-.}"
PY=${PYTHON:-python}
PYE=${PYTHON:-python}
export NUMBA_NUM_THREADS=32 OMP_NUM_THREADS=1 PYTHONNOUSERSITE=1 TWIN_SCENARIO=base
STAGE=${STAGE:?STAGE=pre or post}; OUT=${OUT:-analysis}; RES=${RES:-results}; FIG=${FIG:-$OUT/figures}
NCHUNKS=${NCHUNKS:-1}; INSTS=${INSTS:-P1 P2 P3 P4}
mkdir -p $OUT $FIG
echo "host $(hostname), nproc $(nproc), stage $STAGE, $(date)"
if [ $STAGE = pre ]; then
  echo "== crosscheck $(date)"; $PY scripts/crosscheck_runs.py $RES 20 > $OUT/crosscheck.txt; tail -2 $OUT/crosscheck.txt
  echo "== collect $(date)"; $PY scripts/analysis/collect.py --res $RES --out $OUT --instances $INSTS
else
  for I in $INSTS; do $PY scripts/analysis/test_eval.py --inst $I --analysis $OUT --merge --nchunks $NCHUNKS; done
  echo "== metrics $(date)"; $PYE scripts/analysis/metrics.py --analysis $OUT --instances $INSTS
  echo "== e3 $(date)"; $PY scripts/analysis/e3.py --inst P1 --analysis $OUT
  echo "== figures $(date)"; $PYE scripts/analysis/figures.py --analysis $OUT --out $FIG --instances $INSTS
fi
echo "== done $(date)"
