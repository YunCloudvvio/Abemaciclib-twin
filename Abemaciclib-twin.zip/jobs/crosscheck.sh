#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=01:00:00
#PBS -N abema_xcheck
#PBS -j oe

# Re-evaluates stored solutions of finished runs directly in Python: qsub -v RES=results jobs/crosscheck.sh
cd "${PBS_O_WORKDIR:-.}"
export NUMBA_NUM_THREADS=$(nproc)
${PYTHON:-python} scripts/crosscheck_runs.py $RES 20 | tee $RES/crosscheck.txt
