#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=06:00:00
#PBS -N abema_calib
#PBS -j oe

# Calibration of the twin. Submit from the repository root:
#   qsub -v STEP=stage12,STRUCTURE=time     jobs/calibrate.sh
#   qsub -v STEP=stage12,STRUCTURE=exposure jobs/calibrate.sh
#   qsub -v STEP=stage3,STRUCTURE=time      jobs/calibrate.sh   (needs calibration/stage12_<structure>.json)
#   qsub -v STEP=verify                     jobs/calibrate.sh   (code verification)
cd "${PBS_O_WORKDIR:-.}"
PY=${PYTHON:-python}
export NUMBA_NUM_THREADS=$(nproc)
echo "host $(hostname), threads $NUMBA_NUM_THREADS, step $STEP, structure $STRUCTURE, $(date)"
case "$STEP" in
  stage12) $PY scripts/calibrate_stage12.py --structure "$STRUCTURE" 2>&1 | tee "calibration/stage12_${STRUCTURE}_log.txt" ;;
  stage3)  $PY scripts/calibrate_stage3.py --toxicity "calibration/stage12_${STRUCTURE}.json" 2>&1 | tee "calibration/stage3_${STRUCTURE}_log.txt" ;;
  submodels) $PY scripts/check_submodels.py --toxicity "calibration/stage12_${STRUCTURE}.json" 2>&1 | tee "calibration/check_submodels_${STRUCTURE}_log.txt" ;;
  sobol)   $PY scripts/sobol_twin.py --structure "$STRUCTURE" 2>&1 | tee "calibration/sobol_${STRUCTURE}_log.txt" ;;
  ensemble) $PY scripts/select_ensemble.py --structure "$STRUCTURE" 2>&1 | tee "calibration/ensemble_${STRUCTURE}_log.txt" ;;
  verify)  $PY scripts/verify_numerics.py 2>&1 | tee calibration/verify_numerics_log.txt ;;
  *) echo "unknown STEP '$STEP'"; exit 1 ;;
esac
echo "done $(date)"
