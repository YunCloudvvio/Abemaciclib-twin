#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=01:00:00
#PBS -N abema_pytest
#PBS -j oe
cd "${PBS_O_WORKDIR:-.}"
export PYTHONNOUSERSITE=1
${PYTHON:-python} -m pytest -q tests 2>&1 | tail -15
