#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=06:00:00
#PBS -N abema_ana_all
#PBS -j oe

# Whole analysis in one job (small result sets): qsub -v RES=...,OUT=... jobs/analysis_all.sh
set -e
cd "${PBS_O_WORKDIR:-.}"
INSTS=${INSTS:-P1 P2 P3 P4}; NCHUNKS=${NCHUNKS:-2}
STAGE=pre RES=$RES OUT=$OUT bash jobs/analysis.sh
for I in $INSTS; do OUT=$OUT INST=$I NCHUNKS=$NCHUNKS C0=0 C1=$((NCHUNKS-1)) bash jobs/test_eval.sh; done
STAGE=post OUT=$OUT NCHUNKS=$NCHUNKS bash jobs/analysis.sh
