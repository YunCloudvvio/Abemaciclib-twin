#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=01:00:00
#PBS -N abema_valid
#PBS -j oe
cd "${PBS_O_WORKDIR:-.}"
export PYTHONNOUSERSITE=1 NUMBA_NUM_THREADS=32 OMP_NUM_THREADS=1 TWIN_SCENARIO=base
${PYTHON:-python} scripts/analysis/validation.py
