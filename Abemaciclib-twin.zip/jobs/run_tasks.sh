#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=06:00:00
#PBS -N abema_runs
#PBS -j oe

# Runs lines FIRST..LAST of TASKS (1-based), 32 at a time on one socket. Finished runs are skipped.
#   qsub -v TASKS=results/tasks.txt,FIRST=1,LAST=64 jobs/run_tasks.sh
cd "${PBS_O_WORKDIR:-.}"
echo "host $(hostname), lines $FIRST-$LAST of $TASKS, FES ${FES:-10000}, $(date)"
sed -n "${FIRST},${LAST}p" $TASKS | xargs -P ${NPAR:-32} -L 1 scripts/run_one.sh
echo "done $(date)"
