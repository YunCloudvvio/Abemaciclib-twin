#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=06:00:00
#PBS -N abema_teval
#PBS -j oe

# Test-population evaluation, chunks C0..C1 of NCHUNKS for one instance (after collect):
#   qsub -v OUT=analysis,INST=P1,NCHUNKS=8,C0=0,C1=3[,STRUCT=time][,SCEN=base] jobs/test_eval.sh
# Chunks of one job run one after another with all cores of the socket.
set -e
cd "${PBS_O_WORKDIR:-.}"
PY=${PYTHON:-python}
export NUMBA_NUM_THREADS=32 OMP_NUM_THREADS=1 PYTHONNOUSERSITE=1 TWIN_SCENARIO=${SCEN:-base}
echo "host $(hostname), nproc $(nproc), numba threads $NUMBA_NUM_THREADS, $INST chunks $C0-$C1 of $NCHUNKS, $(date)"
for c in $(seq $C0 $C1); do
  $PY scripts/analysis/test_eval.py --inst $INST --structure ${STRUCT:-time} --analysis $OUT --chunk $c --nchunks $NCHUNKS
done
echo "done $(date)"
