#!/bin/bash
#PBS -l select=1:ncpus=32
#PBS -l walltime=12:00:00
#PBS -N abema_e4ana
#PBS -j oe

# E4 post-processing, one scenario after another: qsub -v SCENS="eff_low_tol_low ..." jobs/e4_analysis.sh
# For every scenario: collect -> test population (same scenario) -> metrics -> e3, in analysis_e4/<scenario>.
set -e
cd "${PBS_O_WORKDIR:-.}"
PY=${PYTHON:-python}
PYE=${PYTHON:-python}
export NUMBA_NUM_THREADS=32 OMP_NUM_THREADS=1 PYTHONNOUSERSITE=1
for S in $SCENS; do
  if [ "$S" = exposure ]; then export TWIN_SCENARIO=base; ST=exposure; else export TWIN_SCENARIO=$S; ST=time; fi
  OUT=analysis_e4/$S; mkdir -p $OUT
  echo "== $S ($ST) $(date)"
  $PY scripts/crosscheck_runs.py results_e4/$S 5 > $OUT/crosscheck.txt; tail -1 $OUT/crosscheck.txt
  $PY scripts/analysis/collect.py --res results_e4/$S --structure $ST --out $OUT --instances P1
  $PY scripts/analysis/test_eval.py --inst P1 --structure $ST --analysis $OUT
  $PY scripts/analysis/test_eval.py --inst P1 --structure $ST --analysis $OUT --merge
  $PYE scripts/analysis/metrics.py --analysis $OUT --instances P1
  $PY scripts/analysis/e3.py --inst P1 --analysis $OUT
done
echo "== done $(date)"
