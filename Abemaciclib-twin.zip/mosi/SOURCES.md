# Sources of the swarm intelligence algorithms

Each folder in `codes/` holds a Python port (`impl.py`) of the MATLAB code published by the authors
of the algorithm. The docstring of each `impl.py` describes the algorithm as implemented in that
code and lists every difference of the port. License files of the original code are kept in the
folders where the original repository provides one.

| Folder | Algorithm | Paper | Original code | Commit |
|---|---|---|---|---|
| `M001_MOGWO` | Multi-objective grey wolf optimizer | Mirjalili et al., Expert Syst. Appl. 2016, doi:10.1016/j.eswa.2015.10.039 | https://github.com/VG-TechCenter/Multi-objective-gray-wolf-optimization-algorithm | `296c535` |
| `M004_MSSA` | Multi-objective salp swarm algorithm | Mirjalili et al., Adv. Eng. Softw. 2017, doi:10.1016/j.advengsoft.2017.07.002 | https://github.com/Natee-Panagant/Comparative-study-of-truss-sizing-optimisation-problems-in-MATLAB (`Algorithms/MSSA.m`) | `0b307e3` |
| `M014_MOAVOA` | Multi-objective artificial vultures optimization algorithm | Khodadadi et al., Neural Comput. Appl. 2022, doi:10.1007/s00521-022-07557-y | https://github.com/inimakhan/MOAVOA | `cd77280` |
| `M103_MOCGO` | Multi-objective chaos game optimization | Khodadadi et al., Neural Comput. Appl. 2023, doi:10.1007/s00521-023-08432-0 | https://github.com/inimakhan/MOCGO | `c251fed` |
| `M105_MOEOSMA` | Multi-objective equilibrium optimizer slime mould algorithm | Luo et al., Struct. Multidiscip. Optim. 2023, doi:10.1007/s00158-023-03568-y | https://github.com/Shihong-Yin/MOEOSMA | `f87d372` |
| `M212_MOGNDO` | Multi-objective generalized normal distribution optimization | Khodadadi et al., Cluster Comput. 2024, doi:10.1007/s10586-024-04467-7 | https://github.com/inimakhan/MOGNDO | `ccb1d01` |
| `M231_MORIME` | Multi-objective RIME algorithm | Pandya et al., Energy Rep. 2024, doi:10.1016/j.egyr.2024.04.016 | https://github.com/kanak02/MORIME | `69cc5f1` |
| `M306_MaOMPA` | Many-objective marine predators algorithm | Mashru et al., Sci. Rep. 2025, doi:10.1038/s41598-025-96901-y | https://github.com/kanak02/MaOMPA | `cb2d529` |
| `M315_MOSRS` | Multi-objective special relativity search | Goodarzimehr et al., PLOS One 2025, doi:10.1371/journal.pone.0328005 | https://github.com/inimakhan/MOSRS | `ffe8524` |
| `M323_C-MOBRO` | Constrained multi-objective battle royale optimization | Alp et al., Cluster Comput. 2025, doi:10.1007/s10586-025-05600-w | https://github.com/Taymazakan/C-MOBRO | `3d1f52f` |
