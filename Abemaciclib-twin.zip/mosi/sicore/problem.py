"""Problem wrappers and runners shared by the swarm intelligence implementations.

Every implementation lives in `mosi/codes/<ID>_<Name>/impl.py` and exposes

    optimize(problem, pop_size, rng, max_iter=None, **params)

* `problem(x)` evaluates one solution (1-D array) and returns a float (SO) or a 1-D array (MO).
  The wrapper counts every call; when `problem.max_fes` calls have been made the next call raises
  `BudgetExhausted`, which the runner catches. Implementations therefore never need their own FE checks.
* `problem.lb`, `problem.ub` are 1-D arrays, `problem.dim` the dimension, `problem.max_fes` the budget
  (may be `inf` when the run is controlled by `max_iter`).
* `rng` is a `numpy.random.Generator`; implementations must draw all randomness from it.
* `max_iter`: the iteration count T used by the original code (schedules such as t/T depend on it).
  When None, the implementation derives T from `problem.max_fes` using its own evaluations per
  iteration (see `iters_from_fes`).
* SO: the result is the best of all evaluated solutions, tracked by the wrapper.
  MO: implementations call `problem.report(X, F)` with their current output set (archive or final
  population) after initialisation and at the end of every iteration; the runner returns the last report.
"""
from __future__ import annotations

import math

import numpy as np


class BudgetExhausted(Exception):
    pass


class SOProblem:
    def __init__(self, f, lb, ub, dim=None, max_fes=math.inf, n_ckpt=0):
        lb, ub = np.asarray(lb, dtype=float), np.asarray(ub, dtype=float)
        if lb.ndim == 0:
            lb, ub = np.full(dim, float(lb)), np.full(dim, float(ub))
        self.f, self.lb, self.ub, self.dim = f, lb, ub, lb.size
        self.max_fes = max_fes
        self.fes = 0
        self.nonfinite = 0      # evaluations at non-finite x or giving a non-finite value
        self.outside = 0        # evaluations at points outside [lb, ub] (informational: some originals do this)
        self.best_f, self.best_x = math.inf, None
        self.ckpt = [int(max_fes * k // n_ckpt) for k in range(1, n_ckpt + 1)] if n_ckpt and math.isfinite(max_fes) else []
        self.curve = []

    def __call__(self, x):
        if self.fes >= self.max_fes:
            raise BudgetExhausted
        x = np.asarray(x, dtype=float)
        y = float(self.f(x))
        self.fes += 1
        if not (np.all(np.isfinite(x)) and math.isfinite(y)):
            self.nonfinite += 1
        if np.any(x < self.lb) or np.any(x > self.ub):
            self.outside += 1
        if y < self.best_f:
            self.best_f, self.best_x = y, x.copy()
        if self.ckpt and self.fes == self.ckpt[len(self.curve)]:
            self.curve.append(self.best_f)
        return y

    def evaluate(self, X):
        return np.array([self(x) for x in X])


class MOProblem:
    def __init__(self, f, lb, ub, n_obj, dim=None, max_fes=math.inf):
        lb, ub = np.asarray(lb, dtype=float), np.asarray(ub, dtype=float)
        if lb.ndim == 0:
            lb, ub = np.full(dim, float(lb)), np.full(dim, float(ub))
        self.f, self.lb, self.ub, self.dim, self.n_obj = f, lb, ub, lb.size, n_obj
        self.max_fes = max_fes
        self.fes = 0
        self.nonfinite = 0
        self.outside = 0
        self.out_X = self.out_F = None

    def __call__(self, x):
        if self.fes >= self.max_fes:
            raise BudgetExhausted
        x = np.asarray(x, dtype=float)
        y = np.asarray(self.f(x), dtype=float)
        self.fes += 1
        if not (np.all(np.isfinite(x)) and np.all(np.isfinite(y))):
            self.nonfinite += 1
        if np.any(x < self.lb) or np.any(x > self.ub):
            self.outside += 1
        return y

    def evaluate(self, X):
        return np.array([self(x) for x in X])

    def report(self, X, F):
        self.out_X, self.out_F = np.array(X, dtype=float, copy=True), np.array(F, dtype=float, copy=True)


def iters_from_fes(problem, evals_per_iter, init_evals):
    """Largest T such that init_evals + T * evals_per_iter <= max_fes (at least 1)."""
    if not math.isfinite(problem.max_fes):
        raise ValueError("max_iter is required when max_fes is infinite")
    return max(1, int((problem.max_fes - init_evals) // evals_per_iter))


def run_so(optimize, problem, seed, pop_size=30, max_iter=None, **params):
    rng = np.random.default_rng(seed)
    try:
        optimize(problem, pop_size=pop_size, rng=rng, max_iter=max_iter, **params)
    except BudgetExhausted:
        pass
    return {"best_f": problem.best_f, "best_x": problem.best_x, "fes": problem.fes, "curve": list(problem.curve),
            "nonfinite": problem.nonfinite, "outside": problem.outside}


def run_mo(optimize, problem, seed, pop_size=100, max_iter=None, **params):
    rng = np.random.default_rng(seed)
    try:
        optimize(problem, pop_size=pop_size, rng=rng, max_iter=max_iter, **params)
    except BudgetExhausted:
        pass
    return {"X": problem.out_X, "F": problem.out_F, "fes": problem.fes,
            "nonfinite": problem.nonfinite, "outside": problem.outside}
