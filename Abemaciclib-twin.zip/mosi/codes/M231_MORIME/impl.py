"""Multi-objective RIME algorithm (MORIME).

Pandya, S. B., Kalita, K., Jangir, P., Cep, R., Migdady, H., Chohan, J. S., Abualigah, L., Mallik, S.
Multi-objective RIME algorithm-based techno economic analysis for security constraints load dispatch and power
flow including uncertainties model of hybrid power systems. Energy Reports 11 (2024) 4423-4451.
doi:10.1016/j.egyr.2024.04.016

Reference: the authors' MATLAB code (github.com/kanak02/MORIME, v1.0 "NDS+CD"): MORIME.m (script),
initialization.m, NonDominatedSorting.m, CrowdingDistance.m, UpdateArchiveUsingNSGAII.m, dominates.m.
Line-by-line port of the authors' MATLAB code.

Evaluations: 2*N per iteration, none before the loop -> 2*N*T (N=100, T=100: 20000). Each individual is
evaluated at the start of its update (at its old position, i.e. a repeat of the previous iteration's
evaluation) and the whole population is evaluated again after the update.

Quirks of the original reproduced on purpose:
- Best_rime = zeros(dim, 1) is never updated, so every "soft-rime" move is Best_rime(j) + RimeFactor*((ub-lb)*rand
  + lb) = RimeFactor*((ub-lb)*rand + lb), and every "hard-rime puncture" sets x_j = 0 (then clipped to [lb, ub]).
  The search is therefore pulled to the origin (an origin-biased method; it happens to be the optimum of x_2..x_n
  for ZDT1-4).
- The puncture probability normalized_rime_rates(i) is a linear index into normr(Rime_rates): element (i, 1) =
  f1_i / ||F_i|| of the objective vector just evaluated at the individual's old position (normr: zero row ->
  1/sqrt(M)).
- RimeFactor = (rand-0.5)*2*cos(pi*t/(T/10))*(1 - round(t*W/T)/W) with MATLAB round (half away from zero), W = 5;
  E = sqrt(t/T); one RimeFactor per iteration.
- The original uses ArchiveMaxSize for BOTH the population size and the archive size. Here pop_size is the
  population and archive_size the archive cap (default: archive_size = pop_size, i.e. the original).
- The archive is an NSGA-II truncation of (population + archive) (NonDominatedSorting.m / CrowdingDistance.m /
  UpdateArchiveUsingNSGAII.m, identical to the MOEDO package): it always holds min(A, N + |archive|) solutions,
  dominated fronts included. Crowding distance is normalised by max-min over the whole combined set; fronts with
  <= 2 members get inf; front members are ordered by MATLAB's stable sort(-distance) (NaN last).
- No solution is evaluated before the first iteration, so report() is first called after iteration 1.
Random numbers: per individual the r1, soft-rime and r2 draws are made as arrays of length dim (the soft-rime
number is drawn for every component and used where r1 < E); same distribution as the original's scalar draws.
"""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
from sicore.problem import iters_from_fes  # noqa: E402


# --- ports of the package's archive routines (same code as the MOEDO package; logic copied from
#     MOSI/codes/_mohelpers_b, kept local so this folder is self-contained) --------------------------------
def _dom_matrix(F):
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    return le & lt


def nd_sort_deb(F):
    """NonDominatedSorting.m: list of fronts (0-based), front 1 in index order, later fronts in discovery order."""
    F = np.asarray(F, dtype=float)
    n = len(F)
    D = _dom_matrix(F)
    cnt = D.sum(axis=0).astype(int)
    S = [np.flatnonzero(D[i]) for i in range(n)]
    cur = [i for i in range(n) if cnt[i] == 0]
    fronts = []
    while cur:
        fronts.append(np.array(cur, dtype=int))
        Q = []
        for i in cur:
            for j in S[i]:
                cnt[j] -= 1
                if cnt[j] == 0:
                    Q.append(j)
        cur = Q
    return fronts


def crowding_distance_global(F, fronts):
    """CrowdingDistance.m: normalisation by max-min of ALL rows; fronts with <= 2 members -> inf."""
    F = np.asarray(F, dtype=float)
    dist = np.zeros(len(F))
    rng_m = F.max(axis=0) - F.min(axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        for front in fronts:
            k = len(front)
            if k > 2:
                dist[front] = 0.0
                for m in range(F.shape[1]):
                    sf = front[np.argsort(F[front, m], kind="stable")]
                    dist[sf[0]] = np.inf
                    dist[sf[-1]] = np.inf
                    for i in range(1, k - 1):
                        dist[sf[i]] = dist[sf[i]] + (F[sf[i + 1], m] - F[sf[i - 1], m]) / rng_m[m]
            else:
                dist[front] = np.inf
    return dist


def _sort_desc_order(x):
    y = -np.asarray(x, dtype=float)
    nan = np.isnan(y)
    idx = np.argsort(np.where(nan, np.inf, y), kind="stable")
    return np.r_[idx[~nan[idx]], idx[nan[idx]]]


def nsgaii_truncate(fronts, dist, size):
    """UpdateArchiveUsingNSGAII.m: fill front by front (each by descending crowding distance), cut the last."""
    out = []
    for front in fronts:
        front = front[_sort_desc_order(dist[front])]
        if len(front) + len(out) <= size:
            out.extend(front.tolist())
        else:
            out.extend(front[: size - len(out)].tolist())
            break
    return np.array(out, dtype=int)


def _mround(x):
    """MATLAB round: half away from zero."""
    return math.copysign(math.floor(abs(x) + 0.5), x)


def optimize(problem, pop_size=100, rng=None, max_iter=None, archive_size=None, W=5):
    N, D, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    A = N if archive_size is None else archive_size
    T = max_iter if max_iter is not None else iters_from_fes(problem, 2 * N, 0)

    best_rime = np.zeros(D)                                   # never updated in the original
    # initialization.m: column by column
    X = np.empty((N, D))
    for j in range(D):
        X[:, j] = rng.random(N) * (ub[j] - lb[j]) + lb[j]
    Arch_X = np.zeros((0, D))
    Arch_F = None
    rates = None

    for it in range(1, T + 1):
        rime_factor = (rng.random() - 0.5) * 2 * math.cos(math.pi * it / (T / 10)) * (1 - _mround(it * W / T) / W)
        E = math.sqrt(it / T)
        for i in range(N):
            fi = np.asarray(problem(X[i]), dtype=float)
            if rates is None:
                rates = np.zeros((N, fi.size))
            rates[i] = fi
            nrm = math.sqrt(float(np.sum(fi ** 2)))
            nr = fi[0] / nrm if nrm != 0 else 1 / math.sqrt(fi.size)   # normr(Rime_rates)(i) = element (i, 1)
            r1 = rng.random(D)
            soft = rng.random(D)
            r2 = rng.random(D)
            x = X[i].copy()
            m1 = r1 < E
            x[m1] = best_rime[m1] + rime_factor * ((ub[m1] - lb[m1]) * soft[m1] + lb[m1])
            m2 = r2 < nr
            x[m2] = best_rime[m2]
            fu, fl = x > ub, x < lb
            X[i] = np.where(fu, ub, np.where(fl, lb, x))
        rates = np.array([problem(x) for x in X], dtype=float)
        if Arch_F is None:
            Arch_F = np.zeros((0, rates.shape[1]))
        Comb_X = np.r_[X, Arch_X]
        Comb_F = np.r_[rates, Arch_F]
        fronts = nd_sort_deb(Comb_F)
        dist = crowding_distance_global(Comb_F, fronts)
        sel = nsgaii_truncate(fronts, dist, A)
        Arch_X, Arch_F = Comb_X[sel], Comb_F[sel]
        problem.report(Arch_X, Arch_F)
    return Arch_X, Arch_F
