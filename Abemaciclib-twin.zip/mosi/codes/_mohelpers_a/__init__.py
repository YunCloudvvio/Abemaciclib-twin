"""Shared multi-objective helpers for shard IMA (MOSI M001-M015, M101-M125). Owned by shard IMA; other
shards: do not edit.

Import from an impl.py with:
    import os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    from _mohelpers_a import ...

Contents
--------
1. The MOPSO grid repository of Coello Coello et al. as coded by S. M. Kalami Heris (MOPSO v1.0, 2011) and
   reused verbatim by Mirjalili (MOGWO) and Khodadadi et al. (MOCryStAl, MOMGA, MAOA, MOAOS, MOAVOA, MOSPO,
   MOCGO): DetermineDomination(s), GetNonDominatedParticles, CreateHypercubes, GetGridIndex,
   GetOccupiedCells, RouletteWheelSelection, SelectLeader, DeleteFromRep. The helper files of all these
   packages are identical apart from comments (checked with diff).
2. Mirjalili's archive routines of the MOALO/MODA/MSSA/MOMVO/MOGOA family (RankingProcess,
   HandleFullArchive, RouletteWheelSelection with cumsum*rand) are kept inside each impl.py because the
   third-party copies differ slightly between algorithms.

MATLAB randi/randperm/rand draws are replaced by numpy Generator draws with the same distribution.
"""
from __future__ import annotations

import math

import numpy as np


def dom_matrix(F):
    """D[i, j] = True when row i Pareto-dominates row j: all(F_i <= F_j) and any(F_i < F_j)."""
    F = np.asarray(F, dtype=float)
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    return le & lt


def determine_domination(F):
    """Kalami's DetermineDomination(pop): returns the boolean 'Dominated' flags.

    The MATLAB loop (for i, for j<i: if ~pop(j).Dominated: if i dom j -> mark j, elseif j dom i -> mark i,
    break) marks exactly the solutions that are dominated by some other member: it never marks a
    non-dominated solution, and every dominated x is dominated by a non-dominated y that is never marked;
    if y comes before x the loop over j reaches y (or marks x earlier), if y comes after x the (unbroken)
    loop of y reaches x. Hence the vectorised 'dominated by anybody' test is identical. Equal cost vectors
    never dominate each other, so duplicates all stay (as in the original)."""
    F = np.asarray(F, dtype=float)
    if len(F) == 0:
        return np.zeros(0, dtype=bool)
    return dom_matrix(F).any(axis=0)


def create_hypercubes(F, ngrid, alpha):
    """CreateHypercubes(costs, nGrid, alpha) -> list with the 'Upper' vector per objective (Lower unused).
    F has one row per solution (the MATLAB costs matrix is its transpose)."""
    F = np.asarray(F, dtype=float)
    G = []
    for j in range(F.shape[1]):
        mn, mx = F[:, j].min(), F[:, j].max()
        dc = alpha * (mx - mn)
        gx = np.linspace(mn - dc, mx + dc, ngrid - 1)
        G.append(np.r_[gx, np.inf])
    return G


def grid_index(F, G):
    """GetGridIndex for every row of F: SubIndex(j) = find(c(j) < Upper_j, 1, 'first') and
    Index = sub2ind(ngrid*ones(1, nobj), SubIndex) (1-based, first objective fastest)."""
    F = np.atleast_2d(np.asarray(F, dtype=float))
    ngrid = len(G[0])
    idx = np.zeros(len(F), dtype=np.int64)
    for j, U in enumerate(G):
        hit = F[:, j][:, None] < U[None, :]
        if not hit.any(axis=1).all():
            # MATLAB: find(...) is empty for NaN costs -> 'SubIndex(j)=i' errors out
            raise FloatingPointError("GetGridIndex: NaN cost (the original stops with an error)")
        s = np.argmax(hit, axis=1)  # 0-based first hit
        idx += s * ngrid ** j
    return idx + 1


def roulette_wheel(p, rng):
    """RouletteWheelSelection(p): r = rand; i = find(r <= cumsum(p), 1, 'first'). 0-based result."""
    r = rng.random()
    c = np.cumsum(p)
    i = int(np.searchsorted(c, r, side="left"))
    return min(i, len(c) - 1)


def occupied_cells(gidx):
    """GetOccupiedCells: sorted unique cell indices and member counts."""
    occ, cnt = np.unique(np.asarray(gidx), return_counts=True)
    return occ, cnt.astype(float)


def select_leader(gidx, beta, rng):
    """SelectLeader(rep, beta): roulette over occupied cells with p ~ count^-beta, then randi member.
    Returns the 0-based position of the leader in 'rep'."""
    gidx = np.asarray(gidx)
    occ, cnt = occupied_cells(gidx)
    p = cnt ** (-beta)
    p = p / p.sum()
    cell = occ[roulette_wheel(p, rng)]
    members = np.flatnonzero(gidx == cell)
    return int(members[rng.integers(len(members))])


def delete_from_rep(gidx, extra, gamma, rng):
    """DeleteFromRep(rep, EXTRA, gamma): EXTRA times: roulette over occupied cells with p ~ count^gamma,
    remove a uniformly chosen member of that cell. Returns the kept 0-based positions (original order)."""
    keep = np.arange(len(gidx))
    g = np.asarray(gidx).copy()
    for _ in range(extra):
        occ, cnt = occupied_cells(g)
        p = cnt ** gamma
        p = p / p.sum()
        cell = occ[roulette_wheel(p, rng)]
        members = np.flatnonzero(g == cell)
        j = members[rng.integers(len(members))]
        keep = np.delete(keep, j)
        g = np.delete(g, j)
    return keep


class GridArchive:
    """The repository logic shared by MOGWO and the Khodadadi MO codes (main-loop tail):

        pop = DetermineDomination(pop); nd = GetNonDominatedParticles(pop)
        Archive = [Archive; nd]; Archive = DetermineDomination(Archive); Archive = GetNonDominated(Archive)
        for each member: GridIndex = GetGridIndex(member, G)            (G = the CURRENT grid)
        if numel(Archive) > Archive_size: DeleteFromRep(...); G = CreateHypercubes(Archive costs)

    Note the quirk kept: the grid G is rebuilt only at initialisation and after a truncation, and the grid
    indices of the members are recomputed only at the end of the next iteration (so leaders are selected
    with indices that refer to the grid in force before the last truncation)."""

    def __init__(self, X, F, ngrid, alpha, beta, gamma, size, rng):
        self.ngrid, self.alpha, self.beta, self.gamma, self.size, self.rng = ngrid, alpha, beta, gamma, size, rng
        nd = ~determine_domination(F)
        self.X, self.F = np.array(X[nd], dtype=float), np.array(F[nd], dtype=float)
        self.G = create_hypercubes(self.F, ngrid, alpha)
        self.gidx = grid_index(self.F, self.G)

    def leader(self):
        return select_leader(self.gidx, self.beta, self.rng)

    def update(self, PX, PF):
        nd = ~determine_domination(PF)
        X = np.r_[self.X, PX[nd]]
        F = np.r_[self.F, PF[nd]]
        keep = ~determine_domination(F)
        self.X, self.F = X[keep], F[keep]
        self.gidx = grid_index(self.F, self.G)
        n = len(self.F)
        if self.size is not None and n > self.size:
            k = delete_from_rep(self.gidx, n - self.size, self.gamma, self.rng)
            self.X, self.F, self.gidx = self.X[k], self.F[k], self.gidx[k]
            self.G = create_hypercubes(self.F, self.ngrid, self.alpha)


def levy_mantegna(rng, d, beta=1.5):
    """levyFlight(d) of the AVO family: u = randn(1,d)*sigma, v = randn(1,d), u./abs(v).^(1/beta)."""
    sigma = (math.gamma(1 + beta) * math.sin(math.pi * beta / 2)
             / (math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = rng.standard_normal(d) * sigma
    v = rng.standard_normal(d)
    return u / np.abs(v) ** (1 / beta)


def mclip(x, lb, ub):
    """MATLAB min(max(x, lb), ub): NaN components become the bound (MATLAB max/min ignore NaN)."""
    return np.fmin(np.fmax(x, lb), ub)


# ----------------------------------------------------------------------------------------------------------
# Archive routines of the Mirjalili MOALO/MODA/MSSA/MOMVO/MOGOA demos as wrapped by N. Panagant (truss
# sizing studies, 2020): UpdateArchive (unique rows + sequential domination loop), RankingProcess,
# RouletteWheelSelection (rand*cumsum, -1 if none), HandleFullArchive, pbil_selection0 (output filter).
# The wrappers carry a constraint vector G; for unconstrained problems (G = 0) their constrained
# 'dominates' reduces to Pareto dominance and fpenal_1 to the identity, which is what is ported here.
# ----------------------------------------------------------------------------------------------------------
def pg_update_archive(AX, AF, PX, PF):
    """UpdateArchive: [X_temp, uind] = unique([Archive_X; Particles_X], 'rows') (lexicographic order, first
    occurrence), then the sequential loop: for i, for j < i: if F_i ~= F_j (any): i dom j -> o(j)=1,
    elseif j dom i -> o(i)=1, break; else (equal F) o(j)=0 and o(i)=0. Members with o == 0 are kept."""
    X = np.r_[AX, PX]
    F = np.r_[AF, PF]
    _, first = np.unique(X, axis=0, return_index=True)   # sorted unique rows, first occurrence
    X, F = X[first], F[first]
    n = len(F)
    with np.errstate(invalid="ignore"):
        D = dom_matrix(F)
    EQ = np.all(F[:, None, :] == F[None, :, :], axis=2)
    o = np.zeros(n, dtype=bool)
    for i in range(n):
        o[i] = False
        Di, Ei = D[i], EQ[i]
        Dc = D[:, i]
        for j in range(i):
            if not Ei[j]:
                if Di[j]:
                    o[j] = True
                elif Dc[j]:
                    o[i] = True
                    break
            else:
                o[j] = False
                o[i] = False
    return X[~o], F[~o]


def pg_ranking(AF, obj_no):
    """RankingProcess: r = (max-min)/20 per objective (0 if one member); rank_i = #j with
    |F_jk - F_ik| < r_k for k = 1..obj_no."""
    AF = np.asarray(AF, dtype=float)
    if len(AF) == 1:
        r = np.zeros(AF.shape[1])
    else:
        r = (AF.max(axis=0) - AF.min(axis=0)) / 20
    k = obj_no
    close = np.all(np.abs(AF[None, :, :k] - AF[:, None, :k]) < r[:k], axis=2)
    return close.sum(axis=1).astype(float)


def pg_roulette(weights, rng):
    """RouletteWheelSelection(weights): acc = cumsum(w); p = rand*acc(end); first index with acc > p,
    -1 if none (0-based result, -1 kept)."""
    with np.errstate(invalid="ignore", over="ignore"):
        acc = np.cumsum(weights)
        p = rng.random() * acc[-1]
        hit = np.flatnonzero(acc > p)
    return int(hit[0]) if hit.size else -1


def pg_handle_full(AX, AF, ranks, cap, rng):
    """HandleFullArchive: removes size-cap members one by one by roulette on the (not updated) ranks;
    if the roulette fails (-1) the index is ceil(size*rand)."""
    ranks = np.asarray(ranks, dtype=float).copy()
    for _ in range(len(AF) - cap):
        idx = pg_roulette(ranks, rng)
        if idx == -1:
            idx = int(math.ceil(len(AF) * rng.random())) - 1
        AX, AF, ranks = np.delete(AX, idx, 0), np.delete(AF, idx, 0), np.delete(ranks, idx)
    return AX, AF, ranks


def pg_archive_step(AX, AF, PX, PF, cap, obj_no, rng):
    """The common block: UpdateArchive; RankingProcess; HandleFullArchive if full; RankingProcess again.
    Returns (AX, AF, ranks)."""
    AX, AF = pg_update_archive(AX, AF, PX, PF)
    ranks = pg_ranking(AF, obj_no)
    if len(AF) > cap:
        AX, AF, _ = pg_handle_full(AX, AF, ranks, cap, rng)
    ranks = pg_ranking(AF, obj_no)
    return AX, AF, ranks


def pg_select(ranks, rng, inverse):
    """index = RouletteWheelSelection(1./ranks) (inverse) or (ranks); -1 -> first member."""
    with np.errstate(divide="ignore"):
        w = 1.0 / ranks if inverse else ranks
    idx = pg_roulette(w, rng)
    return 0 if idx == -1 else idx


def pg_output(AX, AF):
    """pbil_selection0 on the archive: members not (weakly-Pareto) dominated by another member."""
    keep = ~determine_domination(AF)
    return AX[keep], AF[keep]
