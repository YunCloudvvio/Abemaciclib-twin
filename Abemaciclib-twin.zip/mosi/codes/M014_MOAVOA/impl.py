"""Multi-Objective African Vultures Optimization Algorithm (MOAVOA).

Khodadadi, N., Soleimanian Gharehchopogh, F., Mirjalili, S. MOAVOA: a new multi-objective artificial
vultures optimization algorithm. Neural Computing and Applications 34 (2022) 20791-20829.
DOI: 10.1007/s00521-022-07557-y

Reference source: the authors' MATLAB code (github.com/inimakhan/MOAVOA, MOAVOA.m, exploration.m,
exploitation.m, levyFlight.m, random_select.m, boundaryCheck.m + MOPSO grid helpers). Paper PDF not
available here (Springer, manual download).

Evaluations: N at initialisation + (N+1) per iteration (after the vulture loop the code clips and
evaluates the last vulture once more) -> N + T*(N+1).
Output set (problem.report): the repository (Archive), after initialisation and after every iteration.

Faithful to the code, including its quirks:
- the population X is never updated: every iteration starts each vulture from its INITIAL position
  (current_vulture_X(i).Position = X(i).Position) and the moved vultures are only used for the archive;
- one leader per iteration (SelectLeader, beta=4); a = unifrnd(-2,2)*(sin(pi/2*t/T)^2.5 + cos(pi/2*t/T)-1),
  P1 = (2*rand+1)*(1-t/T) + a, F = P1*(2*rand-1) per vulture;
- random_select(current, Leader, 0.8, 0.2): roulette -> the vulture itself with prob. 0.8, else Leader;
- |F| >= 1: exploration (p1 = 0.6); |F| < 1: exploitation called as exploitation(cur, R, Leader, R, ...)
  so Best_vulture1 = R (the selected vulture), Best_vulture2 = Leader (p2 = 0.4, p3 = 0.6);
  Levy flight (Mantegna, beta = 1.5); all scalar rand() as in the code;
- boundaryCheck: components above ub/below lb are set to the bound;
- MOPSO grid repository with nGrid = 10, alpha = 0.1, beta = 4, gamma = 2.
Deviation: boundaryCheck computes X.*~(FU+FL) + ub.*FU + lb.*FL, which turns an infinite component into
NaN in MATLAB (inf*0); here an infinite component is set to the bound (only reachable through a division
by exactly zero in the exploitation rule, i.e. never in practice).
"""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from _mohelpers_a import GridArchive, levy_mantegna  # noqa: E402

from sicore.problem import iters_from_fes  # noqa: E402


def _bound(x, lb, ub):
    return np.where(x > ub, ub, np.where(x < lb, lb, x))


def optimize(problem, pop_size=100, rng=None, max_iter=None, archive_size=100,
             p1=0.6, p2=0.4, p3=0.6, alpha=0.8, betha=0.2, gamma_=2.5,
             grid_alpha=0.1, n_grid=10, beta=4, gamma=2):
    N, D, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, N + 1, N)

    X0 = lb + (ub - lb) * rng.random((N, D))
    F0 = np.array([problem(x) for x in X0])
    arc = GridArchive(X0, F0, n_grid, grid_alpha, beta, gamma, archive_size, rng)
    problem.report(arc.X, arc.F)

    CX = np.empty((N, D))
    CF = np.empty_like(F0)
    for t in range(1, T + 1):
        L = arc.X[arc.leader()]
        a = rng.uniform(-2, 2) * ((math.sin((math.pi / 2) * (t / T)) ** gamma_) + math.cos((math.pi / 2) * (t / T)) - 1)
        P1 = (2 * rng.random() + 1) * (1 - (t / T)) + a
        for i in range(N):
            cur = X0[i].copy()
            Fv = P1 * (2 * rng.random() - 1)
            R = cur if rng.random() <= alpha else L       # RouletteWheelSelection([alpha betha]) == 1
            if abs(Fv) >= 1:                                        # exploration.m
                if rng.random() < p1:
                    cur = R - (abs(2 * rng.random()) * R - cur) * Fv
                else:
                    cur = (R - Fv + rng.random() * ((ub - lb) * rng.random() + lb))
            else:                                                   # exploitation.m (B1 = R, B2 = Leader)
                if abs(Fv) < 0.5:
                    if rng.random() < p2:
                        with np.errstate(divide="ignore", invalid="ignore"):
                            A = R - ((R * cur) / (R - cur ** 2)) * Fv
                            B = L - ((L * cur) / (L - cur ** 2)) * Fv
                        cur = (A + B) / 2
                    else:
                        cur = R - np.abs(R - cur) * Fv * levy_mantegna(rng, D)
                else:
                    if rng.random() < p3:
                        cur = (abs(2 * rng.random()) * R - cur) * (Fv + rng.random()) - (R - cur)
                    else:
                        s1 = R * (rng.random() * cur / (2 * math.pi)) * np.cos(cur)
                        s2 = R * (rng.random() * cur / (2 * math.pi)) * np.sin(cur)
                        cur = R - (s1 + s2)
            CX[i] = _bound(cur, lb, ub)
            CF[i] = problem(CX[i])
        CX[N - 1] = _bound(CX[N - 1], lb, ub)          # extra clip + evaluation of the last vulture
        CF[N - 1] = problem(CX[N - 1])
        arc.update(CX, CF)
        problem.report(arc.X, arc.F)
    return arc.X, arc.F
