"""MaOMPA - Many-objective Marine Predators Algorithm ("Adaptive predator prey algorithm for many objective
optimization").

Mashru, N., Kalita, K., Cepova, L., Patel, P., Arpita, Jangir, P. Adaptive predator prey algorithm for many
objective optimization. Scientific Reports 15 (2025) 12690. doi:10.1038/s41598-025-96901-y

Reference used: the authors' MATLAB code in this folder (MaOMPA.m, EnvironmentalSelection.m, NDSort.m,
UniformPoint.m, Gaussian_search.m, initialization.m, mompa_levy.m; https://github.com/kanak02/MaOMPA,
commit cb2d529). The code is followed where it differs from the paper.

Evaluations (the original evaluates through the batch function MOFcn, and re-evaluates sets it already knows):
- initialisation: MOFcn(Prey) (pop_size) + MOFcn inside EnvironmentalSelection (pop_size) -> 2 * pop_size;
- per iteration: U = unique rows of [Prey_old; Prey_evo; Prey_fads; Prey_gau] (at most 4N rows, N = number of
  reference points) is evaluated twice (MOFcn in the main loop + inside EnvironmentalSelection), then the
  selected population is evaluated once more (MOFcn(Prey)) -> 2|U| + N, nominal worst case 9N (used for T when
  max_iter is None).
Note N = number of Das-Dennis reference points (UniformPoint(pop_size, M)) replaces pop_size after the first
environmental selection (100 for M=2, 91 for M=3 with pop_size=100), exactly as in the original.

Quirks kept:
- Elite is a uniformly random member of the previous population (not a best solution); it is one row copied
  to all N rows;
- the phase test is `Iter < T/3` / `T/3 < Iter < 2T/3` / else, so Iter == T/3 (when integer) uses phase 3;
- in phase 2 the second half (1-based i > N/2) uses the Brownian rule, the first half the Levy rule;
- FADs (Eq. 16) is applied to the whole population with ONE rand() deciding the branch;
- Gaussian search mutates one random coordinate of every FADs-moved prey by (ub-lb)*N(0,1), then clips;
- unique(...,'rows') sorts the candidate set lexicographically (reproduced with np.unique(axis=0));
- the reported output set is the whole selected population (the original returns `fit` of the population,
  dominated members included); after initialisation the selected population is reported.
Implementation details: element-wise rand/randn draws are taken as (N, D) arrays; Levy steps use the
Mantegna formula of mompa_levy.m.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from _mohelpers_c import levy_mantegna, nsga3_env_selection, uniform_point  # noqa: E402
from sicore.problem import iters_from_fes  # noqa: E402


def _clip(X, lb, ub):
    # (X.*~(Flag4ub+Flag4lb)) + ub.*Flag4ub + lb.*Flag4lb
    return np.where(X > ub, ub, np.where(X < lb, lb, X))


def optimize(problem, pop_size=100, rng=None, max_iter=None, FADs=0.2, P=0.5):
    D, lb, ub, M = problem.dim, problem.lb, problem.ub, problem.n_obj
    Z, N = uniform_point(pop_size, M)
    T = max_iter if max_iter is not None else iters_from_fes(problem, 9 * N, 2 * pop_size)

    # Iter == 0 block
    Prey = rng.random((pop_size, D)) * (ub - lb) + lb          # initialization.m (vector bounds)
    subfit = problem.evaluate(Prey)                            # MOFcn(FUN, Prey, numObj)
    Zmin = subfit.min(axis=0)
    F_es = problem.evaluate(Prey)                              # MOFcn inside EnvironmentalSelection
    sel = nsga3_env_selection(F_es, N, Z, Zmin, rng)
    Prey, Fp = Prey[sel], F_es[sel]
    Prey_old = Prey.copy()
    problem.report(Prey, Fp)

    for it in range(T):
        Elite = np.tile(Prey_old[rng.integers(N)], (N, 1))
        CF = (1 - it / T) ** (2 * it / T)
        RL = 0.05 * levy_mantegna(rng, (N, D), 1.5)
        RB = rng.standard_normal((N, D))
        R = rng.random((N, D))
        if it < T / 3:                                         # Phase 1 (Eq. 12)
            step = RB * (Elite - RB * Prey)
            Prey = Prey + P * R * step
        elif T / 3 < it < 2 * T / 3:                           # Phase 2 (Eqs. 13-14)
            upper = (np.arange(1, N + 1) > N / 2)[:, None]
            step_b = RB * (RB * Elite - Prey)
            step_l = RL * (Elite - RL * Prey)
            Prey = np.where(upper, Elite + P * CF * step_b, Prey + P * R * step_l)
        else:                                                  # Phase 3 (Eq. 15)
            step = RL * (RL * Elite - Prey)
            Prey = Elite + P * CF * step
        Prey = _clip(Prey, lb, ub)
        Prey_evo = Prey.copy()
        if rng.random() < FADs:                                # FADs (Eq. 16)
            U = rng.random((N, D)) < FADs
            Prey = Prey + CF * ((lb + rng.random((N, D)) * (ub - lb)) * U)
        else:
            r = rng.random()
            Prey = Prey + (FADs * (1 - r) + r) * (Prey[rng.permutation(N)] - Prey[rng.permutation(N)])
        Prey = _clip(Prey, lb, ub)
        Prey_fads = Prey.copy()
        Prey_gau = Prey.copy()                                 # Gaussian_search.m
        for i in range(N):
            d = rng.integers(D)
            Prey_gau[i, d] = Prey_gau[i, d] + (ub[d] - lb[d]) * rng.standard_normal()
        Prey_gau = _clip(Prey_gau, lb, ub)

        two_loc = np.unique(np.r_[Prey_old, Prey_evo, Prey_fads, Prey_gau], axis=0)
        subfit = problem.evaluate(two_loc)                     # MOFcn(FUN, two_loc, numObj)
        Zmin = np.min(np.r_[Zmin[None, :], subfit], axis=0)
        F_es = problem.evaluate(two_loc)                       # MOFcn inside EnvironmentalSelection
        sel = nsga3_env_selection(F_es, N, Z, Zmin, rng)
        Prey = two_loc[sel]
        fit = problem.evaluate(Prey)                           # [fit] = MOFcn(FUN, Prey, numObj)
        Prey_old = Prey.copy()
        problem.report(Prey, fit)
    return Prey, fit if T > 0 else Fp
