"""Multi-Objective Grey Wolf Optimizer (MOGWO).

Mirjalili, S., Saremi, S., Mirjalili, S. M., Coelho, L. d. S. Multi-objective grey wolf optimizer: A novel
algorithm for multi-criterion optimization. Expert Systems with Applications 47 (2016) 106-119.
DOI: 10.1016/j.eswa.2015.10.039

Reference source: the authors' MATLAB demo v1.0 (MOGWO.m script + Kalami's MOPSO repository helpers
CreateHypercubes.m, GetGridIndex.m, SelectLeader.m, DeleteFromRep.m, DetermineDomination.m, ...), mirrored
at github.com/VG-TechCenter/Multi-objective-gray-wolf-optimization-algorithm (see mosi/SOURCES.md).

Evaluations: N at initialisation + N per iteration -> N*(T+1).
Output set (problem.report): the repository (Archive), after initialisation and after every iteration.

Faithful to the original, including:
- a = 2 - it*2/MaxIt with it = 1..MaxIt (a reaches 0 in the last iteration);
- per wolf, three leaders are drawn: Delta, Beta, Alpha = SelectLeader(Archive) (each a roulette over the
  occupied hypercubes with p ~ count^-beta + a uniform member); if |Archive| > 1, Beta is redrawn from the
  archive members whose position differs from Delta (rep2); if |Archive| > 2, Alpha is redrawn from rep2
  without the members equal to Beta (rep3);
- X1 uses a per-dimension A vector, X2 and X3 use a scalar A (rand() vs rand(1,nVar) in the code);
  the "Delta" leader plays the role of alpha in X1 (naming as in the code);
- new position = (X1+X2+X3)/3, clipped to [lb, ub], then evaluated; wolves are not kept greedily;
- repository update with the MOPSO grid: the grid is rebuilt only at initialisation and after a
  truncation (DeleteFromRep with gamma = 2), grid indices are recomputed with the current grid after
  every merge; nGrid = 10, alpha = 0.1, beta = 4.
Deviation (crash fix only): when rep2 or rep3 would be empty (all remaining members share Delta's/Beta's
position) the MATLAB code stops with an undefined-variable error; here the previously drawn leader is kept.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from _mohelpers_a import GridArchive, mclip, select_leader  # noqa: E402

from sicore.problem import iters_from_fes  # noqa: E402


def optimize(problem, pop_size=100, rng=None, max_iter=None, archive_size=100,
             alpha=0.1, n_grid=10, beta=4, gamma=2):
    N, D, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, N, N)

    X = lb + (ub - lb) * rng.random((N, D))
    F = np.array([problem(x) for x in X])
    arc = GridArchive(X, F, n_grid, alpha, beta, gamma, archive_size, rng)
    problem.report(arc.X, arc.F)

    for it in range(1, T + 1):
        a = 2 - it * (2 / T)
        AX, gidx = arc.X, arc.gidx
        nA = len(AX)
        for i in range(N):
            d = select_leader(gidx, beta, rng)
            b = select_leader(gidx, beta, rng)
            al = select_leader(gidx, beta, rng)
            delta = AX[d]
            if nA > 1:
                rep2 = np.flatnonzero(np.any(AX != delta, axis=1))
                if rep2.size:
                    b = rep2[select_leader(gidx[rep2], beta, rng)]
                if nA > 2 and rep2.size:
                    rep3 = rep2[np.any(AX[rep2] != AX[b], axis=1)]
                    if rep3.size:
                        al = rep3[select_leader(gidx[rep3], beta, rng)]
            betaw, alphaw = AX[b], AX[al]
            x = X[i]
            c = 2 * rng.random(D)
            Dd = np.abs(c * delta - x)
            A = 2 * a * rng.random(D) - a
            X1 = delta - A * np.abs(Dd)
            c = 2 * rng.random(D)
            Dd = np.abs(c * betaw - x)
            A = 2 * a * rng.random() - a
            X2 = betaw - A * np.abs(Dd)
            c = 2 * rng.random(D)
            Dd = np.abs(c * alphaw - x)
            A = 2 * a * rng.random() - a
            X3 = alphaw - A * np.abs(Dd)
            X[i] = mclip((X1 + X2 + X3) / 3, lb, ub)
            F[i] = problem(X[i])
        arc.update(X, F)
        problem.report(arc.X, arc.F)
    return arc.X, arc.F
