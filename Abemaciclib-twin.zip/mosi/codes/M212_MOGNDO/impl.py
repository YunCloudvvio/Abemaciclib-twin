"""Multi-objective Generalized Normal Distribution Optimization (MOGNDO).

Khodadadi, N., Khodadadi, E., Abdollahzadeh, B., El-Kenawy, E.-S. M., Mardanpour, P., Zhao, W.,
Gharehchopogh, F. S., Mirjalili, S. Multi-objective generalized normal distribution optimization: a novel
algorithm for multi-objective problems. Cluster Computing 27(8) (2024) 10589-10631.
doi:10.1007/s10586-024-04467-7

Reference: the first author's MATLAB code (github.com/inimakhan/MOGNDO): MOGNDO.m plus the MOPSO/MOGWO grid
archive helpers (CreateHypercubes, GetGridIndex, GetOccupiedCells, SelectLeader, DeleteFromRep,
DetermineDominations, RouletteWheelSelection). Line-by-line port.

Evaluations: N initial + 2N per iteration (every agent is re-evaluated at its current position before the
move, then evaluated again after the move) -> N + 2*N*T (N=100, T=100: 20100).

Quirks of the original reproduced on purpose:
- The leader is drawn N times per iteration (SelectLeader inside the re-evaluation loop) but only the last
  draw is used for all agents; `Best` is updated with an all-objectives-strictly-less test and never used.
- mo = mean(Leader.Position') is the SCALAR mean of the leader's components (not a mean position).
- Local exploitation (rand <= rand): u = (x_i + leader + mo)/3, deta = sqrt(((x_i-u)^2+(leader-u)^2+(mo-u)^2)/3),
  eta = u + deta*Z1 or u + deta*Z2 (Box-Muller with vc1, vc2), chosen by a second rand-vs-rand test.
- Global exploration: v = x_i + leader + beta*|randn|*v1 + (1-beta)*|randn|*v2 (the leader position is added;
  GNDO has no leader term here). The comparisons `Cost(a) < Cost(i)` and `Cost(b) < Cost(c)` are true only if
  ALL objectives are strictly smaller (MATLAB `if` on a vector). Agents are updated in place (later agents
  see already-moved, re-evaluated earlier agents).
- a, b, c are drawn with randperm(N,1) each and redrawn together until all distinct and different from i.
- Archive = non-dominated set of (archive + non-dominated agents); grid indices are recomputed with the
  current grid each iteration; the grid is rebuilt only after a deletion (and the indices are then stale
  until the next iteration, so the next leader selection uses indices of the old grid).
- Duplicate objective vectors do not dominate each other (both stay in the archive).
- RouletteWheelSelection: if rand exceeds the last cumulative sum by round-off (MATLAB would error on an
  empty index) the last cell is taken.
Parameters (original defaults): alpha=0.01 (grid inflation), nGrid=30, Beta=4 (leader pressure),
gamma=2 (deletion pressure).
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from _mohelpers_b import create_hypercubes, delete_from_rep, determine_domination, grid_index, select_leader  # noqa: E402
from sicore.problem import iters_from_fes  # noqa: E402


def optimize(problem, pop_size=100, rng=None, max_iter=None, archive_size=100,
             alpha=0.01, n_grid=30, beta=4, gamma=2):
    N, D, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, 2 * N, N)

    X = np.empty((N, D))
    F = []
    for i in range(N):
        X[i] = lb + (ub - lb) * rng.random(D)          # unifrnd(lb(j), ub(j), 1) element by element
        F.append(problem(X[i]))
    F = np.array(F)
    dom = determine_domination(F)
    AX, AF = X[~dom].copy(), F[~dom].copy()
    G = create_hypercubes(AF, n_grid, alpha)
    gidx, _ = grid_index(AF, G)
    problem.report(AX, AF)

    for it in range(T):
        for i in range(N):
            h = select_leader(gidx, beta, rng)
            F[i] = problem(X[i])
        leader = AX[h].copy()
        mo = leader.mean()
        for i in range(N):
            a, b, c = rng.integers(N), rng.integers(N), rng.integers(N)
            while a == i or a == b or c == b or c == a or c == i or b == i:
                a, b, c = rng.integers(N), rng.integers(N), rng.integers(N)
            v1 = X[a] - X[i] if np.all(F[a] < F[i]) else X[i] - X[a]
            v2 = X[b] - X[c] if np.all(F[b] < F[c]) else X[c] - X[b]
            if rng.random() <= rng.random():
                u = (X[i] + leader + mo) / 3
                deta = np.sqrt(((X[i] - u) ** 2 + (leader - u) ** 2 + (mo - u) ** 2) / 3)
                vc1 = rng.random(D)
                vc2 = rng.random(D)
                Z1 = np.sqrt(-np.log(vc2)) * np.cos(2 * np.pi * vc1)
                Z2 = np.sqrt(-np.log(vc2)) * np.cos(2 * np.pi * vc1 + np.pi)
                ra, rb = rng.random(), rng.random()
                X[i] = u + deta * Z1 if ra <= rb else u + deta * Z2
            else:
                bt = rng.random()
                X[i] = X[i] + leader + bt * abs(rng.standard_normal()) * v1 \
                    + (1 - bt) * abs(rng.standard_normal()) * v2
            X[i] = np.minimum(np.maximum(X[i], lb), ub)
            F[i] = problem(X[i])
        dom = determine_domination(F)
        AX = np.r_[AX, X[~dom]]
        AF = np.r_[AF, F[~dom]]
        dom = determine_domination(AF)
        AX, AF = AX[~dom], AF[~dom]
        gidx, _ = grid_index(AF, G)
        if len(AF) > archive_size:
            keep = delete_from_rep(gidx, len(AF) - archive_size, gamma, rng)
            AX, AF, gidx = AX[keep], AF[keep], gidx[keep]
            G = create_hypercubes(AF, n_grid, alpha)
        problem.report(AX, AF)
    return AX, AF
