"""Multi-objective Salp Swarm Algorithm (MSSA).

Mirjalili, S., Gandomi, A. H., Mirjalili, S. Z., Saremi, S., Faris, H., Mirjalili, S. M. Salp Swarm
Algorithm: A bio-inspired optimizer for engineering design problems. Advances in Engineering Software
114 (2017) 163-191. DOI: 10.1016/j.advengsoft.2017.07.002

Reference source: MSSA.m from github.com/Natee-Panagant/Comparative-study-of-truss-sizing-optimisation-
problems-in-MATLAB (Algorithms/MSSA.m): Mirjalili's MSSA demo wrapped by N. Panagant as
MSSA(fun,fout,nloop,nsol,nvar,nbit,narchive,a,b) with a constraint vector G (third-party adaptation of the
original demo code).

Evaluations: 2 set-up evaluations (obj_no = numel(feval(fun,a)) at the lower-bound vector, and
feval(fun, zeros) for the constraint count) + N per iteration + one re-evaluation of every final
archive member after the loop -> 2 + N*T + |archive|.
Output set (problem.report): the archive filtered by pbil_selection0, after every iteration.

Faithful to the wrapper, including:
- the archive starts with ArchiveMaxSize rows of zeros / inf objectives (collapsed by `unique` and
  dominated at the first update); obj_no = number of objectives (here not hard-coded);
- c1 = 2*exp(-(4t/T)^2); Food = archive member by roulette on 1./ranks;
- leaders (i <= N/2): per dimension c2, c3 = rand: Food_j +- c1*((ub_j-lb_j)*c2 + lb_j) (c3 < 0.5 -> +);
  followers (i > N/2): (X_{i-1} + X_i)/2 with X_{i-1} already moved; clipping to [lb, ub];
- the positions moved in the last iteration are never evaluated.
Constraint handling (G, fpenal_1) is not ported (identity for unconstrained problems); the Food update
inside the evaluation loop is overwritten before use.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from _mohelpers_a import pg_archive_step, pg_output, pg_select  # noqa: E402

from sicore.problem import iters_from_fes  # noqa: E402


def optimize(problem, pop_size=100, rng=None, max_iter=None, archive_size=100):
    N, D, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, N, 2 + archive_size)

    M = len(problem(lb.copy()))                  # obj_no = numel(feval(fun, a))
    problem(np.zeros(D))                         # [ff, gg] = feval(fun, Archive_X(1,:)')
    AX = np.zeros((archive_size, D))
    AF = np.full((archive_size, M), np.inf)
    X = lb + (ub - lb) * rng.random((N, D))
    for t in range(1, T + 1):
        c1 = 2 * np.exp(-(4 * t / T) ** 2)
        PF = np.array([problem(x) for x in X])
        AX, AF, ranks = pg_archive_step(AX, AF, X, PF, archive_size, M, rng)
        food = AX[pg_select(ranks, rng, inverse=True)]
        for i in range(N):
            if i + 1 <= N / 2:
                c = rng.random((D, 2))
                step = c1 * ((ub - lb) * c[:, 0] + lb)
                X[i] = np.where(c[:, 1] < 0.5, food + step, food - step)
            elif i + 1 < N + 1:
                X[i] = (X[i] + X[i - 1]) / 2
            X[i] = np.where(X[i] > ub, ub, np.where(X[i] < lb, lb, X[i]))
        problem.report(*pg_output(AX, AF))
    for x in AX:                                  # final re-evaluation of the archive (fpareto, gpareto)
        problem(x)
    return pg_output(AX, AF)
