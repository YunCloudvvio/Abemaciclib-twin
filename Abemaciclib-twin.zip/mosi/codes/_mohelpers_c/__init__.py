"""Shared multi-objective helpers for shard IMC (MOSI M301-M333). Owned by shard IMC; other shards: do not edit.

Import from an impl.py with:
    import os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    from _mohelpers_c import nd_sort, ...
Every helper is a faithful port of a widely copied MATLAB routine (source named in its docstring).
MATLAB randi/randperm/rand draws are replaced by the equivalent numpy Generator draws (same distribution).
"""
from __future__ import annotations

import itertools
import math

import numpy as np


# ----------------------------------------------------------------------------------------------------------
# Dominance, non-dominated sorting (PlatEMO NDSort), crowding distance (PlatEMO CrowdingDistance)
# ----------------------------------------------------------------------------------------------------------
def dominates(a, b):
    """all(a <= b) and any(a < b) (minimisation)."""
    return bool(np.all(a <= b) and np.any(a < b))


def dom_matrix(F):
    """D[i, j] = True when row i dominates row j."""
    F = np.asarray(F, dtype=float)
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    return le & lt


def nd_sort(F, n_sort=math.inf):
    """PlatEMO NDSort(PopObj, nSort) (ENS-SS / T-ENS give identical results).

    Returns (FrontNo, MaxFNo): FrontNo is a float array (inf for solutions not sorted); fronts are assigned
    until at least min(n_sort, N) solutions are sorted. Identical objective vectors share a front.
    """
    F = np.asarray(F, dtype=float)
    N = len(F)
    U, loc = np.unique(F, axis=0, return_inverse=True)
    loc = np.asarray(loc).ravel()
    table = np.bincount(loc, minlength=len(U))
    D = dom_matrix(U)
    front = np.full(len(U), np.inf)
    maxf = 0
    target = min(n_sort, N)
    while table[np.isfinite(front)].sum() < target:
        maxf += 1
        rem = ~np.isfinite(front)
        idx = np.flatnonzero(rem)
        dominated = D[np.ix_(idx, idx)].any(axis=0)
        front[idx[~dominated]] = maxf
    return front[loc], maxf


def nd_front_all(F):
    """Full non-dominated sorting (all solutions get a front number)."""
    return nd_sort(F, math.inf)[0]


def crowding_distance_platemo(F, front_no=None):
    """PlatEMO CrowdingDistance(PopObj, FrontNo): per-front, normalised by (fmax - fmin) of the front,
    boundary solutions get inf. Solutions with front_no == inf get 0 (as in PlatEMO: CrowdDis initialised 0
    and only finite fronts processed)."""
    F = np.asarray(F, dtype=float)
    N, M = F.shape
    if front_no is None:
        front_no = np.ones(N)
    cd = np.zeros(N)
    for f in np.unique(front_no[np.isfinite(front_no)]):
        fr = np.flatnonzero(front_no == f)
        fmax = F[fr].max(axis=0)
        fmin = F[fr].min(axis=0)
        for i in range(M):
            rank = np.argsort(F[fr, i], kind="stable")  # MATLAB sortrows(PopObj(Front,i)) is stable
            cd[fr[rank[0]]] = np.inf
            cd[fr[rank[-1]]] = np.inf
            for j in range(1, len(fr) - 1):
                cd[fr[rank[j]]] += (F[fr[rank[j + 1]], i] - F[fr[rank[j - 1]], i]) / (fmax[i] - fmin[i])
    return cd


# ----------------------------------------------------------------------------------------------------------
# NSGA-III machinery (PlatEMO UniformPoint and EnvironmentalSelection/LastSelection, 2018-era version)
# ----------------------------------------------------------------------------------------------------------
def _nchoosek_rows(n, k):
    return np.array(list(itertools.combinations(range(1, n + 1), k)), dtype=float).reshape(-1, k)


def uniform_point(N, M):
    """PlatEMO UniformPoint(N, M) (Das-Dennis, two layers when H1 < M). Returns (W, N)."""
    H1 = 1
    while math.comb(H1 + M, M - 1) <= N:
        H1 += 1
    W = _nchoosek_rows(H1 + M - 1, M - 1) - np.arange(M - 1) - 1
    W = (np.c_[W, np.zeros(len(W)) + H1] - np.c_[np.zeros(len(W)), W]) / H1
    if H1 < M:
        H2 = 0
        while math.comb(H1 + M - 1, M - 1) + math.comb(H2 + M, M - 1) <= N:
            H2 += 1
        if H2 > 0:
            W2 = _nchoosek_rows(H2 + M - 1, M - 1) - np.arange(M - 1) - 1
            W2 = (np.c_[W2, np.zeros(len(W2)) + H2] - np.c_[np.zeros(len(W2)), W2]) / H2
            W = np.r_[W, W2 / 2 + 1 / (2 * M)]
    W = np.maximum(W, 1e-6)
    return W, len(W)


def nsga3_last_selection(PopObj1, PopObj2, K, Z, Zmin, rng):
    """PlatEMO NSGA-III LastSelection: returns a boolean mask over PopObj2 with K selected.

    Notes: the hyperplane solve uses numpy; when the extreme-point matrix is exactly singular numpy raises
    (MATLAB would warn and return Inf/NaN) -> treated as NaN intercepts -> fallback to the max (as PlatEMO's
    isnan branch). sqrt(1 - cos^2) is clipped at 0 (MATLAB would return a tiny complex number)."""
    PopObj = np.r_[PopObj1, PopObj2] - Zmin
    N, M = PopObj.shape
    N1 = len(PopObj1)
    NZ = len(Z)
    w = np.zeros((M, M)) + 1e-6 + np.eye(M)
    extreme = np.array([int(np.argmin(np.max(PopObj / w[i], axis=1))) for i in range(M)])
    try:
        hyper = np.linalg.solve(PopObj[extreme], np.ones(M))
        with np.errstate(divide="ignore"):
            a = 1.0 / hyper
    except np.linalg.LinAlgError:
        a = np.full(M, np.nan)
    if np.any(np.isnan(a)):
        a = PopObj.max(axis=0)
    PopObj = PopObj / a
    nrm = np.sqrt((PopObj ** 2).sum(axis=1))
    znrm = np.sqrt((Z ** 2).sum(axis=1))
    with np.errstate(invalid="ignore", divide="ignore"):
        cosine = (PopObj @ Z.T) / np.outer(nrm, znrm)
    distance = nrm[:, None] * np.sqrt(np.maximum(1 - cosine ** 2, 0))
    pi = np.argmin(distance, axis=1)
    d = distance[np.arange(N), pi]
    rho = np.bincount(pi[:N1], minlength=NZ).astype(float)
    choose = np.zeros(len(PopObj2), dtype=bool)
    zchoose = np.ones(NZ, dtype=bool)
    pi2 = pi[N1:]
    while choose.sum() < K:
        temp = np.flatnonzero(zchoose)
        jmin = np.flatnonzero(rho[temp] == rho[temp].min())
        j = temp[jmin[rng.integers(len(jmin))]]
        I = np.flatnonzero(~choose & (pi2 == j))
        if I.size:
            if rho[j] == 0:
                s = int(np.argmin(d[N1 + I]))
            else:
                s = int(rng.integers(len(I)))
            choose[I[s]] = True
            rho[j] += 1
        else:
            zchoose[j] = False
    return choose


def nsga3_env_selection(F, N, Z, Zmin, rng):
    """PlatEMO NSGA-III EnvironmentalSelection without constraints: returns the sorted indices (original
    order) of the N selected rows of F."""
    F = np.asarray(F, dtype=float)
    front, maxf = nd_sort(F, N)
    nxt = front < maxf
    last = np.flatnonzero(front == maxf)
    ch = nsga3_last_selection(F[nxt], F[last], N - int(nxt.sum()), Z, Zmin, rng)
    nxt[last[ch]] = True
    return np.flatnonzero(nxt)


# ----------------------------------------------------------------------------------------------------------
# MOPSO/MOGWO grid archive (Mirjalili's MOGWO/MOALO code: DetermineDomination, CreateHypercubes,
# GetGridIndex, GetOccupiedCells, RouletteWheelSelection, SelectLeader, DeleteFromRep)
# ----------------------------------------------------------------------------------------------------------
def determine_domination(F):
    """MOGWO DetermineDomination: sequential loop with its exact visiting order (returns 'Dominated' flags)."""
    F = np.asarray(F, dtype=float)
    n = len(F)
    D = dom_matrix(F)
    dominated = np.zeros(n, dtype=bool)
    for i in range(n):
        for j in range(i):
            if not dominated[j]:
                if D[i, j]:
                    dominated[j] = True
                elif D[j, i]:
                    dominated[i] = True
                    break
    return dominated


def create_hypercubes(F, ngrid, alpha):
    """MOGWO CreateHypercubes(costs, nGrid, alpha); F has one row per solution. Returns the list of
    'Upper' arrays (Lower is not used by GetGridIndex)."""
    F = np.asarray(F, dtype=float)
    G = []
    for j in range(F.shape[1]):
        mn, mx = F[:, j].min(), F[:, j].max()
        dc = alpha * (mx - mn)
        gx = np.linspace(mn - dc, mx + dc, ngrid - 1)
        G.append(np.r_[gx, np.inf])
    return G


def grid_index(F, G):
    """MOGWO GetGridIndex for every row: Index = sub2ind(ngrid*ones(1,nobj), SubIndex) (1-based)."""
    F = np.atleast_2d(np.asarray(F, dtype=float))
    ngrid = len(G[0])
    idx = np.zeros(len(F), dtype=np.int64)
    sub = np.zeros(F.shape, dtype=np.int64)
    for j, U in enumerate(G):
        # find(c(j) < U, 1, 'first') (1-based)
        s = np.argmax(F[:, j][:, None] < U[None, :], axis=1) + 1
        sub[:, j] = s
        idx += (s - 1) * ngrid ** j
    return idx + 1, sub


def roulette_wheel(p, rng):
    """MOGWO RouletteWheelSelection: r = rand; first i with r <= cumsum(p)(i) (0-based result)."""
    r = rng.random()
    c = np.cumsum(p)
    i = int(np.searchsorted(c, r, side="left"))
    return min(i, len(c) - 1)


def occupied_cells(gidx):
    """MOGWO GetOccupiedCells: unique (sorted) cell indices and their member counts."""
    occ, cnt = np.unique(gidx, return_counts=True)
    return occ, cnt.astype(float)


def select_leader(gidx, beta, rng):
    """MOGWO SelectLeader: roulette over occupied cells with p ~ count^-beta, then a uniform member.
    Returns the 0-based position in the archive."""
    occ, cnt = occupied_cells(gidx)
    p = cnt ** (-beta)
    p = p / p.sum()
    cell = occ[roulette_wheel(p, rng)]
    members = np.flatnonzero(gidx == cell)
    return int(members[rng.integers(len(members))])


def delete_from_rep(gidx, extra, gamma, rng):
    """MOGWO DeleteFromRep: removes 'extra' members one by one (roulette p ~ count^gamma, uniform member).
    Returns the kept 0-based positions in their original order."""
    keep = np.arange(len(gidx))
    g = np.asarray(gidx).copy()
    for _ in range(extra):
        occ, cnt = occupied_cells(g)
        p = cnt ** gamma
        p = p / p.sum()
        cell = occ[roulette_wheel(p, rng)]
        members = np.flatnonzero(g == cell)
        j = members[rng.integers(len(members))]
        keep = np.delete(keep, j)
        g = np.delete(g, j)
    return keep


# ----------------------------------------------------------------------------------------------------------
# Misc
# ----------------------------------------------------------------------------------------------------------
def levy_mantegna(rng, shape, beta=1.5):
    """Mantegna Levy steps: u ~ N(0, sigma_u), v ~ N(0, 1), z = u / |v|^(1/beta)."""
    num = math.gamma(1 + beta) * math.sin(math.pi * beta / 2)
    den = math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2)
    sigma_u = (num / den) ** (1 / beta)
    u = rng.normal(0.0, sigma_u, shape)
    v = rng.normal(0.0, 1.0, shape)
    return u / np.abs(v) ** (1 / beta)


def clip_matlab(X, lb, ub):
    """Flag4ub/Flag4lb style bound handling: out-of-range components set to the violated bound."""
    return np.minimum(np.maximum(X, lb), ub)


# ----------------------------------------------------------------------------------------------------------
# NSGA-II style elitist selection and the information feedback mechanism (IFM) used by several papers
# ----------------------------------------------------------------------------------------------------------
def nsga2_select(F, N):
    """Elitist non-dominated sorting + crowding distance (Deb et al. 2002): fronts are added while they fit;
    the remaining places of the last front go to the largest crowding distances (PlatEMO CrowdingDistance,
    stable order on ties). Returns the selected indices (fronts in order, last front by decreasing CD) and the
    front numbers / crowding distances of ALL rows (inf where not sorted)."""
    F = np.asarray(F, dtype=float)
    front, maxf = nd_sort(F, N)
    with np.errstate(invalid="ignore", divide="ignore"):
        cd = crowding_distance_platemo(F, front)
    nxt = np.flatnonzero(front < maxf)
    last = np.flatnonzero(front == maxf)
    order = last[np.argsort(-cd[last], kind="stable")]
    sel = np.r_[nxt, order[: N - len(nxt)]].astype(int)
    return sel, front, cd


def rank_cd_order(F):
    """Order of all rows by (front ascending, crowding distance descending), stable."""
    front, _ = nd_sort(F)
    with np.errstate(invalid="ignore", divide="ignore"):
        cd = crowding_distance_platemo(F, front)
    return np.lexsort((-cd, front)), front, cd


def ifm_weights(f_new, f_k):
    """IFM (Wang & Tan) weights d1 = f_k/(f_new+f_k), d2 = f_new/(f_new+f_k); a zero denominator gives
    d1 = d2 = 0.5 (guard added: the papers do not define this case)."""
    s = f_new + f_k
    if s == 0 or not np.isfinite(s):
        return 0.5, 0.5
    return f_k / s, f_new / s


def scalar_fitness(F):
    """Scalar 'fitness value' used where an MO paper applies a single-objective formula (IFM weights,
    fitness-proportional factors): the sum of the objective values (choice documented in each impl)."""
    return np.asarray(F, dtype=float).sum(axis=-1)


def ifm_offspring(problem, X, F, U, FU, rng, lb, ub):
    """Information feedback model M-R1 as written in the Jangir-group MO papers (MOCPO/MOEHO/MOIVYA Alg. 1):
    x_i^{t+1} = d1*u_i^{t+1} + d2*x_k^t, d1 = f_k^t/(f_i^{t+1}+f_k^t), d2 = f_i^{t+1}/(f_i^{t+1}+f_k^t),
    k uniformly random in the parent population, f = scalar_fitness. The result is clipped to the bounds and
    evaluated (one evaluation per individual, in index order). Returns (Q, FQ)."""
    N = len(X)
    Q = np.empty_like(U)
    FQ = []
    fu, fx = scalar_fitness(FU), scalar_fitness(F)
    for i in range(N):
        k = int(rng.integers(N))
        d1, d2 = ifm_weights(fu[i], fx[k])
        Q[i] = np.clip(d1 * U[i] + d2 * X[k], lb, ub)
        FQ.append(problem(Q[i]))
    return Q, np.array(FQ)
