"""Multi-Objective Equilibrium Optimizer Slime Mould Algorithm (MOEOSMA).

Luo, Q., Yin, S., Zhou, G., Meng, W., Zhao, Y., Zhou, Y. Multi-objective equilibrium optimizer slime
mould algorithm and its application in solving engineering problems. Structural and Multidisciplinary
Optimization 66 (2023) 114. DOI: 10.1007/s00158-023-03568-y

Reference source: the authors' MATLAB code (github.com/Shihong-Yin/MOEOSMA, folder MOEOSMA_for_CEC2020:
MOEOSMA.m, UpdateArchive.m, RankingProcess.m, HandleFullArchive.m, RouletteWheelSelection.m,
initialization.m). Paper PDF not available here (Springer, manual download).

Evaluations: N at initialisation + 2N per iteration (all N after the boundary check at the start of the
iteration, all N after the EO/SMA move) -> N + 2N*T. The positions produced by the final mutation step
are never evaluated.
Output set (problem.report): the Pareto archive (capacity = population size, as hard-coded in the code;
`archive_size` only exists for the harness and must equal pop_size to match the original). After
initialisation the archive of the code is still empty (inf rows), so the non-dominated initial
solutions are reported instead.

Faithful to the code, including:
- archive update (UpdateArchive.m): a member is removed only if another member is STRICTLY better in
  every objective; identical objective vectors are de-duplicated (first occurrence kept);
- ranks (RankingProcess.m): number of members within (max-min)/ArchiveMaxSize in every objective;
  truncation (HandleFullArchive.m) removes members by roulette (rand*cumsum, prob. ~ rank), ranks not
  recomputed between removals; the ranks are recomputed after the first truncation only;
- equilibrium pool = all archive members with the minimal rank;
- "memory saving": the previous position is kept if its fitness is better in EVERY objective (MATLAB
  'if' on a vector), otherwise the new one;
- SMA weights from the objective rem(it, M)+1 (Eq. 14 of the paper), EO/SMA move (Eq. 13) applied
  sequentially (rows already moved are used by later rows in X(R(i,1),:), X(R(i,2),:));
- boundary handling: violated components -> (Xold + bound)/2;
- DE-like mutation X + SF*(X(r1)-X(r2)), SF = 0.2 + 0.8*rand, evaluated at the next iteration.
Not reproduced: rand('seed', sum(100*clock)) at the start of the code (clock-based reseeding).
"""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from _mohelpers_a import determine_domination  # noqa: E402

from sicore.problem import iters_from_fes  # noqa: E402

EPS = np.finfo(float).eps


def _update_archive(AX, AF, X, F):
    TX, TF = np.r_[AX, X], np.r_[AF, F]
    strict = np.all(TF[:, None, :] < TF[None, :, :], axis=2)      # strict[j, i]: j strictly better than i
    keep = ~strict.any(axis=0)
    TX, TF = TX[keep], TF[keep]
    _, first = np.unique(TF, axis=0, return_index=True)
    first = np.sort(first)
    return TX[first], TF[first]


def _ranks(AF, cap):
    if len(AF) == 1:
        unit = np.zeros(AF.shape[1])
    else:
        unit = (AF.max(axis=0) - AF.min(axis=0)) / cap
    close = np.all(np.abs(AF[None, :, :] - AF[:, None, :]) < unit, axis=2)
    return close.sum(axis=1).astype(float)


def _roulette(w, rng):
    acc = np.cumsum(w)
    p = rng.random() * acc[-1]
    hit = np.flatnonzero(acc > p)
    return int(hit[0]) if hit.size else 0


def _handle_full(AX, AF, ranks, cap, rng):
    ranks = ranks.copy()
    for _ in range(len(AF) - cap):
        k = _roulette(ranks, rng)
        AX, AF, ranks = np.delete(AX, k, 0), np.delete(AF, k, 0), np.delete(ranks, k)
    return AX, AF


def _bound(X, Xold, lb, ub):
    FU, FL = X > ub, X < lb
    return np.where(FU, (Xold + ub) / 2, np.where(FL, (Xold + lb) / 2, X))


def optimize(problem, pop_size=100, rng=None, max_iter=None, archive_size=None, GP=0.5, z=0.6):
    N, D, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, 2 * N, N)
    cap = N                                   # ArchiveMaxSize = PopSize in the code

    X = lb + (ub - lb) * rng.random((N, D))
    Fit = np.array([problem(x) for x in X])
    M = Fit.shape[1]
    nd = ~determine_domination(Fit)
    problem.report(X[nd], Fit[nd])
    AX, AF = np.zeros((0, D)), np.zeros((0, M))   # the inf rows of the code are dominated at once
    fit_old, Xold = Fit.copy(), X.copy()
    weight = np.ones((N, D))

    def memory(X, Fit, Xold, fit_old):
        inx = np.all(fit_old < Fit, axis=1)
        X = np.where(inx[:, None], Xold, X)
        Fit = np.where(inx[:, None], fit_old, Fit)
        return X, Fit

    for it in range(1, T + 1):
        X = _bound(X, Xold, lb, ub)
        Fit = np.array([problem(x) for x in X])
        AX, AF = _update_archive(AX, AF, X, Fit)
        ranks = _ranks(AF, cap)
        if len(AF) > cap:
            AX, AF = _handle_full(AX, AF, ranks, cap, rng)
            ranks = _ranks(AF, cap)
        order = np.argsort(ranks, kind="stable")
        elite = order[ranks[order] == ranks[order[0]]]
        pool = AX[elite]
        X, Fit = memory(X, Fit, Xold, fit_old)
        fit_old, Xold = Fit.copy(), X.copy()

        obj = it % M
        sidx = np.argsort(Fit[:, obj], kind="stable")
        sord = Fit[sidx, obj]
        best, worst = sord[0], sord[-1]
        S = best - worst + EPS
        for i in range(N):
            lg = math.log10((best - sord[i]) / S + 1)
            if i + 1 <= N / 2:
                weight[sidx[i]] = 1 + rng.random(D) * lg
            else:
                weight[sidx[i]] = 1 - rng.random(D) * lg
        a1 = (1 + (1 - it / T) ** (2 * it / T)) * rng.random()
        a2 = (2 - (1 - it / T) ** (2 * it / T)) * rng.random()
        t1 = (1 - it / T) ** (a2 * it / T)
        lam = rng.random((N, D))
        r1 = rng.random(N)
        r2 = rng.random(N)
        rn = rng.integers(len(pool), size=N)
        a = math.atanh(1 - (it / T))
        vb = rng.uniform(-a, a, (N, D)) if a > 0 else np.zeros((N, D))
        r = rng.random((N, D))
        R = rng.integers(N, size=(N, 2))
        for i in range(N):
            g = pool[rn[i]]
            if rng.random() < z:
                Fe = a1 * np.sign(r[i] - 0.5) * (np.exp(-lam[i] * t1) - 1)
                GCP = 0.5 * r1[i] * np.ones(D) * (r2[i] >= GP)
                G = (GCP * (g - lam[i] * X[i])) * Fe
                X[i] = g + (X[i] - g) * Fe + G / lam[i] * (1 - Fe)
            else:
                X[i] = g + vb[i] * (weight[i] * X[R[i, 0]] - X[R[i, 1]])
        X = _bound(X, Xold, lb, ub)
        Fit = np.array([problem(x) for x in X])
        AX, AF = _update_archive(AX, AF, X, Fit)
        ranks = _ranks(AF, cap)
        if len(AF) > cap:
            AX, AF = _handle_full(AX, AF, ranks, cap, rng)
        X, Fit = memory(X, Fit, Xold, fit_old)
        fit_old, Xold = Fit.copy(), X.copy()
        problem.report(AX, AF)
        SF = 0.2 + rng.random() * 0.8
        R = rng.integers(N, size=(N, 2))
        X = X + SF * (X[R[:, 0]] - X[R[:, 1]])
    return AX, AF
