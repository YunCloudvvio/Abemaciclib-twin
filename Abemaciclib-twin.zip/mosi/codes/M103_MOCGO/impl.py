"""Multi-Objective Chaos Game Optimization (MOCGO).

Khodadadi, N., Abualigah, L., Al-Tashi, Q., Mirjalili, S. Multi-objective chaos game optimization.
Neural Computing and Applications 35 (2023) 14973-15004. DOI: 10.1007/s00521-023-08432-0

Reference source: the authors' MATLAB code (github.com/inimakhan/MOCGO, MOCGO.m + MOPSO grid helpers).

Evaluations: N at initialisation + 4(N+1) per iteration (loop `for i=0:Seed_Number`, four new seeds per
pass) -> N + T*4(N+1).
Output set (problem.report): the repository (Archive), after initialisation and after every iteration.

Faithful to the code, including its quirks:
- the seed matrix `Seed` holds the INITIAL positions only and is never updated (MeanGroup is always
  built from initial seeds);
- the population grows to 4(N+1) members; all of them are new in every iteration and only they compete
  for the archive;
- per pass: one leader (SelectLeader, beta=4); I = randi([1,2],1,12), Ir = randi([0,1],1,5);
  MeanGroup = mean of randperm(N, randperm(N,1)) initial seeds (the seed itself if one);
  Alpha rows: rand, 2*rand-1, Ir(1)*rand+1, Ir(2)*rand+~Ir(2); three rows chosen with randi([1,4],1,3);
  seeds: SA1.*(I1*L - I2*MG), L + SA2.*(I3*MG - I4), MG + SA3.*(I5*L - I6), unifrnd(lb, ub)
  (the code uses Leader in place of the paper's best seed; I(7..12), Ir(3..5) unused);
  each clipped to [lb, ub] and evaluated;
- MOPSO grid repository with nGrid = 30, alpha = 0.1, beta = 4, gamma = 2.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from _mohelpers_a import GridArchive, mclip  # noqa: E402

from sicore.problem import iters_from_fes  # noqa: E402


def optimize(problem, pop_size=100, rng=None, max_iter=None, archive_size=100,
             alpha=0.1, n_grid=30, beta=4, gamma=2):
    N, D, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, 4 * (N + 1), N)

    S = lb + (ub - lb) * rng.random((N, D))
    F0 = np.array([problem(x) for x in S])
    arc = GridArchive(S, F0, n_grid, alpha, beta, gamma, archive_size, rng)
    problem.report(arc.X, arc.F)

    X = np.empty((4 * (N + 1), D))
    F = np.empty((4 * (N + 1), F0.shape[1]))
    for it in range(1, T + 1):
        for i in range(N + 1):
            L = arc.X[arc.leader()]
            I = rng.integers(1, 3, size=12)
            Ir = rng.integers(0, 2, size=5)
            k = int(rng.integers(1, N + 1))
            grp = rng.permutation(N)[:k]
            MG = S[grp].mean(axis=0) if k != 1 else S[grp[0]]
            A = np.empty((4, D))
            A[0] = rng.random(D)
            A[1] = 2 * rng.random(D) - 1
            A[2] = Ir[0] * rng.random(D) + 1
            A[3] = Ir[1] * rng.random(D) + (not Ir[1])
            SA = A[rng.integers(0, 4, size=3)]
            cand = (SA[0] * (I[0] * L - I[1] * MG),
                    L + SA[1] * (I[2] * MG - I[3]),
                    MG + SA[2] * (I[4] * L - I[5]),
                    lb + (ub - lb) * rng.random(D))
            for j, x in enumerate(cand):
                X[4 * i + j] = mclip(x, lb, ub)
                F[4 * i + j] = problem(X[4 * i + j])
        arc.update(X, F)
        problem.report(arc.X, arc.F)
    return arc.X, arc.F
