"""C-MOBRO - Constrained Multi-Objective Battle Royale Optimization.

Alp, S., Dehkharghani, R., Akan, T. C-MOBRO: constrained multi-objective Battle Royale Optimization algorithm.
Cluster Computing 28 (2025) 906. doi:10.1007/s10586-025-05600-w

Reference used: the authors' MATLAB code, CEC2021_CMOBRO.7z extracted to CEC2021_CMOBRO/CMOBRO/
(MOBRO_Fun_4.m with SelectLeaderFinal.m, Force2Feasible.m, Dominates.m, DetermineDomination.m, edistance_n.m,
MyCrossOverFcnConstraint.m (CrossType 4 as set in Main.m), MutationFcnConstraint.m, Mutate.m, updateRep.m,
updateRep_by_single.m, CreateGrid.m, FindGridIndex.m, DeleteOneRepMemebr3.m, ComplateRep2.m, Get_CV.m;
https://github.com/Taymazakan/C-MOBRO, commit 3d1f52f). The code is followed where it differs from the paper.

Defaults from Main.m: MaxFault = 6, CrossType = 4, mut = 1, nGrid = 20, alpha = 0.1, beta = 1, gamma = 2,
pm = 0.3 (hard-coded in the loop); population/iterations/archive from Get_run_conditions (2 objectives: 80
soldiers, repository max(30M, 100)).

Constraint handling: the verification problems are unconstrained, so every CV = 0 and the constrained
dominance of Dominates.m reduces to Pareto dominance; this port implements the CV = 0 path only (the
constrained branches, Force2Feasible's loop and the infeasible leader branch are never reached). A problem
with constraints would need the CV branches added.

Evaluations: init nPop; per soldier i: 1 (crossover offspring, only when Fault < MaxFault) + 1 (re-evaluation
of the clipped loser 'dam') [+ 1 if the winner was out of bounds, never happens] + 1 (mutation of 'flag').
Nominal 3*nPop per iteration (used for T when max_iter is None).

Quirks reproduced:
- the crossover offspring (Eq. CrossType 4: x = R1.*flag + R2.*(vel - pos), Off = pos + x) is evaluated
  WITHOUT bound handling; the accepted position is clipped afterwards and evaluated again;
- SelectLeaderFinal: cell roulette with P ~ exp(-beta*count); inside a cell with > 1 members it walks the
  members drawing rand() and stops at the first with rand() > 0.5 (else the last); if the cell has ONE member
  it returns rep(1) (the first archive member), not that member;
- DeleteOneRepMemebr3: cell roulette with P ~ exp(gamma*count); in a cell with > 1 members it deletes the
  LAST member (CV >= max over equal CVs); if the cell has one member it deletes rep(1); grid indices are not
  recomputed between deletions; if exp overflows (P = NaN) the roulette finds nothing and rep(1) is deleted;
- winner/loser: first soldier in ascending distance order that dominates / is dominated by soldier i; when
  none, a fair coin decides with the nearest neighbour;
- the loser's Fault is incremented, the winner's reset; at MaxFault the loser is re-initialised uniformly
  (no crossover evaluation);
- the repository is updated once per iteration: flag (if its position is new), then the non-dominated
  soldiers whose positions are new, then dominated members are removed;
- the final output (after the last iteration) is ComplateRep2(rep, soldier) when |rep| < nRep (non-dominated
  soldiers merged in) - reported as the last report; during the run rep is reported.
Deviation (unavoidable): out-of-bounds crossover offspring can give NaN objectives in numpy (e.g. sqrt of a
negative number in ZDT); MATLAB returns complex numbers and compares their real parts. In this port a NaN
offspring never dominates its parent.
"""
import numpy as np

from sicore.problem import iters_from_fes


def _dom(a, b):
    return bool(np.all(a <= b) and np.any(a < b))


def _determine_domination(F):
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    return np.any(le & lt, axis=0)


def _create_grid(F, nGrid, alpha):
    cmin, cmax = F.min(axis=0), F.max(axis=0)
    dc = cmax - cmin
    cmin, cmax = cmin - alpha * dc, cmax + alpha * dc
    return [np.r_[np.linspace(cmin[j], cmax[j], nGrid + 1), np.inf] for j in range(F.shape[1])]


def _grid_index(F, UB):
    n_g = len(UB[0])                                   # numel(Grid(1).LB) = nGrid + 2
    gi = np.zeros(len(F), dtype=np.int64)
    for k, c in enumerate(F):
        sub = [int(np.argmax(c[j] < UB[j])) + 1 for j in range(len(c))]
        g = sub[0]
        for j in range(1, len(c)):
            g = (g - 1) * n_g + sub[j]
        gi[k] = g
    return gi


def _roulette(P, rng):
    r = rng.random()
    C = np.cumsum(P)
    hit = np.flatnonzero(r <= C)
    return int(hit[0]) if hit.size else None


def _select_leader(GI, beta, rng):
    OC, cnt = np.unique(GI, return_counts=True)
    P = np.exp(-beta * cnt)
    P = P / P.sum()
    sci = _roulette(P, rng)
    SCM = np.flatnonzero(GI == OC[sci])
    if len(SCM) > 1:
        smi = SCM[-1]
        for rid in SCM:
            smi = rid
            if rng.random() > 0.5:
                break
    else:
        smi = 0
    return int(smi)


def _delete_one(GI, gamma, rng):
    OC, cnt = np.unique(GI, return_counts=True)
    with np.errstate(over="ignore", invalid="ignore"):
        P = np.exp(gamma * cnt.astype(float))
        P = P / P.sum()
    sci = _roulette(P, rng)
    if sci is None:
        return 0
    SCM = np.flatnonzero(GI == OC[sci])
    return int(SCM[-1]) if len(SCM) > 1 else 0


def _update_rep(RX, RF, X, F, nd_mask):
    for k in np.flatnonzero(nd_mask):
        if not any(np.array_equal(X[k], rx) for rx in RX):
            RX.append(X[k].copy())
            RF.append(F[k].copy())
    return RX, RF


def _filter_and_trim(RX, RF, nGrid, alpha, gamma, nRep, rng):
    RXa, RFa = np.array(RX), np.array(RF)
    dom = _determine_domination(RFa)
    RXa, RFa = RXa[~dom], RFa[~dom]
    GI = _grid_index(RFa, _create_grid(RFa, nGrid, alpha))
    if len(RXa) > nRep:
        for _ in range(len(RXa) - nRep):
            s = _delete_one(GI, gamma, rng)
            RXa, RFa, GI = np.delete(RXa, s, 0), np.delete(RFa, s, 0), np.delete(GI, s)
    return list(RXa), list(RFa), GI


def optimize(problem, pop_size=80, rng=None, max_iter=None, archive_size=100, MaxFault=6, nGrid=20,
             alpha=0.1, beta=1.0, gamma=2.0, pm=0.3):
    nPop, Dim, lb, ub = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, 3 * nPop, nPop)
    nRep = archive_size

    xy = rng.random((Dim, nPop))
    X = (xy * (ub - lb)[:, None] + lb[:, None]).T.copy()
    F = np.array([problem(X[i]) for i in range(nPop)])
    fault = np.zeros(nPop, dtype=int)
    vel = np.zeros((nPop, Dim))

    dom = _determine_domination(F)
    RX, RF = _update_rep([], [], X, F, ~dom)
    RFa = np.array(RF)
    GI = _grid_index(RFa, _create_grid(RFa, nGrid, alpha))
    problem.report(np.array(RX), RFa)

    for it in range(T):
        s = _select_leader(GI, beta, rng)
        flag_x, flag_f = RX[s].copy(), RF[s].copy()
        for i in range(nPop):
            s = _select_leader(GI, beta, rng)
            if _dom(RF[s], flag_f):                                   # Force2Feasible: no-op when CV == 0
                flag_x, flag_f = RX[s].copy(), RF[s].copy()
            dist = np.sqrt(((X[i] - X) ** 2).sum(axis=1))
            dist[i] = np.inf
            q = np.argsort(dist, kind="stable")
            dam = vic = None
            for k in range(nPop):
                if _dom(F[q[k]], F[i]):
                    dam, vic = i, q[k]
                    break
                elif _dom(F[i], F[q[k]]):
                    dam, vic = q[k], i
                    break
            else:
                k = nPop - 1
            if k == nPop - 1:                                         # MATLAB: if (k == nPop)
                if rng.random() > 0.5:
                    dam, vic = i, q[0]
                else:
                    dam, vic = q[0], i
            fault[dam] += 1
            fault[vic] = 0
            if fault[dam] < MaxFault:                                 # MyCrossOverFcnConstraint, Method 4
                R1, R2 = rng.random(Dim), rng.random(Dim)
                x = R1 * flag_x + R2 * (vel[dam] - X[dam])
                off = X[dam] + x
                f_off = problem(off)
                if _dom(f_off, F[dam]):
                    X[dam], vel[dam] = off, x
                # else: position and vel unchanged
            else:
                X[dam] = rng.random(Dim) * (ub - lb) + lb
                fault[dam] = 0
            vic_shrink = bool(np.any(X[vic] < lb) or np.any(X[vic] > ub))
            X[dam] = np.minimum(np.maximum(X[dam], lb), ub)
            X[vic] = np.minimum(np.maximum(X[vic], lb), ub)
            F[dam] = problem(X[dam])
            if vic_shrink:
                F[vic] = problem(X[vic])
            if _dom(F[dam], flag_f):
                flag_x, flag_f = X[dam].copy(), F[dam].copy()
            elif _dom(F[vic], flag_f):
                flag_x, flag_f = X[vic].copy(), F[vic].copy()
            # MutationFcnConstraint / Mutate (mut = 1)
            j = rng.integers(Dim)
            dx = pm * (ub[j] - lb[j])
            lo, hi = max(flag_x[j] - dx, lb[j]), min(flag_x[j] + dx, ub[j])
            if lo > hi:
                lo, hi = lb[j], ub[j]
            xm = flag_x.copy()
            xm[j] = lo + (hi - lo) * rng.random()
            fm = problem(xm)
            if not _dom(flag_f, fm):
                flag_x, flag_f = xm, fm

        s = _select_leader(GI, beta, rng)
        if _dom(RF[s], flag_f):
            flag_x, flag_f = RX[s].copy(), RF[s].copy()
        sdom = _determine_domination(F)
        if not any(np.array_equal(flag_x, rx) for rx in RX):          # updateRep_by_single
            RX.append(flag_x.copy())
            RF.append(flag_f.copy())
        RX, RF = _update_rep(RX, RF, X, F, ~sdom)
        RX, RF, GI = _filter_and_trim(RX, RF, nGrid, alpha, gamma, nRep, rng)
        if it < T - 1:
            problem.report(np.array(RX), np.array(RF))

    if T > 0:
        s = _select_leader(GI, beta, rng)                             # final tamp (unused for the output)
        if len(RX) < nRep:                                            # ComplateRep2
            common = [i for i in range(nPop) if any(np.array_equal(X[i], rx) for rx in RX)]
            unc = np.setdiff1d(np.arange(nPop), common)
            sel_dom = _determine_domination(F[unc]) if len(unc) else np.zeros(0, bool)
            CX, CF = [r.copy() for r in RX], [r.copy() for r in RF]
            CX, CF = _update_rep(CX, CF, X[unc], F[unc], ~sel_dom)
            CX, CF, _ = _filter_and_trim(CX, CF, nGrid, alpha, gamma, nRep, rng)
            problem.report(np.array(CX), np.array(CF))
        else:
            problem.report(np.array(RX), np.array(RF))
    return np.array(RX), np.array(RF)
