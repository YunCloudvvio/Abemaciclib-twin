"""MOSRS - Multi-Objective Special Relativity Search.

Goodarzimehr, V., Pereira, J. L. J., Khodadadi, N. MOSRS: An engineering multi-objective optimization through
Einsteinian concept. PLOS One 20 (2025) e0328005. doi:10.1371/journal.pone.0328005

Reference used: the authors' MATLAB code in this folder (MOSRS.m with its sub-functions; driver MAIN.m;
https://github.com/inimakhan/MOSRS, commit ffe8524). The code is followed where it differs from the paper.

Evaluations: pop_size at initialisation + pop_size per iteration (N + N*T).
Defaults from MAIN.m: pop = 1000, n_iter = 100, ngrid = 10, Nr (archive) = 100.

Quirks of the original code that are reproduced:
- the particle positions POS are NEVER updated: every iteration the new positions are generated from the
  initial positions; only the stored costs POS_fit are replaced (with the costs of the new positions);
- updateRepository(REP, POS, Newcost) stores the OLD positions POS together with the NEW costs Newcost, so the
  archive's decision vectors do not correspond to its objective vectors (the reported X is that archive);
- the charges Qi = abs((f_i - Worst) / (Best - Worst)) use MATLAB's row-vector mrdivide, i.e. the scalar
  least-squares quotient (a.b)/(b.b); Best/Worst are the per-objective min/max of POS_fit (column sort);
- the partner j is jj(1) unless jj(1) == i (then jj(2), which may again equal i); for j == i or Qi == Qj the
  update divides by zero; MATLAB's min/max ignore the resulting NaN (component -> UB), reproduced with
  np.fmin/np.fmax;
- the greedy replacement uses `if sum(mask) > 1` (a single improving particle is ignored); both masks are
  computed before either replacement; the 'random acceptance' mask uses rand(pop,1) >= 0.5 -> rejected;
- archive truncation (deleteFromRepository): crowding from (next - previous)/(max - min) with Inf padding, so
  the minimum of an objective gets -Inf, the maximum +Inf; NaN -> Inf; the n_extra smallest are removed;
- the hypercube grid (updateGrid) is computed by the original but never used (no leader selection), so it
  is omitted here (it consumes no random numbers);
- constraints: the original adds a static penalty 1e15*g^2 for violated constraints; the test problems here
  are unconstrained (constraint.m returns g = geq = []), so the penalty is always 0 and is not implemented.
Per-particle rand calls (randi(pop,1,2), rand(1,d), rand(1,d)) are drawn as arrays (same distribution).
"""
import numpy as np

from sicore.problem import iters_from_fes

C_LIGHT = 299792458.0


def _check_domination(F):
    """checkDomination: dominated if any other member dominates it (exact pairwise)."""
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    return np.any(le & lt, axis=0)


def _delete_from_repository(X, F, n_extra):
    n, M = F.shape
    crowd = np.zeros(n)
    with np.errstate(invalid="ignore", divide="ignore"):
        for m in range(M):
            idx = np.argsort(F[:, m], kind="stable")
            mf = F[idx, m]
            up = np.r_[mf[1:], np.inf]
            down = np.r_[np.inf, mf[:-1]]
            dist = (up - down) / (mf.max() - mf.min())
            inv = np.argsort(idx, kind="stable")
            crowd = crowd + dist[inv]
    crowd[np.isnan(crowd)] = np.inf
    del_idx = np.argsort(crowd, kind="stable")[:n_extra]
    keep = np.ones(n, dtype=bool)
    keep[del_idx] = False
    return X[keep], F[keep]


def _mrdiv_scalar(a, b):
    bb = float(b @ b)
    return 0.0 if bb == 0 else float(a @ b) / bb


def optimize(problem, pop_size=1000, rng=None, max_iter=None, archive_size=100):
    pop, d, LB, UB = pop_size, problem.dim, problem.lb, problem.ub
    T = max_iter if max_iter is not None else iters_from_fes(problem, pop, pop)
    Nr = archive_size

    POS = np.empty((pop, d))
    POS_fit = []
    for i in range(pop):
        POS[i] = LB + (UB - LB) * rng.random(d)
        POS_fit.append(problem(POS[i]))
    POS_fit = np.array(POS_fit)
    Best, Worst = POS_fit.min(axis=0), POS_fit.max(axis=0)
    dom = _check_domination(POS_fit)
    REPx, REPf = POS[~dom].copy(), POS_fit[~dom].copy()
    problem.report(REPx, REPf)

    for t in range(1, T + 1):
        Newpos = np.empty((pop, d))
        mu = (1 - t / T) ** (t / T)
        b = Best - Worst
        for i in range(pop):
            jj = rng.integers(pop, size=2)
            j = jj[1] if jj[0] == i else jj[0]
            R = np.linalg.norm(POS[j] - POS[i])
            Qi = abs(_mrdiv_scalar(POS_fit[i] - Worst, b))
            Qj = abs(_mrdiv_scalar(POS_fit[j] - Worst, b))
            V = np.abs(POS[j] - POS[i])
            beta = V / C_LIGHT
            r1, r2 = rng.random(d), rng.random(d)
            with np.errstate(invalid="ignore", divide="ignore", over="ignore"):
                m = np.float64(Qi - Qj) / np.float64(Qi + Qj)
                wn = (mu * Qj * Qi * V) / (m * R ** 3)
                x = R * np.sin(wn)
                npos = (beta ** 2) * POS[i] + r1 * ((mu * Qi * Qj * V) / (m * R ** 2)) * np.sqrt(1 - beta ** 2) \
                    + r2 * x * np.sqrt(1 - beta ** 2)
                npos = npos + V
            npos = np.fmin(npos, UB)       # MATLAB min/max ignore NaN
            npos = np.fmax(npos, LB)
            Newpos[i] = npos
        Newcost = np.array([problem(Newpos[i]) for i in range(pop)])

        # updateRepository(REP, POS, Newcost): OLD positions with NEW costs
        dom = _check_domination(Newcost)
        REPx = np.r_[REPx, POS[~dom]]
        REPf = np.r_[REPf, Newcost[~dom]]
        dom = _check_domination(REPf)
        REPx, REPf = REPx[~dom], REPf[~dom]
        if len(REPx) > Nr:
            REPx, REPf = _delete_from_repository(REPx, REPf, len(REPx) - Nr)

        pos_best = np.all(Newcost <= POS_fit, axis=1) & np.any(Newcost < POS_fit, axis=1)
        best_pos = ~(np.all(POS_fit <= Newcost, axis=1) & np.any(POS_fit < Newcost, axis=1))
        best_pos[rng.random(pop) >= 0.5] = False
        if pos_best.sum() > 1:
            POS_fit[pos_best] = Newcost[pos_best]
        if best_pos.sum() > 1:
            POS_fit[best_pos] = Newcost[best_pos]
        # (the original also writes Newpos(mask,:) = POS(mask,:); Newpos is never read afterwards)
        Best, Worst = POS_fit.min(axis=0), POS_fit.max(axis=0)
        problem.report(REPx, REPf)
    return REPx, REPf
