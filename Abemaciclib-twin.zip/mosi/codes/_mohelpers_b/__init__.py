"""Shared multi-objective helpers for shard IMB (MOSI M201-M230). Owned by shard IMB; other shards: do not edit.

Import from an impl.py with:
    import os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    from _mohelpers_b import nd_sort, ...
Every helper is a faithful port of a widely copied MATLAB routine (source named in its docstring).
MATLAB randi/randperm/rand draws are replaced by the equivalent numpy Generator draws (same distribution).
"""
from __future__ import annotations

import itertools
import math

import numpy as np


# ----------------------------------------------------------------------------------------------------------
# Dominance, non-dominated sorting (PlatEMO NDSort), crowding distance (PlatEMO CrowdingDistance)
# ----------------------------------------------------------------------------------------------------------
def dominates(a, b):
    """all(a <= b) and any(a < b) (minimisation)."""
    return bool(np.all(a <= b) and np.any(a < b))


def dom_matrix(F):
    """D[i, j] = True when row i dominates row j."""
    F = np.asarray(F, dtype=float)
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    return le & lt


def nd_sort(F, n_sort=math.inf):
    """PlatEMO NDSort(PopObj, nSort) (ENS-SS / T-ENS give identical results).

    Returns (FrontNo, MaxFNo): FrontNo is a float array (inf for solutions not sorted); fronts are assigned
    until at least min(n_sort, N) solutions are sorted. Identical objective vectors share a front.
    """
    F = np.asarray(F, dtype=float)
    N = len(F)
    U, loc = np.unique(F, axis=0, return_inverse=True)
    loc = np.asarray(loc).ravel()
    table = np.bincount(loc, minlength=len(U))
    D = dom_matrix(U)
    front = np.full(len(U), np.inf)
    maxf = 0
    target = min(n_sort, N)
    while table[np.isfinite(front)].sum() < target:
        maxf += 1
        rem = ~np.isfinite(front)
        idx = np.flatnonzero(rem)
        dominated = D[np.ix_(idx, idx)].any(axis=0)
        front[idx[~dominated]] = maxf
    return front[loc], maxf


def nd_front_all(F):
    """Full non-dominated sorting (all solutions get a front number)."""
    return nd_sort(F, math.inf)[0]


def crowding_distance_platemo(F, front_no=None):
    """PlatEMO CrowdingDistance(PopObj, FrontNo): per-front, normalised by (fmax - fmin) of the front,
    boundary solutions get inf. Solutions with front_no == inf get 0 (as in PlatEMO: CrowdDis initialised 0
    and only finite fronts processed)."""
    F = np.asarray(F, dtype=float)
    N, M = F.shape
    if front_no is None:
        front_no = np.ones(N)
    cd = np.zeros(N)
    for f in np.unique(front_no[np.isfinite(front_no)]):
        fr = np.flatnonzero(front_no == f)
        fmax = F[fr].max(axis=0)
        fmin = F[fr].min(axis=0)
        for i in range(M):
            rank = np.argsort(F[fr, i], kind="stable")  # MATLAB sortrows(PopObj(Front,i)) is stable
            cd[fr[rank[0]]] = np.inf
            cd[fr[rank[-1]]] = np.inf
            for j in range(1, len(fr) - 1):
                cd[fr[rank[j]]] += (F[fr[rank[j + 1]], i] - F[fr[rank[j - 1]], i]) / (fmax[i] - fmin[i])
    return cd


# ----------------------------------------------------------------------------------------------------------
# NSGA-III machinery (PlatEMO UniformPoint and EnvironmentalSelection/LastSelection, 2018-era version)
# ----------------------------------------------------------------------------------------------------------
def _nchoosek_rows(n, k):
    return np.array(list(itertools.combinations(range(1, n + 1), k)), dtype=float).reshape(-1, k)


def uniform_point(N, M):
    """PlatEMO UniformPoint(N, M) (Das-Dennis, two layers when H1 < M). Returns (W, N)."""
    H1 = 1
    while math.comb(H1 + M, M - 1) <= N:
        H1 += 1
    W = _nchoosek_rows(H1 + M - 1, M - 1) - np.arange(M - 1) - 1
    W = (np.c_[W, np.zeros(len(W)) + H1] - np.c_[np.zeros(len(W)), W]) / H1
    if H1 < M:
        H2 = 0
        while math.comb(H1 + M - 1, M - 1) + math.comb(H2 + M, M - 1) <= N:
            H2 += 1
        if H2 > 0:
            W2 = _nchoosek_rows(H2 + M - 1, M - 1) - np.arange(M - 1) - 1
            W2 = (np.c_[W2, np.zeros(len(W2)) + H2] - np.c_[np.zeros(len(W2)), W2]) / H2
            W = np.r_[W, W2 / 2 + 1 / (2 * M)]
    W = np.maximum(W, 1e-6)
    return W, len(W)


def nsga3_last_selection(PopObj1, PopObj2, K, Z, Zmin, rng):
    """PlatEMO NSGA-III LastSelection: returns a boolean mask over PopObj2 with K selected.

    Notes: the hyperplane solve uses numpy; when the extreme-point matrix is exactly singular numpy raises
    (MATLAB would warn and return Inf/NaN) -> treated as NaN intercepts -> fallback to the max (as PlatEMO's
    isnan branch). sqrt(1 - cos^2) is clipped at 0 (MATLAB would return a tiny complex number)."""
    PopObj = np.r_[PopObj1, PopObj2] - Zmin
    N, M = PopObj.shape
    N1 = len(PopObj1)
    NZ = len(Z)
    w = np.zeros((M, M)) + 1e-6 + np.eye(M)
    extreme = np.array([int(np.argmin(np.max(PopObj / w[i], axis=1))) for i in range(M)])
    try:
        hyper = np.linalg.solve(PopObj[extreme], np.ones(M))
        with np.errstate(divide="ignore"):
            a = 1.0 / hyper
    except np.linalg.LinAlgError:
        a = np.full(M, np.nan)
    if np.any(np.isnan(a)):
        a = PopObj.max(axis=0)
    PopObj = PopObj / a
    nrm = np.sqrt((PopObj ** 2).sum(axis=1))
    znrm = np.sqrt((Z ** 2).sum(axis=1))
    with np.errstate(invalid="ignore", divide="ignore"):
        cosine = (PopObj @ Z.T) / np.outer(nrm, znrm)
    distance = nrm[:, None] * np.sqrt(np.maximum(1 - cosine ** 2, 0))
    pi = np.argmin(distance, axis=1)
    d = distance[np.arange(N), pi]
    rho = np.bincount(pi[:N1], minlength=NZ).astype(float)
    choose = np.zeros(len(PopObj2), dtype=bool)
    zchoose = np.ones(NZ, dtype=bool)
    pi2 = pi[N1:]
    while choose.sum() < K:
        temp = np.flatnonzero(zchoose)
        jmin = np.flatnonzero(rho[temp] == rho[temp].min())
        j = temp[jmin[rng.integers(len(jmin))]]
        I = np.flatnonzero(~choose & (pi2 == j))
        if I.size:
            if rho[j] == 0:
                v = d[N1 + I]
                s = 0 if np.all(np.isnan(v)) else int(np.nanargmin(v))   # MATLAB min ignores NaN
            else:
                s = int(rng.integers(len(I)))
            choose[I[s]] = True
            rho[j] += 1
        else:
            zchoose[j] = False
    return choose


def nsga3_env_selection(F, N, Z, Zmin, rng):
    """PlatEMO NSGA-III EnvironmentalSelection without constraints: returns the sorted indices (original
    order) of the N selected rows of F."""
    F = np.asarray(F, dtype=float)
    front, maxf = nd_sort(F, N)
    nxt = front < maxf
    last = np.flatnonzero(front == maxf)
    ch = nsga3_last_selection(F[nxt], F[last], N - int(nxt.sum()), Z, Zmin, rng)
    nxt[last[ch]] = True
    return np.flatnonzero(nxt)


# ----------------------------------------------------------------------------------------------------------
# MOPSO/MOGWO grid archive (Mirjalili's MOGWO/MOALO code: DetermineDomination, CreateHypercubes,
# GetGridIndex, GetOccupiedCells, RouletteWheelSelection, SelectLeader, DeleteFromRep)
# ----------------------------------------------------------------------------------------------------------
def determine_domination(F):
    """MOGWO DetermineDomination: sequential loop with its exact visiting order (returns 'Dominated' flags)."""
    F = np.asarray(F, dtype=float)
    n = len(F)
    D = dom_matrix(F)
    dominated = np.zeros(n, dtype=bool)
    for i in range(n):
        for j in range(i):
            if not dominated[j]:
                if D[i, j]:
                    dominated[j] = True
                elif D[j, i]:
                    dominated[i] = True
                    break
    return dominated


def create_hypercubes(F, ngrid, alpha):
    """MOGWO CreateHypercubes(costs, nGrid, alpha); F has one row per solution. Returns the list of
    'Upper' arrays (Lower is not used by GetGridIndex)."""
    F = np.asarray(F, dtype=float)
    G = []
    for j in range(F.shape[1]):
        mn, mx = F[:, j].min(), F[:, j].max()
        dc = alpha * (mx - mn)
        gx = np.linspace(mn - dc, mx + dc, ngrid - 1)
        G.append(np.r_[gx, np.inf])
    return G


def grid_index(F, G):
    """MOGWO GetGridIndex for every row: Index = sub2ind(ngrid*ones(1,nobj), SubIndex) (1-based)."""
    F = np.atleast_2d(np.asarray(F, dtype=float))
    ngrid = len(G[0])
    idx = np.zeros(len(F), dtype=np.int64)
    sub = np.zeros(F.shape, dtype=np.int64)
    for j, U in enumerate(G):
        # find(c(j) < U, 1, 'first') (1-based)
        s = np.argmax(F[:, j][:, None] < U[None, :], axis=1) + 1
        sub[:, j] = s
        idx += (s - 1) * ngrid ** j
    return idx + 1, sub


def roulette_wheel(p, rng):
    """MOGWO RouletteWheelSelection: r = rand; first i with r <= cumsum(p)(i) (0-based result)."""
    r = rng.random()
    c = np.cumsum(p)
    i = int(np.searchsorted(c, r, side="left"))
    return min(i, len(c) - 1)


def occupied_cells(gidx):
    """MOGWO GetOccupiedCells: unique (sorted) cell indices and their member counts."""
    occ, cnt = np.unique(gidx, return_counts=True)
    return occ, cnt.astype(float)


def select_leader(gidx, beta, rng):
    """MOGWO SelectLeader: roulette over occupied cells with p ~ count^-beta, then a uniform member.
    Returns the 0-based position in the archive."""
    occ, cnt = occupied_cells(gidx)
    p = cnt ** (-beta)
    p = p / p.sum()
    cell = occ[roulette_wheel(p, rng)]
    members = np.flatnonzero(gidx == cell)
    return int(members[rng.integers(len(members))])


def delete_from_rep(gidx, extra, gamma, rng):
    """MOGWO DeleteFromRep: removes 'extra' members one by one (roulette p ~ count^gamma, uniform member).
    Returns the kept 0-based positions in their original order."""
    keep = np.arange(len(gidx))
    g = np.asarray(gidx).copy()
    for _ in range(extra):
        occ, cnt = occupied_cells(g)
        p = cnt ** gamma
        p = p / p.sum()
        cell = occ[roulette_wheel(p, rng)]
        members = np.flatnonzero(g == cell)
        j = members[rng.integers(len(members))]
        keep = np.delete(keep, j)
        g = np.delete(g, j)
    return keep


# ----------------------------------------------------------------------------------------------------------
# Misc
# ----------------------------------------------------------------------------------------------------------
def levy_mantegna(rng, shape, beta=1.5):
    """Mantegna Levy steps: u ~ N(0, sigma_u), v ~ N(0, 1), z = u / |v|^(1/beta)."""
    num = math.gamma(1 + beta) * math.sin(math.pi * beta / 2)
    den = math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2)
    sigma_u = (num / den) ** (1 / beta)
    u = rng.normal(0.0, sigma_u, shape)
    v = rng.normal(0.0, 1.0, shape)
    return u / np.abs(v) ** (1 / beta)


def clip_matlab(X, lb, ub):
    """Flag4ub/Flag4lb style bound handling: out-of-range components set to the violated bound."""
    return np.minimum(np.maximum(X, lb), ub)


# ----------------------------------------------------------------------------------------------------------
# Deb fast non-dominated sorting with the exact front ordering of the Kalita/Jangir NDS+CD codes
# (MOEDO NonDominatedSorting.m) and their crowding distance (normalised by the range of the WHOLE set)
# ----------------------------------------------------------------------------------------------------------
def nd_sort_deb(F):
    """Port of MOEDO NonDominatedSorting.m. Returns a list of fronts (0-based index arrays) in the
    original's member order: front 1 in increasing index order, later fronts in discovery order."""
    F = np.asarray(F, dtype=float)
    n = len(F)
    D = dom_matrix(F)
    cnt = D.sum(axis=0).astype(int)          # n{i}: number of solutions dominating i
    S = [np.flatnonzero(D[i]) for i in range(n)]
    cur = [i for i in range(n) if cnt[i] == 0]
    fronts = []
    while cur:
        fronts.append(np.array(cur, dtype=int))
        Q = []
        for i in cur:
            for j in S[i]:
                cnt[j] -= 1
                if cnt[j] == 0:
                    Q.append(j)
        cur = Q
    return fronts


def crowding_distance_global(F, fronts):
    """Port of MOEDO CrowdingDistance.m: per front, boundary solutions inf, intermediate ones accumulate
    (F[next]-F[prev]) / (max(F[:,m]) - min(F[:,m])) with max/min over ALL rows of F (not the front);
    fronts with <= 2 members get inf. Sorting is MATLAB's stable sort."""
    F = np.asarray(F, dtype=float)
    dist = np.zeros(len(F))
    rng_m = F.max(axis=0) - F.min(axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        for front in fronts:
            k = len(front)
            if k > 2:
                dist[front] = 0.0
                for m in range(F.shape[1]):
                    sf = front[np.argsort(F[front, m], kind="stable")]
                    dist[sf[0]] = np.inf
                    dist[sf[-1]] = np.inf
                    for i in range(1, k - 1):
                        dist[sf[i]] = dist[sf[i]] + (F[sf[i + 1], m] - F[sf[i - 1], m]) / rng_m[m]
            else:
                dist[front] = np.inf
    return dist


def matlab_sort_desc_order(x):
    """Index order of MATLAB [~,I] = sort(-x) (stable ascending of -x; NaN placed last)."""
    y = -np.asarray(x, dtype=float)
    nan = np.isnan(y)
    idx = np.argsort(np.where(nan, np.inf, y), kind="stable")
    return np.r_[idx[~nan[idx]], idx[nan[idx]]]


def nsgaii_truncate(fronts, dist, size):
    """Port of MOEDO UpdateArchiveUsingNSGAII.m: fill front by front, each front ordered by descending
    crowding distance (stable); the overflowing front is cut. Returns the selected 0-based indices in order."""
    out = []
    for front in fronts:
        front = front[matlab_sort_desc_order(dist[front])]
        if len(front) + len(out) <= size:
            out.extend(front.tolist())
        else:
            out.extend(front[: size - len(out)].tolist())
            break
    return np.array(out, dtype=int)


def nds_cd_select(F, size):
    """Elitist NDS + crowding-distance truncation of the Kalita/Jangir group (MOEDO code: NonDominatedSorting,
    CrowdingDistance with whole-set normalisation, UpdateArchiveUsingNSGAII). Returns selected 0-based indices
    in the selection order (front by front, descending crowding distance)."""
    F = np.asarray(F, dtype=float)
    fronts = nd_sort_deb(F)
    dist = crowding_distance_global(F, fronts)
    return nsgaii_truncate(fronts, dist, size)


def first_front_mask(F):
    """Boolean mask of the non-dominated rows of F (duplicates are kept: they do not dominate each other)."""
    D = dom_matrix(F)
    return ~D.any(axis=0)


def clip_bounds(X, lb, ub):
    return np.minimum(np.maximum(X, lb), ub)


def unique_rows(X, *others):
    """MATLAB unique(X,'rows'): lexicographically sorted unique rows; extra arrays are reordered alongside."""
    X = np.asarray(X, dtype=float)
    order = np.lexsort(X.T[::-1])
    Xs = X[order]
    keep = np.ones(len(Xs), dtype=bool)
    keep[1:] = np.any(Xs[1:] != Xs[:-1], axis=1)
    return (Xs[keep],) + tuple(np.asarray(o)[order][keep] for o in others)


def mao_paper_template(problem, pop_size, rng, max_iter, make_offspring, iters_from_fes):
    """Many-objective framework of the Kalita/Jangir 'MaO-<base>' papers as written in the papers (Sect. 3):
    N0 random solutions -> Das-Dennis reference points Z (N = |Z| from UniformPoint(N0, M)) -> NSGA-III
    selection of N; then per iteration Q_t = make_offspring(PX, PF, it, T, rng, state) (N new solutions, each
    evaluated once), R_t = unique(P_t U Q_t), running ideal point, NSGA-III selection -> P_{t+1}.
    The output (report) is P_t. Returns (PX, PF). Evaluations: N0 + N*T."""
    N0, lb, ub = pop_size, problem.lb, problem.ub
    D = problem.dim
    X = lb + rng.random((N0, D)) * (ub - lb)
    F = np.array([problem(x) for x in X])
    M = F.shape[1]
    Z, N = uniform_point(N0, M)
    T = max_iter if max_iter is not None else iters_from_fes(problem, N, N0)
    Zmin = F.min(axis=0)
    sel = nsga3_env_selection(F, N, Z, Zmin, rng)
    PX, PF = X[sel], F[sel]
    problem.report(PX, PF)
    state = {}
    for it in range(1, T + 1):
        Q = make_offspring(PX, PF, it, T, rng, state)
        QF = np.array([problem(x) for x in Q])
        Zmin = np.minimum(Zmin, QF.min(axis=0))
        RX, RF = unique_rows(np.r_[PX, Q], np.r_[PF, QF])
        sel = nsga3_env_selection(RF, N, Z, Zmin, rng)
        PX, PF = RX[sel], RF[sel]
        problem.report(PX, PF)
    return PX, PF


# ----------------------------------------------------------------------------------------------------------
# PlatEMO MOPSO archive routines (UpdateArchive with grid-based deletion, REPSelection) and PlatEMO's
# RouletteWheelSelection (probability proportional to 1/fitness)
# ----------------------------------------------------------------------------------------------------------
def _grid_sites(F, div):
    F = np.asarray(F, dtype=float)
    fmax, fmin = F.max(axis=0), F.min(axis=0)
    d = (fmax - fmin) / div
    with np.errstate(divide="ignore", invalid="ignore"):
        g = np.floor((F - fmin) / d)
    g[g >= div] = div - 1
    g[np.isnan(g)] = 0
    _, site = np.unique(g, axis=0, return_inverse=True)
    site = np.asarray(site).ravel()
    return site, np.bincount(site).astype(float)


def platemo_roulette(n, fitness, rng):
    """PlatEMO RouletteWheelSelection(N, Fitness): index i chosen with probability ~ 1/Fitness(i)."""
    f = np.asarray(fitness, dtype=float).ravel()
    f = f + min(f.min(), 0)
    c = np.cumsum(1.0 / f)
    c = c / c.max()
    r = rng.random(n)
    return np.searchsorted(c, r, side="left")


def platemo_mopso_update_archive(F, N, div, rng):
    """PlatEMO MOPSO UpdateArchive: keep the first front; if larger than N delete members one by one from the
    most crowded grid cell (random cell among ties, random member). Returns kept 0-based indices."""
    F = np.asarray(F, dtype=float)
    front, _ = nd_sort(F, 1)
    idx = np.flatnonzero(front == 1)
    if len(idx) > N:
        site, crowd = _grid_sites(F[idx], div)
        site = site.astype(float)
        dele = np.zeros(len(idx), dtype=bool)
        while dele.sum() < len(idx) - N:
            maxg = np.flatnonzero(crowd == crowd.max())
            g = maxg[rng.integers(len(maxg))]
            ing = np.flatnonzero(site == g)
            p = ing[rng.integers(len(ing))]
            dele[p] = True
            site[p] = np.nan
            crowd[g] -= 1
        idx = idx[~dele]
    return idx


def platemo_rep_selection(F, n, div, rng):
    """PlatEMO MOPSO REPSelection: n leaders, grid cell by roulette on 1/crowding, then a random member."""
    site, crowd = _grid_sites(F, div)
    cells = platemo_roulette(n, crowd, rng)
    out = np.empty(n, dtype=int)
    for i, g in enumerate(cells):
        ing = np.flatnonzero(site == g)
        out[i] = ing[rng.integers(len(ing))]
    return out


# ----------------------------------------------------------------------------------------------------------
# PlatEMO SPEA2 environmental selection (CalFitness + Truncation), as used by CMOPSO-style algorithms
# ----------------------------------------------------------------------------------------------------------
def spea2_fitness(F):
    F = np.asarray(F, dtype=float)
    N = len(F)
    Dm = dom_matrix(F)
    S = Dm.sum(axis=1)
    R = np.array([S[Dm[:, i]].sum() for i in range(N)], dtype=float)
    dist = np.sqrt(((F[:, None, :] - F[None, :, :]) ** 2).sum(-1))
    np.fill_diagonal(dist, np.inf)
    dist = np.sort(dist, axis=1)
    k = max(int(np.floor(np.sqrt(N))), 1)
    Dn = 1.0 / (dist[:, k - 1] + 2)
    return R + Dn


def spea2_selection(F, N):
    """PlatEMO SPEA2 EnvironmentalSelection: returns selected 0-based indices sorted by fitness (stable)."""
    F = np.asarray(F, dtype=float)
    fit = spea2_fitness(F)
    nxt = fit < 1
    if nxt.sum() < N:
        rank = np.argsort(fit, kind="stable")
        nxt[rank[:N]] = True
    elif nxt.sum() > N:
        idx = np.flatnonzero(nxt)
        P = F[idx]
        dist = np.sqrt(((P[:, None, :] - P[None, :, :]) ** 2).sum(-1))
        np.fill_diagonal(dist, np.inf)
        dele = np.zeros(len(idx), dtype=bool)
        while dele.sum() < len(idx) - N:
            remain = np.flatnonzero(~dele)
            temp = np.sort(dist[np.ix_(remain, remain)], axis=1)
            order = np.lexsort(temp.T[::-1])          # sortrows
            dele[remain[order[0]]] = True
        nxt[idx[dele]] = False
    sel = np.flatnonzero(nxt)
    return sel[np.argsort(fit[sel], kind="stable")]
