"""Global sensitivity analysis of the twin.

Variance-based (Sobol) indices of the three objectives under the standard policy
(150 mg twice daily, label rules) and under TRADE-like escalation, and of the
difference escalation - standard, which is what H1 is about. Population: first-line
MONARCH 3 setting (problem P1) with the stage-3 parameters.

Input ranges (log-uniform):
  calibrated parameters      point estimate / 1.5 to x 1.5 (rule fractions: odds / 1.5 to x 1.5)
  Chigutsa 2026 parameters   bootstrap 95% CI of the paper (Tables 1 and 2)
  neutrophil system          mean transit time 109-135 h (Evans 2018 pooled value to the upper
                             Friberg 2002 estimate), feedback exponent 0.103-0.23
Estimators: Saltelli 2010 (first order) and Jansen (total), Sobol' sequence, bootstrap CIs.
Common random numbers: the same virtual patients and random numbers for every sample.

Run from the project root:
    python scripts/sobol_twin.py --structure time
Writes calibration/sobol_<structure>.json.
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
from scipy.stats import qmc

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from twin import kernel as K  # noqa: E402
from twin import params as P  # noqa: E402
from twin import population as pm  # noqa: E402
from twin import trials as T  # noqa: E402
from calibrate_stage12 import STRUCTURE, apply_parameters, toxicity_constants  # noqa: E402

CALIBRATED = ["anc_slope", "anc_slope_cv", "q01", "q12", "q23", "tolerance", "beta",
              "g2_rule_frac", "anc3_rule_frac", "oth_red", "oth_disc", "oth_k"]
LITERATURE = {   # name: (low, high, typical)
    "e_abe": (0.0259, 0.0661, P.TS_E_ABE),
    "hz_conc": (0.820, 2.34, P.HZ_CONC),
    "hz_cfb": (0.00660, 0.0328, P.HZ_CFB),
    "anc_mtt_h": (109.0, 135.0, P.ANC_MTT_H),
    "anc_gamma": (0.103, 0.23, P.ANC_GAMMA),
}
STAGE3 = ["e_ai", "hazard_mult"]
FACTOR = 1.5
OUTPUTS = ["std_f1", "std_f2", "std_f3", "esc_f1", "esc_f2", "esc_f3", "d_f1", "d_f2", "d_f3"]


def ranges(tox, stage3):
    names, lo, hi = [], [], []
    for n in CALIBRATED:
        v = tox[n]
        if n.endswith("_frac"):
            odds = v / (1 - v)
            names.append(n), lo.append(math.log(odds / FACTOR)), hi.append(math.log(odds * FACTOR))
        else:
            names.append(n), lo.append(math.log(v / FACTOR)), hi.append(math.log(v * FACTOR))
    for n, (a, b, _) in LITERATURE.items():
        names.append(n), lo.append(math.log(a)), hi.append(math.log(b))
    for n in STAGE3:
        v = stage3[n]
        names.append(n), lo.append(math.log(v / FACTOR)), hi.append(math.log(v * FACTOR))
    return names, np.array(lo), np.array(hi)


def decode(names, x):
    out = {}
    for n, v in zip(names, x):
        if n.endswith("_frac"):
            odds = math.exp(v)
            out[n] = odds / (1 + odds)
        else:
            out[n] = math.exp(v)
    return out


class Model:
    def __init__(self, n, tox, stage3, structure, seed=8001):
        self.n = n
        self.structure = structure
        self.stage3 = stage3
        self.base = T.monarch3_population(n, seed, e_ai=stage3["e_ai"], hazard_mult=stage3["hazard_mult"])
        self.base[:, pm.C_START_LEVEL] = 0.0      # the policy sets the starting dose
        rng = np.random.default_rng(seed + 2)
        self.u_g2 = rng.random(n)
        self.u_anc3 = rng.random(n)
        self.threshold, self.u = pm.sample_noise(n, T.N_DAYS, seed + 1)
        self.cbc = pm.cbc_schedule(T.N_DAYS)
        self.policies = {"std": K.standard_policy(), "esc": T.trade_policy()}

    def __call__(self, p):
        tox = dict(p)
        pop = apply_parameters(self.base, tox)
        pop[:, pm.C_G2_STRICT] = self.u_g2 < p["g2_rule_frac"]
        pop[:, pm.C_ANC3_STRICT] = self.u_anc3 < p["anc3_rule_frac"]
        pop[:, pm.C_E_ABE] *= p["e_abe"] / P.TS_E_ABE
        pop[:, pm.C_HZ_CONC] = p["hz_conc"]
        pop[:, pm.C_HZ_CFB] *= p["hz_cfb"] / P.HZ_CFB
        pop[:, pm.C_KTR] *= P.ANC_MTT_H / p["anc_mtt_h"]
        pop[:, pm.C_GAMMA] = p["anc_gamma"]
        pop[:, pm.C_E_ET] *= p["e_ai"] / self.stage3["e_ai"]
        pop[:, pm.C_HZ_BASE] *= p["hazard_mult"] / self.stage3["hazard_mult"]
        dcon = toxicity_constants(tox, self.structure)
        res = {}
        for tag, theta in self.policies.items():
            out = np.zeros((self.n, K.N_OUT))
            K.simulate(theta, pop, self.threshold, self.u, self.cbc, dcon, pm.pk_constants(), T.N_DAYS, out,
                       K.NO_TRACE)
            f1, f2, f3 = K.objectives(out)
            res[f"{tag}_f1"], res[f"{tag}_f2"], res[f"{tag}_f3"] = -f1, f2, f3   # RMST in months (higher better)
        for j in (1, 2, 3):
            res[f"d_f{j}"] = res[f"esc_f{j}"] - res[f"std_f{j}"]
        return np.array([res[o] for o in OUTPUTS])


def indices(fa, fb, fab, n_boot=500, seed=0):
    """fa, fb: (N, m); fab: (k, N, m). Returns first-order and total indices with 95% CIs."""
    rng = np.random.default_rng(seed)
    n = fa.shape[0]

    def est(idx):
        a, b, ab = fa[idx], fb[idx], fab[:, idx]
        var = np.var(np.concatenate([a, b]), axis=0)
        var = np.where(var > 0, var, np.nan)
        s1 = np.mean(b[None] * (ab - a[None]), axis=1) / var
        st = 0.5 * np.mean((a[None] - ab) ** 2, axis=1) / var
        return s1, st

    s1, st = est(np.arange(n))
    boots = [est(rng.integers(0, n, n)) for _ in range(n_boot)]
    s1_ci = np.percentile([b[0] for b in boots], [2.5, 97.5], axis=0)
    st_ci = np.percentile([b[1] for b in boots], [2.5, 97.5], axis=0)
    return s1, st, s1_ci, st_ci


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--structure", choices=["time", "exposure"], default="time")
    ap.add_argument("--n-patients", type=int, default=2000)
    ap.add_argument("--n-base", type=int, default=1024)
    args = ap.parse_args()
    with open(f"calibration/stage12_{args.structure}.json", encoding="utf-8") as f:
        tox = json.load(f)["parameters"]
    with open(f"calibration/stage3_{args.structure}.json", encoding="utf-8") as f:
        stage3 = json.load(f)["parameters"]
    names, lo, hi = ranges(tox, stage3)
    k = len(names)
    model = Model(args.n_patients, tox, stage3, STRUCTURE[args.structure])

    sampler = qmc.Sobol(d=2 * k, scramble=True, seed=8101)
    u = sampler.random(args.n_base)
    a = lo + u[:, :k] * (hi - lo)
    b = lo + u[:, k:] * (hi - lo)
    t0 = time.perf_counter()
    fa = np.array([model(decode(names, x)) for x in a])
    fb = np.array([model(decode(names, x)) for x in b])
    fab = np.empty((k, args.n_base, len(OUTPUTS)))
    for i in range(k):
        ab = a.copy()
        ab[:, i] = b[:, i]
        fab[i] = np.array([model(decode(names, x)) for x in ab])
        print(f"  parameter {i + 1}/{k} ({names[i]}) done, {time.perf_counter() - t0:.0f} s", flush=True)
    s1, st, s1_ci, st_ci = indices(fa, fb, fab)

    point = model(decode(names, (lo + hi) / 2))
    report = {"structure": args.structure, "n_patients": args.n_patients, "n_base": args.n_base,
              "n_model_runs": int(args.n_base * (k + 2)), "parameters": names,
              "ranges": {n: [float(math.exp(l)), float(math.exp(h))] if not n.endswith("_frac") else
                         [float(1 / (1 + math.exp(-l))), float(1 / (1 + math.exp(-h)))]
                         for n, l, h in zip(names, lo, hi)},
              "outputs": {}}
    allf = np.concatenate([fa, fb])
    for j, o in enumerate(OUTPUTS):
        report["outputs"][o] = {
            "mean": float(allf[:, j].mean()), "sd": float(allf[:, j].std()),
            "p05_p95": [float(v) for v in np.percentile(allf[:, j], [5, 95])],
            "at_centre": float(point[j]),
            "first_order": {n: [round(float(s1[i, j]), 4), round(float(s1_ci[0, i, j]), 4), round(float(s1_ci[1, i, j]), 4)]
                            for i, n in enumerate(names)},
            "total": {n: [round(float(st[i, j]), 4), round(float(st_ci[0, i, j]), 4), round(float(st_ci[1, i, j]), 4)]
                      for i, n in enumerate(names)},
        }
    with open(f"calibration/sobol_{args.structure}.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    for o in OUTPUTS:
        r = report["outputs"][o]
        top = sorted(r["total"].items(), key=lambda kv: -kv[1][0])[:5]
        print(f"{o}: mean {r['mean']:.3f} (5-95% {r['p05_p95'][0]:.3f} to {r['p05_p95'][1]:.3f}); top total: "
              + ", ".join(f"{n} {v[0]:.2f}" for n, v in top))
    print(f"{time.perf_counter() - t0:.0f} s")


if __name__ == "__main__":
    main()
