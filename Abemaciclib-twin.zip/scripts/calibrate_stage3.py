"""Stage 3 of the calibration: first-line (MONARCH 3) efficacy.

Two parameters are fitted on the control arm (non-steroidal aromatase inhibitor alone), where
abemaciclib plays no role:
  e_ai         shrinkage effect of the aromatase inhibitor (1/week), constrained by the confirmed ORR
  hazard_mult  first-line multiplier of the baseline progression hazard, constrained by
               the median PFS (Kaplan-Meier, progression seen at the scheduled scans)
Everything else (abemaciclib effect, waning, hazard model) is kept from Chigutsa 2026.
The abemaciclib arm (median PFS 28.18 months, confirmed ORR 55.4%) is then predicted
without further fitting, with the stage 1-2 toxicity parameters, as a held-out check.

Run from the project root:
    python scripts/calibrate_stage3.py --toxicity calibration/stage12_time.json
Writes calibration/stage3_<structure>.json.
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from twin import cmaes  # noqa: E402
from twin import kernel as K  # noqa: E402
from twin import params as P  # noqa: E402
from twin import population as pm  # noqa: E402
from twin import trials as T  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from calibrate_stage12 import STRUCTURE, apply_parameters, toxicity_constants  # noqa: E402

N_DAYS = T.N_DAYS_EFFICACY


def arm(n, seed, e_ai, hazard_mult, control, tox=None, structure=K.TOL_TIME):
    pop = T.monarch3_population(n, seed, e_ai=e_ai, hazard_mult=hazard_mult, control_arm=control)
    noise = pm.sample_noise(n, N_DAYS, seed + 1)
    cbc = T.trial_cbc_schedule(N_DAYS, day15=False)
    if control:
        out = T.run(pop, noise, cbc, pm.diarrhoea_constants(), n_days=N_DAYS, theta=T.no_abemaciclib_policy())
    else:
        rng = np.random.default_rng(seed + 2)
        pop = apply_parameters(pop, tox)
        pop[:, pm.C_G2_STRICT] = rng.random(n) < tox["g2_rule_frac"]
        pop[:, pm.C_ANC3_STRICT] = rng.random(n) < tox["anc3_rule_frac"]
        dcon = toxicity_constants(tox, structure)
        out = T.run(pop, noise, cbc, dcon, n_days=N_DAYS)
    obs, event = T.observed_pfs_days(out[:, K.O_PFS_DAYS], "monarch3", N_DAYS)
    return {"median_pfs_months": T.km_median_months(obs, event), "orr_confirmed": T.confirmed_orr(out, pop),
            "pfs_12m": 100.0 * float(np.mean(obs > 12 * P.DAYS_PER_MONTH)),
            "pfs_24m": 100.0 * float(np.mean(obs > 24 * P.DAYS_PER_MONTH))}, out


def monarch2_arms(n, seed, tox, structure):
    """Reproduction check of the Chigutsa 2026 model on its own trial (both arms)."""
    res = {}
    noise = pm.sample_noise(n, N_DAYS, seed + 1)
    cbc = T.trial_cbc_schedule(N_DAYS)
    for name in ("monarch2", "monarch2_control"):
        if name == "monarch2":
            pop = apply_parameters(T.monarch2_population(n, seed, tox.get("m2_force_median", T.MEDIAN_DAYS_ON_200MG)), tox)
            rng = np.random.default_rng(seed + 2)
            pop[:, pm.C_G2_STRICT] = rng.random(n) < tox["g2_rule_frac"]
            pop[:, pm.C_ANC3_STRICT] = rng.random(n) < tox["anc3_rule_frac"]
            dcon = toxicity_constants(tox, structure)
            out = T.run(pop, noise, cbc, dcon, n_days=N_DAYS)
        else:
            pop = T.monarch2_control_population(n, seed)
            out = T.run(pop, noise, cbc, pm.diarrhoea_constants(), n_days=N_DAYS, theta=T.no_abemaciclib_policy())
        obs, event = T.observed_pfs_days(out[:, K.O_PFS_DAYS], "monarch2", N_DAYS)
        res[name] = {"simulated": {"median_pfs_months": T.km_median_months(obs, event),
                                   "orr_confirmed": T.confirmed_orr(out, pop)},
                     "target": {"median_pfs_months": T.TARGETS[name]["median_pfs_months"],
                                "orr_confirmed": T.ORR_TARGETS[name]}}
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--toxicity", default=None, help="stage 1-2 result (json); initial values if omitted")
    ap.add_argument("--n-fit", type=int, default=5000)
    ap.add_argument("--n-check", type=int, default=20000)
    ap.add_argument("--evals", type=int, default=200)
    args = ap.parse_args()

    if args.toxicity:
        with open(args.toxicity, encoding="utf-8") as f:
            stage12 = json.load(f)
        tox, structure_name = stage12["parameters"], stage12["structure"]
    else:
        tox = {"anc_slope": P.ANC_SLOPE, "anc_slope_cv": P.ANC_CV_SLOPE, "q01": P.DI_Q_UP_PER_DAY[0],
               "q12": P.DI_Q_UP_PER_DAY[1], "q23": P.DI_Q_UP_PER_DAY[2], "tolerance": P.DI_KH_PER_DAY,
               "beta": P.DI_BETA, "g2_rule_frac": 1.0, "anc3_rule_frac": 1.0,
               "oth_red": P.OTH_RED_PER_DAY, "oth_disc": P.OTH_DISC_PER_DAY, "oth_k": P.OTH_K_PER_DAY}
        structure_name = "time"
        print("WARNING: initial toxicity parameters", flush=True)
    structure = STRUCTURE[structure_name]

    target_pfs = T.TARGETS["monarch3_control"]["median_pfs_months"]
    target_orr = T.ORR_TARGETS["monarch3_control"]
    n_orr = T.ORR_N["monarch3_control"]
    se_orr = math.sqrt(target_orr * (100.0 - target_orr) / n_orr)

    def loss(x):
        sim, _ = arm(args.n_fit, 6101, math.exp(x[0]), math.exp(x[1]), True)
        if math.isnan(sim["median_pfs_months"]):
            return 1e3
        return ((sim["median_pfs_months"] - target_pfs) / 0.5) ** 2 + ((sim["orr_confirmed"] - target_orr) / se_orr) ** 2

    t0 = time.perf_counter()
    lower, upper = np.log([1e-4, 0.1]), np.log([0.2, 5.0])
    es = cmaes.minimize(loss, np.log([P.TS_E_FULV, 1.0]), 0.5, lower, upper, args.evals, popsize=8, seed=61)
    e_ai, hazard_mult = (float(v) for v in np.exp(es.best_x))
    print(f"fit: e_ai {e_ai:.4g} /week, hazard_mult {hazard_mult:.4g}, loss {es.best_f:.3f}, "
          f"{es.evals} evaluations, {time.perf_counter() - t0:.0f} s", flush=True)

    control, _ = arm(args.n_check, 6201, e_ai, hazard_mult, True)
    combo, out = arm(args.n_check, 6301, e_ai, hazard_mult, False, tox, structure)
    report = {
        "structure": structure_name, "toxicity_source": args.toxicity,
        "parameters": {"e_ai": e_ai, "hazard_mult": hazard_mult}, "fit_loss": es.best_f,
        "control_fit": {"simulated": control, "target": {"median_pfs_months": target_pfs, "orr_confirmed": target_orr}},
        "abemaciclib_heldout": {"simulated": combo,
                                "target": {"median_pfs_months": T.TARGETS["monarch3"]["median_pfs_months"],
                                           "median_pfs_ci": [23.5, None],
                                           "orr_confirmed": T.ORR_TARGETS["monarch3"]}},
        "abemaciclib_toxicity": T.summarize(out, "monarch3", N_DAYS),
        "monarch2_reproduction": monarch2_arms(args.n_check, 6401, tox, structure),
    }
    os.makedirs("calibration", exist_ok=True)
    path = f"calibration/stage3_{structure_name}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(json.dumps({k: report[k] for k in ("parameters", "control_fit", "abemaciclib_heldout",
                                             "monarch2_reproduction")}, indent=2))


if __name__ == "__main__":
    main()
