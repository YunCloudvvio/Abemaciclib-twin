"""Task list of the scenario analysis (E4): P1, the top-3 algorithms of the comparison (E2), 10 runs per scenario.

Seeds 3,000,001-3,000,010 are those of the main experiment, so the base cell of every comparison is the
main experiment itself (same patients and random numbers) and the scenarios differ only in the factor
changed.  python scripts/make_e4_tasks.py --algs A B C --out results_e4/tasks.txt
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from make_tasks import MOEA, MOSI, SEED0  # noqa: E402
from twin.scenarios import SCENARIOS  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--algs", nargs=3, required=True)
    ap.add_argument("--runs", type=int, default=10)
    ap.add_argument("--out", default="results_e4/tasks.txt")
    args = ap.parse_args()
    for a in args.algs:
        if a not in MOEA + MOSI:
            raise SystemExit(f"unknown algorithm {a}")
    scen = [s for s in SCENARIOS if s != "base"] + ["exposure"]
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    n = 0
    with open(args.out, "w") as f:
        for k in range(1, args.runs + 1):
            for s in scen:
                for a in args.algs:
                    f.write(f"{s} {'moea' if a in MOEA else 'mosi'} {a} {SEED0 + k}\n")
                    n += 1
    print(f"{n} tasks ({len(scen)} scenarios) -> {args.out}")


if __name__ == "__main__":
    main()
