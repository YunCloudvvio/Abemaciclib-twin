"""Twin ensemble: M = 20 toxicity parameter sets.

Candidates are the archived CMA-ES evaluations inside the approximate 95% likelihood-ratio
region: loss <= L_min + chi2_0.95(p), the loss being the sum of squared standardised residuals
and p the number of calibrated parameters. (Requiring every target inside its published CI
proved too brittle: with structurally conflicting targets the best fits sit at CI edges and
flip with Monte Carlo noise.) Selection is greedy maximin in the transformed
parameter space (log, logit), started from the best candidate, so the ensemble spans the
region the data cannot pin down. Every selected set is re-checked on fresh virtual
patients with the same rule (fresh loss <= fresh loss of the best set + chi2_0.95(p)); a set
that fails there is dropped and the next farthest candidate (measured from the kept members
only) is tried. Per-target CI coverage is reported for every member.
The ensemble then gives prediction ranges for the held-out settings (MONARCH 3 toxicity,
TRADE, monarchE).

Run from the project root:
    python scripts/select_ensemble.py --structure time
Writes calibration/ensemble_<structure>.json.
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
from scipy.stats import chi2

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from twin import population as pm  # noqa: E402
from twin import trials as T  # noqa: E402
import calibrate_stage12 as C  # noqa: E402

M = 20
HELD = {
    "monarch3": ["anc3_lab", "diar_any", "diar_g2", "diar_g3", "diar_onset_days", "held_diar", "reduced_diar",
                 "held_anc", "reduced_anc", "reduced_ae", "discontinued"],
    "trade": list(T.TRADE_TARGETS.keys() - {"n"}),
    "monarche": ["anc3_lab", "diar_any", "diar_g3", "held_diar", "held_anc", "reduced_diar", "reduced_anc",
                 "reduced_ae", "discontinued"],
}


def transform(names, x):
    rows = {r[0]: r[4] for r in C.PARAMETERS}
    return np.array([[C.forward(v, rows[n]) for n, v in zip(names, xi)] for xi in x])


def held_out(par, structure, n):
    res = {}
    s3 = C.Setting("monarch3", n, 905)
    res["monarch3"] = T.summarize(s3.simulate(par, structure), "monarch3")
    pop = C.apply_parameters(pm.sample_patients(n, 906), par)
    rng = np.random.default_rng(908)
    pop[:, pm.C_G2_STRICT] = rng.random(n) < par["g2_rule_frac"]
    pop[:, pm.C_ANC3_STRICT] = rng.random(n) < par["anc3_rule_frac"]
    _, u = pm.sample_noise(n, T.TRADE_DAYS, 907)
    dcon = C.toxicity_constants(par, structure)
    res["trade"] = T.run_trade(pop, u, dcon)
    pop = C.apply_parameters(T.monarche_population(n, 909), par)
    rng = np.random.default_rng(911)
    pop[:, pm.C_G2_STRICT] = rng.random(n) < par["g2_rule_frac"]
    pop[:, pm.C_ANC3_STRICT] = rng.random(n) < par["anc3_rule_frac"]
    _, u = pm.sample_noise(n, T.N_DAYS, 910)
    res["monarche"] = T.summarize(T.run_monarche(pop, u, dcon))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--structure", choices=["time", "exposure"], default="time")
    ap.add_argument("--n-check", type=int, default=5000)
    args = ap.parse_args()
    structure = C.STRUCTURE[args.structure]
    arc = np.load(f"calibration/stage12_{args.structure}_archive.npz")
    names = [str(n) for n in arc["names"]]
    delta = float(chi2.ppf(0.95, len(names)))
    l_min = float(arc["loss"].min())
    ok = arc["loss"] <= l_min + delta
    x, loss = arc["x"][ok], arc["loss"][ok]
    print(f"{ok.sum()} of {ok.size} inside the region (L_min {l_min:.2f} + {delta:.2f})", flush=True)
    order = np.argsort(loss)
    x, loss = x[order], loss[order]
    z = transform(names, x)
    z = (z - z.mean(axis=0)) / np.where(z.std(axis=0) > 0, z.std(axis=0), 1.0)

    check = [C.Setting("monarch1", args.n_check, 901), C.Setting("monarch2", args.n_check, 902)]

    def fresh(par):
        summaries = {s.name: s.summary(par, structure)[0] for s in check}
        res, in_ci = C.residuals(summaries)
        return float(np.sum(res ** 2)), in_ci
    ref_loss, _ = fresh(dict(zip(names, (float(v) for v in x[0]))))
    print(f"fresh loss of the best set {ref_loss:.2f}; threshold {ref_loss + delta:.2f}", flush=True)
    chosen, rejected = [], []
    fresh_info = {}
    dist = np.full(len(x), np.inf)
    candidate = 0
    t0 = time.perf_counter()
    max_tries = 400                                   # fresh checks are cheap but not free
    while len(chosen) < M and len(chosen) + len(rejected) < min(len(x), max_tries):
        par = dict(zip(names, (float(v) for v in x[candidate])))
        f_loss, in_ci = fresh(par)
        accepted = f_loss <= ref_loss + delta
        (chosen if accepted else rejected).append(candidate)
        fresh_info[candidate] = (f_loss, in_ci)
        if accepted:                                  # only ensemble members push the next choice away
            dist = np.minimum(dist, np.linalg.norm(z - z[candidate], axis=1))
        dist[chosen + rejected] = -1.0
        if not chosen:                                # nothing kept yet: take the next best by loss
            dist[:] = -1.0
            free = np.setdiff1d(np.arange(len(x)), rejected)
            dist[free[0]] = 1.0
        candidate = int(np.argmax(dist))
        print(f"  candidate {len(chosen) + len(rejected):3d}: loss {loss[chosen[-1] if accepted else rejected[-1]]:.2f} "
              f"{'kept' if accepted else 'failed fresh check'} ({len(chosen)} kept, {time.perf_counter() - t0:.0f} s)",
              flush=True)

    members = []
    for idx in chosen:
        par = dict(zip(names, (float(v) for v in x[idx])))
        members.append({"parameters": par, "fit_loss": float(loss[idx]), "fresh_loss": fresh_info[idx][0],
                        "all_targets_in_ci_fresh": bool(fresh_info[idx][1]),
                        "held_out": held_out(par, structure, args.n_check)})
    ranges = {}
    for trial, keys in HELD.items():
        tgt = T.TRADE_TARGETS if trial == "trade" else T.TARGETS[trial]
        ranges[trial] = {}
        for k in keys:
            vals = np.array([m["held_out"][trial][k] for m in members])
            ranges[trial][k] = {"min": float(vals.min()), "median": float(np.median(vals)), "max": float(vals.max()),
                                "target": tgt.get(k)}
    report = {"structure": args.structure, "region": {"l_min": l_min, "delta_chi2_95": delta, "n_params": len(names)},
              "fresh_reference_loss": ref_loss, "n_candidates_in_region": int(ok.sum()), "n_members": len(members),
              "n_failed_fresh_check": len(rejected), "members": members, "held_out_ranges": ranges}
    with open(f"calibration/ensemble_{args.structure}.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"\n{len(members)} members ({len(rejected)} failed the fresh check)")
    for trial, rows in ranges.items():
        print(f"\n{trial} (ensemble min / median / max vs target)")
        for k, r in rows.items():
            print(f"  {k:20s} {r['min']:6.1f} {r['median']:6.1f} {r['max']:6.1f}   target {r['target']}")


if __name__ == "__main__":
    main()
