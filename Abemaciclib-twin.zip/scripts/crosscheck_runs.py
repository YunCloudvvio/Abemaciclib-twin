"""End-to-end check: re-evaluate decision vectors stored by finished runs directly in Python and compare
with the objectives/constraints the run recorded (PlatEMO .mat via the pipe, MOSI .npz via si_runner).

Run from the project root:  python scripts/crosscheck_runs.py results [rows per file]
"""
import glob
import os
import sys

import numpy as np
from scipy.io import loadmat

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from twin import problems  # noqa: E402


def main():
    res_dir = sys.argv[1]
    k = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    worst = 0.0
    n_files = 0
    bad_runs = []
    for f in sorted(glob.glob(os.path.join(res_dir, "*", "P*", "*", "seed*.*"))):
        if f.endswith(".log") or ".tmp" in f or ".tv." in f or ".failed." in f:
            continue
        struct, inst_name, alg, name = f.split(os.sep)[-4:]
        seed = int(name[4:].split(".")[0])
        if f.endswith(".mat"):
            d = loadmat(f)
            X, F, G = d["Dec"], d["Obj"], d["Con"]
            fe = d["ckpt_FE"].ravel()
            cX = [np.asarray(c) for c in d["ckpt_Dec"].ravel()]
            cF = [np.asarray(c) for c in d["ckpt_Obj"].ravel()]
            cG = [np.asarray(c) for c in d["ckpt_Con"].ravel()]
            n_fe = int(d["info"]["FE"][0][0][0][0])
        else:
            d = np.load(f)
            X, F, G = d["X"], d["F"], d["G"]
            fe = d["ckpt_fe"]
            cX = [d["ckpt_X"][d["ckpt_id"] == i] for i in range(len(fe))]
            cF = [d["ckpt_F"][d["ckpt_id"] == i] for i in range(len(fe))]
            cG = [d["ckpt_G"][d["ckpt_id"] == i] for i in range(len(fe))]
            n_fe = int(d["fes"])
        problems_found = []
        if len(fe) != 20:
            problems_found.append(f"{len(fe)} checkpoints")
        if np.any(np.diff(fe) < 0):
            problems_found.append("checkpoint evaluations not increasing")
        if not (np.array_equal(cX[-1], X) and np.array_equal(cF[-1], F) and np.array_equal(cG[-1], G)):
            problems_found.append("last checkpoint differs from the final set")
        bad_runs.extend(f"{f}: {p}" for p in problems_found)
        mid = len(cX) // 2                              # also re-evaluate a middle checkpoint
        X = np.concatenate([X, cX[mid]]) if len(cX[mid]) else X
        F = np.concatenate([F, cF[mid]]) if len(cF[mid]) else F
        G = np.concatenate([G, cG[mid]]) if len(cG[mid]) else G
        inst = problems.Instance(os.path.join(ROOT, "calibration", f"ensemble_{struct}.json"),
                                 os.path.join(ROOT, "calibration", f"stage3_{struct}.json"), seed, name=inst_name)
        rows = np.linspace(0, len(X) - 1, min(k, len(X))).astype(int)
        F2, G2 = inst.evaluate(X[rows])
        diff = max(float(np.max(np.abs(F2 - F[rows]))), float(np.max(np.abs(G2 - G[rows]))))
        worst = max(worst, diff)
        n_files += 1
        print(f"{inst_name} {alg:12s} seed {seed}: FE {n_fe}, checkpoints {len(fe)} "
              f"(FE {int(fe[0])}..{int(fe[-1])}), {len(rows)} rows checked, max |difference| {diff:.3g}")
    print(f"{n_files} files, worst difference {worst:.3g}")
    print("structural problems:", bad_runs if bad_runs else "none")


if __name__ == "__main__":
    main()
