"""Figures of the paper (Times New Roman everywhere):
  python scripts/analysis/figures.py --analysis analysis --out paper/figures
Reads analysis/metrics_<inst>.pkl, analysis/e3_P1.pkl and calibration/*.json; every number plotted comes from
those files (no values typed in by hand except the published trial targets, which are read from twin/trials.py).
"""
import argparse
import json
import os
import pickle
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from collect import ALGS, MOEA  # noqa: E402

for f in font_manager.findSystemFonts(os.path.expanduser("~/.local/share/fonts")):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "Times New Roman", "font.size": 9, "axes.titlesize": 10,
                     "axes.labelsize": 9, "legend.fontsize": 8, "mathtext.fontset": "stix",
                     "savefig.dpi": 300, "savefig.bbox": "tight"})

NAMES = {"SPEA2": "SPEA2", "NSGAII": "NSGA-II", "GDE3": "GDE3", "MOEADDE": "MOEA/D-DE", "NSGAIII": "NSGA-III",
         "AGEMOEAII": "AGE-MOEA-II", "LMPFE": "LMPFE", "CMOES": "CMOES", "APSEA": "APSEA", "CMOCEADDAP": "CMOCEA-DDAP",
         "M001_MOGWO": "MOGWO", "M004_MSSA": "MSSA", "M014_MOAVOA": "MOAVOA", "M103_MOCGO": "MOCGO",
         "M105_MOEOSMA": "MOEOSMA", "M212_MOGNDO": "MOGNDO", "M231_MORIME": "MORIME", "M306_MaOMPA": "MaOMPA",
         "M315_MOSRS": "MOSRS", "M323_C-MOBRO": "C-MOBRO"}
C_MOEA, C_MOSI = "#3B6EA8", "#C0504D"
INSTANCES = ["P1", "P2", "P3", "P4"]


def load(analysis, inst):
    with open(os.path.join(analysis, f"metrics_{inst}.pkl"), "rb") as fh:
        return pickle.load(fh)


def fig_hv_box(analysis, out):
    fig, axes = plt.subplots(4, 1, figsize=(7.2, 9.0), sharex=True)
    for ax, inst in zip(axes, INSTANCES):
        m = load(analysis, inst)
        data = [[p["hv_test"] for p in m["per_run"] if p["alg"] == a] for a in ALGS]
        bp = ax.boxplot(data, widths=0.6, patch_artist=True, showfliers=True,
                        flierprops={"markersize": 2}, medianprops={"color": "black", "linewidth": 0.8})
        for k, b in enumerate(bp["boxes"]):
            b.set_facecolor(C_MOEA if ALGS[k] in MOEA else C_MOSI)
            b.set_alpha(0.75)
        ax.set_ylabel(f"{inst}: test HV")
        ax.axvline(10.5, color="grey", linewidth=0.6, linestyle=":")
    axes[-1].set_xticks(range(1, len(ALGS) + 1))
    axes[-1].set_xticklabels([NAMES[a] for a in ALGS], rotation=60, ha="right")
    handles = [plt.Rectangle((0, 0), 1, 1, color=C_MOEA, alpha=0.75), plt.Rectangle((0, 0), 1, 1, color=C_MOSI, alpha=0.75)]
    axes[0].legend(handles, ["MOEA", "MOSI"], loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, frameon=False)
    fig.savefig(os.path.join(out, "fig_hv_box.pdf"))
    fig.savefig(os.path.join(out, "fig_hv_box.png"))
    plt.close(fig)


def fig_convergence(analysis, out):
    # leading algorithms (best mean HV ranks), the best MOSI algorithms and MOGNDO in color; all others in grey
    highlight = {"CMOES": "#0072B2", "CMOCEADDAP": "#D55E00", "GDE3": "#009E73", "APSEA": "#CC79A7",
                 "M103_MOCGO": "#E69F00", "M231_MORIME": "#56B4E9", "M212_MOGNDO": "#000000"}
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 6.0), sharex=True)
    for ax, inst in zip(axes.ravel(), INSTANCES):
        m = load(analysis, inst)
        for a in [a for a in ALGS if a not in highlight] + [a for a in ALGS if a in highlight]:
            rows = [p for p in m["per_run"] if p["alg"] == a]
            hv = np.array([p["curve"] for p in rows])
            fe = np.array([p["curve_fe"] for p in rows])
            x, y = np.median(fe, axis=0), np.median(hv, axis=0)
            if a in highlight:
                ax.plot(x, y, color=highlight[a], linewidth=1.3, linestyle="-" if a in MOEA else "--",
                        label=NAMES[a] + ("" if a in MOEA else " (MOSI)"), zorder=3)
            else:
                ax.plot(x, y, color="#BBBBBB", linewidth=0.8, linestyle="-" if a in MOEA else "--",
                        label="Other MOEAs" if a in MOEA else "Other MOSI algorithms", zorder=1)
        ax.set_title(inst)
        ax.set_ylabel("Median HV, optimization batch")
        ax.set_xlabel("Function evaluations")
    h, l = axes[0, 0].get_legend_handles_labels()
    seen, hh, ll = set(), [], []
    for hi, li in zip(h, l):
        if li not in seen:
            seen.add(li), hh.append(hi), ll.append(li)
    order = [ll.index(NAMES[a] + ("" if a in MOEA else " (MOSI)")) for a in highlight] + \
            [ll.index(x) for x in ("Other MOEAs", "Other MOSI algorithms")]
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    fig.legend([hh[i] for i in order], [ll[i] for i in order], ncol=5, fontsize=7, frameon=False,
               loc="lower center", bbox_to_anchor=(0.5, 0.0))
    fig.savefig(os.path.join(out, "fig_convergence.pdf"))
    fig.savefig(os.path.join(out, "fig_convergence.png"))
    plt.close(fig)


def fig_front(analysis, out, inst="P1"):
    m = load(analysis, inst)
    with open(os.path.join(analysis, f"e3_{inst}.pkl"), "rb") as fh:
        e3 = pickle.load(fh)
    R = m["ref_front"].copy()
    R[:, 0] = -R[:, 0]                                   # RMST (months)
    R[:, 1] = 100 * R[:, 1]                              # %
    lab = ["RMST (months)", "Grade $\\geq$3 neutropenia (%)", "Grade $\\geq$2 diarrhea days (first 6 months)"]
    pairs = [(2, 0), (1, 0), (2, 1)]
    marks = {"standard": ("s", "black", "Label regimen"), "trade": ("^", "#2E7D32", "TRADE-like escalation"),
             "knee": ("o", "#F39C12", "Knee policy"), "dominating": ("D", "#8E44AD", "Dominating policy")}
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.9))
    for ax, (i, j) in zip(axes, pairs):
        sc = ax.scatter(R[:, i], R[:, j], c=R[:, 3 - i - j], s=6, cmap="viridis", linewidths=0)
        for name, (mk, col, text) in marks.items():
            if name in e3["representatives"]:
                f = np.array(e3["representatives"][name]["objectives"], dtype=float)
                f = np.array([-f[0], 100 * f[1], f[2]])
                ax.scatter(f[i], f[j], marker=mk, s=38, facecolors="none" if name != "standard" else col,
                           edgecolors=col, linewidths=1.0, label=text, zorder=3)
        ax.set_xlabel(lab[i])
        ax.set_ylabel(lab[j])
        cb = fig.colorbar(sc, ax=ax, fraction=0.05, pad=0.02)
        cb.set_label(lab[3 - i - j], fontsize=7)
    h, l = axes[0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    fig.legend(h, l, ncol=4, fontsize=7, frameon=False, loc="lower center", bbox_to_anchor=(0.5, 0.0))
    fig.savefig(os.path.join(out, f"fig_front_{inst}.pdf"))
    fig.savefig(os.path.join(out, f"fig_front_{inst}.png"))
    plt.close(fig)


def fig_trajectories(analysis, out, inst="P1"):
    with open(os.path.join(analysis, f"e3_{inst}.pkl"), "rb") as fh:
        e3 = pickle.load(fh)
    style = {"standard": ("black", "-", "Label regimen"), "trade": ("#2E7D32", "--", "TRADE-like escalation"),
             "knee": ("#F39C12", "-.", "Knee policy"), "dominating": ("#8E44AD", ":", "Dominating policy")}
    panels = [("mean_dose", "Mean dose given (mg twice daily)"), ("on_hold", "Fraction withheld or discontinued"),
              ("mean_anc", "Mean ANC ($10^9$/L)"), ("diar2", "Fraction with grade $\\geq$2 diarrhea")]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.0), sharex=True)
    for ax, (key, ylab) in zip(axes.ravel(), panels):
        for name, (col, ls, text) in style.items():
            if name in e3["curves"]:
                y = e3["curves"][name][key]
                ax.plot(np.arange(1, len(y) + 1) / 30.4375, y, color=col, linestyle=ls, linewidth=1.0, label=text)
        ax.set_ylabel(ylab)
        ax.set_xlim(0, 24)
    for ax in axes[-1]:
        ax.set_xlabel("Months since first dose")
    axes[0, 0].legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(out, f"fig_trajectories_{inst}.pdf"))
    fig.savefig(os.path.join(out, f"fig_trajectories_{inst}.png"))
    plt.close(fig)


LABELS = {"anc3_lab": "grade $\\geq$3 neutropenia (laboratory)", "diar_any": "diarrhea, any grade",
          "diar_g2": "diarrhea, worst grade 2", "diar_g3": "diarrhea, grade 3", "held_diar": "withheld for diarrhea",
          "reduced_diar": "reduced for diarrhea", "held_anc": "withheld for neutropenia",
          "reduced_anc": "reduced for neutropenia", "reduced_ae": "reduced for any adverse reaction",
          "discontinued": "discontinued", "reduced_w12": "reduced by week 12", "reduced_w24": "reduced by week 24",
          "not_reached_w12": "150 mg not reached by week 12", "not_reached_w24": "150 mg never reached by week 24",
          "discontinued_w12": "discontinued by week 12", "discontinued_w24": "discontinued by week 24",
          "diar_g2plus_w24": "grade $\\geq$2 diarrhea by week 24", "diar_g3_w24": "grade 3 diarrhea by week 24",
          "maintained_150_w12": "150 mg reached and kept, week 12", "maintained_150_w24": "150 mg reached and kept, week 24",
          "anc3_w24": "grade $\\geq$3 neutropenia by week 24"}


def trial_literals():
    """TARGETS and TRADE_TARGETS of twin/trials.py, read as literals (that module needs numba)."""
    import ast
    tree = ast.parse(open(os.path.join(ROOT, "twin", "trials.py"), encoding="utf-8").read())
    found = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and \
                node.targets[0].id in ("TARGETS", "TRADE_TARGETS"):
            found[node.targets[0].id] = ast.literal_eval(node.value)
    return found["TARGETS"], found["TRADE_TARGETS"]


def fig_validation(out, structure="time"):
    """Held-out checks: ensemble range (bar) versus trial value (dot) with its 95% CI where binomial."""
    with open(os.path.join(ROOT, "calibration", f"ensemble_{structure}.json"), encoding="utf-8") as fh:
        ens = json.load(fh)["held_out_ranges"]
    targets, trade = trial_literals()
    n_trial = {"monarch3": targets["monarch3"]["n"], "trade": trade["n"], "monarche": targets["monarche"]["n"]}
    labels, lo, hi, med, tgt, ci = [], [], [], [], [], []
    for trial, rows in ens.items():
        for k, r in rows.items():
            if r["target"] is None or k.endswith("_days"):
                continue
            labels.append(f"{ {'monarch3': 'MONARCH 3', 'trade': 'TRADE', 'monarche': 'monarchE'}[trial]}: {LABELS.get(k, k)}")
            lo.append(r["min"]), hi.append(r["max"]), med.append(r["median"]), tgt.append(r["target"])
            p, n = r["target"] / 100.0, n_trial[trial]
            ci.append(196.0 * np.sqrt(p * (1 - p) / n))
    y = np.arange(len(labels))[::-1]
    fig, ax = plt.subplots(figsize=(7.2, 0.22 * len(labels) + 0.8))
    ax.hlines(y, lo, hi, color="#3B6EA8", linewidth=4, alpha=0.6, label="Twin ensemble (20 members): range")
    ax.plot(med, y, "|", color="#3B6EA8", markersize=8)
    ax.errorbar(tgt, y, xerr=ci, fmt="o", color="black", markersize=3, elinewidth=0.8, capsize=2,
                label="Trial value and 95% CI")
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=7)
    ax.set_xlabel("Percentage of patients")
    ax.legend(fontsize=7, frameon=False, loc="lower right")
    fig.savefig(os.path.join(out, "fig_validation.pdf"))
    fig.savefig(os.path.join(out, "fig_validation.png"))
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--analysis", default="analysis")
    ap.add_argument("--out", default="paper/figures")
    ap.add_argument("--only", nargs="*", default=None)
    ap.add_argument("--instances", nargs="+", default=["P1", "P2", "P3", "P4"])
    args = ap.parse_args()
    if args.instances != INSTANCES:
        raise SystemExit("the HV and convergence figures are laid out for the four instances P1-P4")
    os.makedirs(args.out, exist_ok=True)
    jobs = {"hv": lambda: fig_hv_box(args.analysis, args.out), "conv": lambda: fig_convergence(args.analysis, args.out),
            "front": lambda: fig_front(args.analysis, args.out), "traj": lambda: fig_trajectories(args.analysis, args.out),
            "valid": lambda: fig_validation(args.out)}
    for k, f in jobs.items():
        if args.only is None or k in args.only:
            f()
            print("figure", k, "done")


if __name__ == "__main__":
    main()
