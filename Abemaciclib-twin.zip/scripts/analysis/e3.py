"""E3: clinical interpretation of the P1 fronts on the test population.

For one instance (main analysis P1, time-based diarrhoea tolerance):
1. position of the standard policy (150 mg twice daily with the label rules) and of the TRADE-like policy
   relative to the reference front (analysis/metrics_<inst>.pkl, test population);
2. test-feasible final policies that dominate the standard policy (all three objectives no worse, at least
   one better), from all runs of all algorithms;
3. representative policies of the reference front: the knee point (smallest Euclidean distance to the ideal
   point in the normalised objective space), the best policy for each objective, and among the policies
   dominating the standard policy the one with the largest smallest normalised improvement;
4. paired per-patient comparisons with the standard policy on the test population, with 95% bootstrap
   confidence intervals (2,000 resamples of patients): RMST, P(true grade >= 3 neutropenia), grade >= 2
   diarrhoea days in 6 months; plus clinical indicators (median PFS, detected grade >= 3 neutropenia,
   grade >= 2 diarrhoea incidence, median relative dose intensity, any dose reduction, discontinuation);
5. robustness: the same policies re-evaluated with the cumulative-exposure tolerance ensemble (H1 must hold
   under both structures);
6. daily population curves for the dose-trajectory figure (mean dose, fraction withheld, mean ANC, fraction
   with grade >= 2 diarrhoea) from per-patient traces of a subsample.
Usage:  python scripts/analysis/e3.py --inst P1
Writes analysis/e3_<inst>.pkl (read by scripts/analysis/figures.py and the tables).
"""
import argparse
import os
import pickle
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from twin import kernel as K  # noqa: E402
from twin import params as P  # noqa: E402
from twin import problems  # noqa: E402
from test_eval import TEST_SEED  # noqa: E402

N_BOOT = 2000


def theta_of(inst_name, x):
    return problems.decode_schedule(x) if inst_name == "P3" else problems.decode(x)


def per_patient(inst, x):
    out = inst._simulate(theta_of(inst.name, x))
    pfs_m = out[:, K.O_PFS_DAYS] / P.DAYS_PER_MONTH
    return {"rmst": pfs_m, "anc3": out[:, K.O_ANC3].astype(float), "diar": out[:, K.O_DIAR_DAYS_6M],
            "anc3_det": out[:, K.O_ANC3_DETECTED].astype(float), "diar_any2": (out[:, K.O_MAX_DIAR] >= 2).astype(float),
            "rdi": out[:, K.O_RDI], "reduced": (out[:, K.O_N_RED] > 0).astype(float),
            "disc": out[:, K.O_DISCONTINUED].astype(float), "pfs_days": out[:, K.O_PFS_DAYS],
            "anc4": out[:, K.O_ANC4].astype(float)}


def summary(pp):
    return {"rmst": float(pp["rmst"].mean()), "median_pfs": float(np.median(pp["pfs_days"]) / P.DAYS_PER_MONTH),
            "anc3_true": float(pp["anc3"].mean()), "anc3_detected": float(pp["anc3_det"].mean()),
            "anc4_true": float(pp["anc4"].mean()), "diar_days": float(pp["diar"].mean()),
            "diar_incidence": float(pp["diar_any2"].mean()), "median_rdi": float(np.median(pp["rdi"])),
            "reduced": float(pp["reduced"].mean()), "discontinued": float(pp["disc"].mean())}


def paired_ci(a, b, rng):
    """Mean difference a - b with a 95% bootstrap CI over patients (paired)."""
    d = a - b
    idx = rng.integers(0, len(d), (N_BOOT, len(d)))
    boot = d[idx].mean(axis=1)
    return float(d.mean()), float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))


def daily_curves(inst, x, n_patients=2000, n_days=None):
    """Population curves from per-patient traces (the kernel traces patient 0 of each call)."""
    n_days = inst.n_days if n_days is None else n_days
    theta = theta_of(inst.name, x)
    rows = []
    for pop, thr, u, dcon in inst.groups:
        for i in range(min(len(pop), max(1, n_patients // len(inst.groups)))):
            out = np.zeros((1, K.N_OUT))
            trace = np.zeros((n_days, K.N_TRACE))
            K.simulate(theta, pop[i:i + 1], thr[i:i + 1], u[i:i + 1], inst.cbc, dcon, inst.pkcon, n_days, out, trace)
            alive = np.arange(n_days) < out[0, K.O_PFS_DAYS]          # until progression
            rows.append((trace, alive))
    dose = np.array([np.where(a, t[:, K.TR_LEVEL] * K.DOSE_PER_LEVEL * (1 - t[:, K.TR_ON_HOLD]), np.nan) for t, a in rows])
    hold = np.array([np.where(a, t[:, K.TR_ON_HOLD], np.nan) for t, a in rows])
    anc = np.array([np.where(a, t[:, K.TR_ANC], np.nan) for t, a in rows])
    diar = np.array([np.where(a, t[:, K.TR_GRADE] >= 2, np.nan) for t, a in rows])
    with np.errstate(invalid="ignore"):
        return {"mean_dose": np.nanmean(dose, axis=0), "on_hold": np.nanmean(hold, axis=0),
                "mean_anc": np.nanmean(anc, axis=0), "diar2": np.nanmean(diar, axis=0),
                "n_progression_free": np.sum(~np.isnan(dose), axis=0)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inst", default="P1", choices=problems.INSTANCES)
    ap.add_argument("--analysis", default=os.path.join(ROOT, "analysis"))
    ap.add_argument("--n-per-member", type=int, default=500)
    args = ap.parse_args()
    with open(os.path.join(args.analysis, f"metrics_{args.inst}.pkl"), "rb") as fh:
        met = pickle.load(fh)
    with open(os.path.join(args.analysis, f"test_{args.inst}.pkl"), "rb") as fh:
        test = pickle.load(fh)
    Pol, F, G = test["policies"], test["F"], test["G"]
    std, trade = test["standard"], test["trade"]
    find = {x.tobytes(): i for i, x in enumerate(Pol)}
    i_std, i_trade = find[np.asarray(std, float).tobytes()], find[np.asarray(trade, float).tobytes()]
    # candidates: policies found by the runs; the standard and TRADE-like policies are only located
    with open(os.path.join(args.analysis, f"runs_{args.inst}.pkl"), "rb") as fh:
        runs = pickle.load(fh)
    found = {np.asarray(x, float).tobytes() for r in runs for x in r["X"]}
    from_run = np.array([x.tobytes() in found for x in np.asarray(Pol, float)])
    feas = np.all(G <= 0, axis=1) & from_run
    ideal, nadir = met["ideal"], met["nadir"]
    span = np.where(nadir > ideal, nadir - ideal, 1.0)
    norm = (F - ideal) / span
    f_std = F[i_std]
    dom = feas & np.all(F <= f_std, axis=1) & np.any(F < f_std, axis=1)
    # representative policies among the test-feasible non-dominated policies found by the runs
    nd_mask = np.zeros(len(F), bool)
    cand = np.nonzero(feas)[0]
    Fc = F[cand]
    for k, j in enumerate(cand):
        nd_mask[j] = not np.any(np.all(Fc <= Fc[k], axis=1) & np.any(Fc < Fc[k], axis=1))
    nd_idx = np.nonzero(nd_mask)[0]
    reps = {"knee": int(nd_idx[np.argmin(np.linalg.norm(norm[nd_idx], axis=1))]),
            "best_f1": int(nd_idx[np.argmin(F[nd_idx, 0])]),
            "best_f2": int(nd_idx[np.argmin(F[nd_idx, 1])]),
            "best_f3": int(nd_idx[np.argmin(F[nd_idx, 2])])}
    if dom.any():
        di = np.nonzero(dom)[0]
        gain = (f_std - F[di]) / span                       # normalised improvements, >= 0
        reps["dominating"] = int(di[np.argmax(gain.min(axis=1))])
    reps["standard"], reps["trade"] = i_std, i_trade
    rng = np.random.default_rng(20261114)
    res = {"inst": args.inst, "n_policies": int(from_run.sum()), "n_feasible": int(feas.sum()), "n_nd": len(nd_idx),
           "standard_found_by_a_run": bool(from_run[i_std]), "trade_found_by_a_run": bool(from_run[i_trade]),
           "n_dominating_standard": int(dom.sum()), "standard_obj": f_std.tolist(), "trade_obj": F[i_trade].tolist(),
           "trade_feasible": bool(np.all(G[i_trade] <= 0)), "trade_dominated_by_nd": bool(np.any(np.all(F[nd_idx] <= F[i_trade], axis=1)
                                                                                      & np.any(F[nd_idx] < F[i_trade], axis=1))),
           "standard_dominated_by_nd": bool(dom.any()), "representatives": {}, "robustness": {}, "curves": {}}
    struct_insts = {}
    for struct in ("time", "exposure"):
        struct_insts[struct] = problems.Instance(os.path.join(ROOT, "calibration", f"ensemble_{struct}.json"),
                                                 os.path.join(ROOT, "calibration", f"stage3_{struct}.json"),
                                                 TEST_SEED, n_per_member=args.n_per_member, name=args.inst)
    base = {s: per_patient(struct_insts[s], std) for s in struct_insts}
    for name, j in reps.items():
        x = Pol[j]
        entry = {"policy": x.tolist(), "objectives": F[j].tolist(), "constraints": G[j].tolist()}
        for s, inst in struct_insts.items():
            pp = per_patient(inst, x)
            entry[s] = {"summary": summary(pp),
                        "diff_vs_standard": {k: paired_ci(pp[k], base[s][k], rng) for k in ("rmst", "anc3", "diar")}}
            Fs, Gs = inst.evaluate(x)
            entry[s]["objectives"], entry[s]["constraints"] = Fs[0].tolist(), Gs[0].tolist()
        res["representatives"][name] = entry
    # robustness of "dominates the standard policy" under both structures, for every dominating policy
    if dom.any():
        di = np.nonzero(dom)[0]
        Fe, Ge = struct_insts["exposure"].evaluate(Pol[di])
        f_std_e = struct_insts["exposure"].evaluate(std)[0][0]
        still = np.all(Ge <= 0, axis=1) & np.all(Fe <= f_std_e, axis=1) & np.any(Fe < f_std_e, axis=1)
        res["robustness"] = {"n_dominating_time": int(len(di)), "n_still_dominating_exposure": int(still.sum())}
    for name in ("standard", "trade", "knee", "dominating"):
        if name in reps:
            res["curves"][name] = daily_curves(struct_insts["time"], Pol[reps[name]])
    with open(os.path.join(args.analysis, f"e3_{args.inst}.pkl"), "wb") as fh:
        pickle.dump(res, fh)
    print({k: res[k] for k in ("inst", "n_policies", "n_feasible", "n_nd", "n_dominating_standard",
                               "standard_dominated_by_nd", "trade_feasible", "trade_dominated_by_nd", "robustness")})


if __name__ == "__main__":
    main()
