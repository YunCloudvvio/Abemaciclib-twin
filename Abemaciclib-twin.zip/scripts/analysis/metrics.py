"""Metrics and statistics of the algorithm comparison (E2).

Per instance, from analysis/runs_<inst>.pkl (collect.py) and analysis/test_<inst>.pkl (test_eval.py):
* reference front: non-dominated set of every final policy of every run that is feasible on the test
  population (objectives on the test population, duplicates by objective vector removed);
* normalisation: ideal and nadir point of the reference front; hypervolume (HV) with reference point
  1.1 in every normalised objective; IGD+ against the normalised reference front;
* per run: test HV and IGD+ of its test-feasible non-dominated final policies (no feasible policy: HV = 0,
  IGD+ undefined and counted separately); feasible fraction of its unique final policies on its own SAA
  batch and on the test population; SAA HV of its SAA-feasible non-dominated final policies with the same
  normalisation (generalisation gap = SAA HV - test HV); number of non-dominated test-feasible policies
  (unique objective vectors); evaluations used; HV on the SAA batch at each checkpoint and the evaluations
  needed to reach 95% of the final SAA HV (from the stored checkpoint evaluation counts);
* statistics: the algorithm with the best mean test HV (resp. IGD+) is the reference; every other
  algorithm is compared with it by the Wilcoxon signed-rank test paired by seed (common random numbers),
  two-sided, Holm-corrected over the 19 comparisons, alpha 0.05 ("-" significantly worse, "+" significantly
  better, "=" no significant difference); Friedman mean ranks of the mean HV over the instances (descriptive).
Needs pymoo and scipy:
  python scripts/analysis/metrics.py --analysis analysis
Writes analysis/metrics_<inst>.pkl, analysis/summary.json and CSV tables in analysis/tables/.
"""
import argparse
import json
import os
import pickle

import numpy as np
from pymoo.indicators.hv import HV
from pymoo.indicators.igd_plus import IGDPlus
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
from scipy.stats import rankdata, wilcoxon

from collect import ALGS, MOEA

REF_POINT = 1.1
ALPHA = 0.05


def nd(F):
    """Indices of the non-dominated rows of F (minimisation), duplicates by objective vector removed."""
    if len(F) == 0:
        return np.zeros(0, dtype=int)
    _, first = np.unique(F, axis=0, return_index=True)
    first = np.sort(first)
    front = NonDominatedSorting().do(F[first], only_non_dominated_front=True)
    return first[np.sort(front)]


def holm(p):
    """Holm-adjusted p-values."""
    p = np.asarray(p, dtype=float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    run = 0.0
    for k, i in enumerate(order):
        run = max(run, (m - k) * p[i])
        adj[i] = min(1.0, run)
    return adj


class Lookup:
    def __init__(self, test):
        self.index = {x.tobytes(): i for i, x in enumerate(test["policies"])}
        self.F, self.G = test["F"], test["G"]

    def __call__(self, X):
        idx = np.array([self.index[np.asarray(x, float).tobytes()] for x in X], dtype=int)
        return self.F[idx], self.G[idx]


def hv_of(Fn, hv):
    """HV of normalised points; points not dominating the reference point contribute nothing."""
    if len(Fn) == 0:
        return 0.0
    keep = np.all(Fn < REF_POINT, axis=1)
    return float(hv(Fn[keep])) if keep.any() else 0.0


def compare(values, seeds, algs, higher_better):
    """values[alg] -> dict seed -> value (NaN = undefined, e.g. IGD+ of a run without a test-feasible solution).

    Reference = best mean among the algorithms defined in every run; the others are compared with it by the
    Wilcoxon signed-rank test paired by seed, Holm-corrected. An undefined value counts as the worst value
    (it loses every pair), so an algorithm that often finds no feasible solution cannot look equal.
    Direction of a significant difference = sign of the mean of the per-seed differences with undefined
    values replaced by the worst defined value of the pair minus/plus 1.
    """
    full = [a for a in algs if all(np.isfinite(values[a][s]) for s in seeds)]
    pool = full if full else algs
    means = {a: (np.nanmean([values[a][s] for s in seeds])
                 if any(np.isfinite(values[a][s]) for s in seeds) else np.nan) for a in algs}
    key = (lambda a: means[a] if np.isfinite(means[a]) else -np.inf) if higher_better else \
          (lambda a: means[a] if np.isfinite(means[a]) else np.inf)
    best = (max if higher_better else min)(pool, key=key)
    others = [a for a in algs if a != best]
    pvals, signs = [], []
    for a in others:
        x = np.array([values[a][s] for s in seeds], float)
        y = np.array([values[best][s] for s in seeds], float)
        both = np.concatenate([x[np.isfinite(x)], y[np.isfinite(y)]])
        worst = (both.min() - 1.0 if higher_better else both.max() + 1.0) if both.size else 0.0
        x = np.where(np.isfinite(x), x, worst)
        y = np.where(np.isfinite(y), y, worst)
        d = x - y
        if np.all(d == 0):
            pvals.append(1.0)
        else:
            pvals.append(float(wilcoxon(x, y, zero_method="wilcox", alternative="two-sided").pvalue))
        better = d.mean() > 0 if higher_better else d.mean() < 0
        signs.append("+" if better else "-")
    adj = holm(pvals) if others else []
    marks = {best: "best"}
    for a, p, s in zip(others, adj, signs):
        marks[a] = s if p < ALPHA else "="
    return best, means, marks, dict(zip(others, [float(v) for v in adj]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--analysis", default="analysis")
    ap.add_argument("--instances", nargs="+", default=["P1", "P2", "P3", "P4"])
    args = ap.parse_args()
    os.makedirs(os.path.join(args.analysis, "tables"), exist_ok=True)
    summary = {}
    for inst in args.instances:
        with open(os.path.join(args.analysis, f"runs_{inst}.pkl"), "rb") as fh:
            runs = pickle.load(fh)
        with open(os.path.join(args.analysis, f"test_{inst}.pkl"), "rb") as fh:
            test = pickle.load(fh)
        look = Lookup(test)
        # reference front on the test population
        pool = [look(r["X"])[0][np.all(look(r["X"])[1] <= 0, axis=1)] for r in runs if len(r["X"])]
        pool = np.concatenate([p for p in pool if len(p)]) if any(len(p) for p in pool) else np.zeros((0, 3))
        if len(pool) == 0:
            raise SystemExit(f"{inst}: no test-feasible final solution in any run")
        ref = pool[nd(pool)]
        ideal, nadir = ref.min(axis=0), ref.max(axis=0)
        span = np.where(nadir > ideal, nadir - ideal, 1.0)
        norm = lambda F: (F - ideal) / span  # noqa: E731
        hv = HV(ref_point=np.full(3, REF_POINT))
        igd = IGDPlus(norm(ref))
        per_run = []
        for r in runs:
            Ft, Gt = look(r["X"]) if len(r["X"]) else (np.zeros((0, 3)), np.zeros((0, 3)))
            feas_t = np.all(Gt <= 0, axis=1)
            feas_s = np.all(r["G"] <= 0, axis=1) if len(r["G"]) else np.zeros(0, bool)
            Ft_nd = Ft[feas_t][nd(Ft[feas_t])]
            Fs_nd = r["F"][feas_s][nd(r["F"][feas_s])]
            hv_t = hv_of(norm(Ft_nd), hv)
            hv_s = hv_of(norm(Fs_nd), hv)
            igdp = float(igd(norm(Ft_nd))) if len(Ft_nd) else np.nan
            curve = []
            for c in r["ckpt"]:
                fs = np.all(c["G"] <= 0, axis=1) if len(c["G"]) else np.zeros(0, bool)
                Fc = c["F"][fs]
                curve.append(hv_of(norm(Fc[nd(Fc)]), hv))
            curve = np.array(curve)
            final = curve[-1] if len(curve) else 0.0
            reach = np.nan
            if final > 0:
                hit = np.nonzero(curve >= 0.95 * final)[0]
                reach = float(r["ckpt_fe"][hit[0]])
            per_run.append({"alg": r["alg"], "family": r["family"], "seed": r["seed"], "fe": r["fe"],
                            "runtime": r["runtime"], "n_final": len(r["X"]),
                            "feas_saa": float(feas_s.mean()) if len(feas_s) else 0.0,
                            "feas_test": float(feas_t.mean()) if len(feas_t) else 0.0,
                            "hv_test": hv_t, "hv_saa": hv_s, "gap": hv_s - hv_t, "igdp": igdp,
                            "n_nd": len(Ft_nd), "curve": curve, "curve_fe": np.asarray(r["ckpt_fe"]),
                            "fe95": reach})
        algs = [a for a in ALGS if any(p["alg"] == a for p in per_run)]
        seeds = sorted({p["seed"] for p in per_run})
        val = lambda key: {a: {p["seed"]: p[key] for p in per_run if p["alg"] == a} for a in algs}  # noqa: E731
        for a in algs:                                   # every algorithm must have every seed
            missing = set(seeds) - set(val("hv_test")[a])
            if missing:
                raise SystemExit(f"{inst} {a}: missing seeds {sorted(missing)}")
        best_hv, mean_hv, marks_hv, p_hv = compare(val("hv_test"), seeds, algs, True)
        best_ig, mean_ig, marks_ig, p_ig = compare(val("igdp"), seeds, algs, False)
        table = []
        for a in algs:
            rows = [p for p in per_run if p["alg"] == a]
            g = lambda k: np.array([p[k] for p in rows], dtype=float)  # noqa: E731
            table.append({"alg": a, "family": "MOEA" if a in MOEA else "MOSI",
                          "hv_mean": float(g("hv_test").mean()), "hv_sd": float(g("hv_test").std(ddof=1)),
                          "hv_mark": marks_hv[a], "hv_p_holm": p_hv.get(a),
                          "igdp_mean": float(np.nanmean(g("igdp"))), "igdp_sd": float(np.nanstd(g("igdp"), ddof=1)),
                          "igdp_mark": marks_ig[a], "igdp_p_holm": p_ig.get(a),
                          "igdp_undefined_runs": int(np.isnan(g("igdp")).sum()),
                          "feas_saa": float(g("feas_saa").mean()), "feas_test": float(g("feas_test").mean()),
                          "gap_mean": float(g("gap").mean()), "n_nd": float(g("n_nd").mean()),
                          "fe_mean": float(g("fe").mean()), "fe_min": int(g("fe").min()), "fe_max": int(g("fe").max()),
                          "fe95_median": float(np.nanmedian(g("fe95"))) if np.isfinite(g("fe95")).any() else None,
                          "runtime_mean_s": float(g("runtime").mean())})
        with open(os.path.join(args.analysis, f"metrics_{inst}.pkl"), "wb") as fh:
            pickle.dump({"per_run": per_run, "table": table, "ref_front": ref, "ideal": ideal, "nadir": nadir,
                         "standard": test["standard"], "trade": test["trade"]}, fh)
        with open(os.path.join(args.analysis, "tables", f"e2_{inst}.csv"), "w") as fh:
            keys = list(table[0].keys())
            fh.write(",".join(keys) + "\n")
            for t in table:
                fh.write(",".join("" if t[k] is None else str(t[k]) for k in keys) + "\n")
        summary[inst] = {"n_runs": len(per_run), "seeds": len(seeds), "ref_front_size": len(ref),
                         "ideal": ideal.tolist(), "nadir": nadir.tolist(), "best_hv": best_hv, "best_igdp": best_ig,
                         "mean_hv": mean_hv, "mean_igdp": mean_ig}
        print(f"{inst}: {len(per_run)} runs, reference front {len(ref)} points, best HV {best_hv}, best IGD+ {best_ig}")
    # Friedman mean ranks of the mean test HV over the instances (descriptive)
    algs = list(summary[args.instances[0]]["mean_hv"].keys())
    ranks = np.array([rankdata([-summary[i]["mean_hv"][a] for a in algs]) for i in args.instances])
    summary["friedman_mean_rank_hv"] = dict(zip(algs, ranks.mean(axis=0).tolist()))
    with open(os.path.join(args.analysis, "summary.json"), "w") as fh:
        json.dump(summary, fh, indent=2)


if __name__ == "__main__":
    main()
