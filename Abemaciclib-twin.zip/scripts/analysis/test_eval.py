"""Re-evaluate final policies on an independent test population.

Test population per instance: the same 20-member twin ensemble, n_per_member virtual patients per member
(default 500, i.e. 10,000 patients), test seed 9,000,001 (disjoint from every optimisation seed, which are
3,000,001-3,000,030). The paired constraints are computed against the standard policy on the same test
patients (problems.Instance does this). Policies: the union of the unique final policies of all runs of the
instance, plus the standard policy and a TRADE-like policy (adaptive escalation 50 -> 100 -> 150 mg every
14 days for P1/P2/P4; for P3 the fixed schedule 50, 50, 100, 100, then 150 mg).

Usage:  python scripts/analysis/test_eval.py --inst P1 --chunk 0 --nchunks 4
Merge:               python scripts/analysis/test_eval.py --inst P1 --merge --nchunks 4
Writes analysis/test_<inst>_<chunk>.pkl and, after merging, analysis/test_<inst>.pkl:
{"policies": array (n, D), "F": (n, 3), "G": (n, 3), "standard": x, "trade": x, "n_per_member", "seed"}.
"""
import argparse
import os
import pickle
import sys
import time

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from twin import problems  # noqa: E402
from twin import scenarios as SC  # noqa: E402

TEST_SEED = 9_000_001
STANDARD = {"P3": np.full(24, 3.0)}
TRADE = {"P3": np.array([1, 1, 2, 2] + [3] * 20, dtype=float)}
ADAPTIVE_STANDARD = np.array([3, 3, 14, 1.0, 0, 0, 28, 0], dtype=float)
ADAPTIVE_TRADE = np.array([1, 3, 14, 1.0, 1, 0, 28, 0], dtype=float)


def reference_policies(inst):
    if inst == "P3":
        return STANDARD["P3"], TRADE["P3"]
    return ADAPTIVE_STANDARD, ADAPTIVE_TRADE


def policy_list(inst, analysis_dir):
    with open(os.path.join(analysis_dir, f"runs_{inst}.pkl"), "rb") as fh:
        runs = pickle.load(fh)
    std, trade = reference_policies(inst)
    allx = [r["X"] for r in runs if len(r["X"])] + [std[None, :], trade[None, :]]
    P = np.unique(np.concatenate(allx), axis=0)              # sorted, deterministic
    return P, std, trade


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inst", required=True, choices=problems.INSTANCES)
    ap.add_argument("--structure", default="time")
    ap.add_argument("--analysis", default=os.path.join(ROOT, "analysis"))
    ap.add_argument("--n-per-member", type=int, default=500)
    ap.add_argument("--chunk", type=int, default=0)
    ap.add_argument("--nchunks", type=int, default=1)
    ap.add_argument("--merge", action="store_true")
    args = ap.parse_args()
    P, std, trade = policy_list(args.inst, args.analysis)
    if args.merge:
        F = np.full((len(P), problems.N_OBJ), np.nan)
        G = np.full((len(P), problems.N_CON), np.nan)
        for c in range(args.nchunks):
            with open(os.path.join(args.analysis, f"test_{args.inst}_{c}.pkl"), "rb") as fh:
                part = pickle.load(fh)
            if not np.array_equal(part["policies"], P[c::args.nchunks]):
                raise SystemExit(f"chunk {c} was computed for a different policy list")
            meta = (part.get("n_per_member"), part.get("seed"), part.get("structure"), part.get("scenario"),
                    part.get("nchunks"))
            if meta != (args.n_per_member, TEST_SEED, args.structure, SC.current()[0], args.nchunks):
                raise SystemExit(f"chunk {c} settings {meta} differ from the merge settings")
            F[c::args.nchunks], G[c::args.nchunks] = part["F"], part["G"]
        if np.isnan(F).any() or np.isnan(G).any():
            raise SystemExit("missing values after merging")
        out = {"policies": P, "F": F, "G": G, "standard": std, "trade": trade, "n_per_member": args.n_per_member,
               "seed": TEST_SEED, "structure": args.structure, "scenario": SC.current()[0]}
        with open(os.path.join(args.analysis, f"test_{args.inst}.pkl"), "wb") as fh:
            pickle.dump(out, fh)
        print(f"{args.inst}: merged {len(P)} policies")
        return
    inst = problems.Instance(os.path.join(ROOT, "calibration", f"ensemble_{args.structure}.json"),
                             os.path.join(ROOT, "calibration", f"stage3_{args.structure}.json"),
                             TEST_SEED, n_per_member=args.n_per_member, name=args.inst)
    mine = P[args.chunk::args.nchunks]
    t0 = time.perf_counter()
    F, G = inst.evaluate(mine) if len(mine) else (np.zeros((0, 3)), np.zeros((0, 3)))
    with open(os.path.join(args.analysis, f"test_{args.inst}_{args.chunk}.pkl"), "wb") as fh:
        pickle.dump({"policies": mine, "F": F, "G": G, "n_per_member": args.n_per_member, "seed": TEST_SEED,
                     "structure": args.structure, "scenario": inst.scenario, "nchunks": args.nchunks}, fh)
    print(f"{args.inst} chunk {args.chunk}/{args.nchunks}: {len(mine)} policies in {time.perf_counter() - t0:.0f} s "
          f"({os.environ.get('NUMBA_NUM_THREADS')} threads)")


if __name__ == "__main__":
    main()
