"""LaTeX tables of E2 from analysis/tables/e2_<inst>.csv and analysis/summary.json (paper/tables/)."""
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from collect import ALGS, MOEA  # noqa: E402

NAMES = {"SPEA2": "SPEA2", "NSGAII": "NSGA-II", "GDE3": "GDE3", "MOEADDE": "MOEA/D-DE", "NSGAIII": "NSGA-III",
         "AGEMOEAII": "AGE-MOEA-II", "LMPFE": "LMPFE", "CMOES": "CMOES", "APSEA": "APSEA", "CMOCEADDAP": "CMOCEA-DDAP",
         "M001_MOGWO": "MOGWO", "M004_MSSA": "MSSA", "M014_MOAVOA": "MOAVOA", "M103_MOCGO": "MOCGO",
         "M105_MOEOSMA": "MOEOSMA", "M212_MOGNDO": "MOGNDO", "M231_MORIME": "MORIME", "M306_MaOMPA": "MaOMPA",
         "M315_MOSRS": "MOSRS", "M323_C-MOBRO": "C-MOBRO"}
INST = ["P1", "P2", "P3", "P4"]
MARK = {"best": "", "=": "$\\approx$", "-": "$-$", "+": "$+$"}


def cell(r, key, sd, mark, digits=3, bold=False, rank=None):
    sdv = float(r[sd])
    v = f"{float(r[key]):.{digits}f} $\\pm$ " + (f"{sdv:.{digits}f}" if sdv == sdv else "--")
    if bold:
        v = f"\\textbf{{{v}}}"
    if rank is not None:
        v += f" ({rank})"
    return v + (f" {MARK[r[mark]]}" if r[mark] != "best" else "")


def main(analysis="analysis", out="paper/tables"):
    os.makedirs(out, exist_ok=True)
    rows = {i: {r["alg"]: r for r in csv.DictReader(open(os.path.join(analysis, "tables", f"e2_{i}.csv")))} for i in INST}
    summ = json.load(open(os.path.join(analysis, "summary.json")))
    for metric, sd, mark, fname, digits in (("hv_mean", "hv_sd", "hv_mark", "table_hv.tex", 3),
                                             ("igdp_mean", "igdp_sd", "igdp_mark", "table_igd.tex", 3)):
        lines = ["\\begin{tabular}{l" + "c" * len(INST) + ("c" if metric == "hv_mean" else "") + "}", "\\toprule",
                 "\\textbf{Algorithm} & " + " & ".join(f"\\textbf{{{i}}}" for i in INST)
                 + (" & \\textbf{Mean rank}" if metric == "hv_mean" else "") + "\\\\", "\\midrule"]
        ranks = {}
        if metric == "hv_mean":                      # rank of the mean test HV among the 20 algorithms
            from scipy.stats import rankdata
            for i in INST:
                rk = rankdata([-float(rows[i][a]["hv_mean"]) for a in ALGS], method="min")
                ranks[i] = {a: int(k) for a, k in zip(ALGS, rk)}
        for a in ALGS:
            if a == ALGS[len(MOEA)]:
                lines.append("\\midrule")
            cells = []
            for i in INST:
                r = rows[i][a]
                c = cell(r, metric, sd, mark, digits, bold=(r[mark] == "best"),
                         rank=ranks[i][a] if ranks else None)
                if metric == "igdp_mean" and r["igdp_undefined_runs"] not in ("0", "0.0"):
                    c += f"$^{{{int(float(r['igdp_undefined_runs']))}}}$"
                cells.append(c)
            if metric == "hv_mean":
                cells.append(f"{summ['friedman_mean_rank_hv'][a]:.2f}")
            lines.append(NAMES[a] + " & " + " & ".join(cells) + "\\\\")
        lines += ["\\bottomrule", "\\end{tabular}"]
        open(os.path.join(out, fname), "w").write("\n".join(lines) + "\n")
        print("wrote", fname)


if __name__ == "__main__":
    main(*sys.argv[1:])
