"""E4 summary: one row per scenario from analysis_e4/<scenario>/e3_P1.pkl, and the efficacy x tolerance heat map.

For every scenario: whether a test-feasible policy found by the runs dominates the standard policy and how many
do; whether the TRADE-like policy is feasible and dominated; the standard policy's objectives; the knee policy
(decision vector, objectives and paired differences from the standard policy with 95% bootstrap CIs).
The base cell is the main experiment restricted to the same three algorithms and seeds (analysis_e4/base).
Usage:  python scripts/analysis/e4_summary.py --e4 analysis_e4 --out paper
"""
import argparse
import json
import os
import pickle
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from twin.scenarios import SCENARIOS  # noqa: E402

for f in font_manager.findSystemFonts(os.path.expanduser("~/.local/share/fonts")):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "Times New Roman", "font.size": 8.5, "mathtext.fontset": "stix",
                     "savefig.dpi": 300, "savefig.bbox": "tight"})

ORDER = ["base"] + [s for s in SCENARIOS if s != "base"] + ["exposure"]


def row(name, e3):
    k = e3["representatives"]["knee"]
    t = k.get("exposure" if name == "exposure" else "time") or {}   # the scenario's own tolerance structure
    d = t.get("diff_vs_standard", {})
    return {"scenario": name, "n_policies": e3["n_policies"], "n_feasible": e3["n_feasible"], "n_nd": e3["n_nd"],
            "standard_dominated": e3["standard_dominated_by_nd"], "n_dominating_standard": e3["n_dominating_standard"],
            "trade_feasible": e3["trade_feasible"], "trade_dominated": e3["trade_dominated_by_nd"],
            "standard_obj": e3["standard_obj"], "trade_obj": e3["trade_obj"],
            "knee_policy": k["policy"], "knee_obj": k["objectives"],
            "knee_diff_rmst": d.get("rmst"), "knee_diff_anc3": d.get("anc3"), "knee_diff_diar": d.get("diar")}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--e4", default="analysis_e4")
    ap.add_argument("--out", default="paper")
    args = ap.parse_args()
    rows = []
    for s in ORDER:
        f = os.path.join(args.e4, s, "e3_P1.pkl")
        if not os.path.exists(f):
            raise SystemExit(f"missing {f}")
        with open(f, "rb") as fh:
            rows.append(row(s, pickle.load(fh)))
    os.makedirs(os.path.join(args.out, "tables"), exist_ok=True)
    os.makedirs(os.path.join(args.out, "figures"), exist_ok=True)
    with open(os.path.join(args.out, "tables", "e4_summary.json"), "w") as fh:
        json.dump(rows, fh, indent=1)
    labels = {"base": "Main analysis", "exposure": "Exposure-based tolerance",
              "anc_low": "Neutrophil slope ÷1.5", "anc_high": "Neutrophil slope ×1.5",
              "rdi_0.5": "Dose intensity ≥ 0.5", "rdi_0.7": "Dose intensity ≥ 0.7",
              "window_18": "Follow-up 18 months", "window_36": "Follow-up 36 months"}
    for e, el in (("low", "low"), ("mid", "central"), ("high", "high")):
        for t, tl in (("low", "slow"), ("mid", "calibrated"), ("high", "fast")):
            labels[f"eff_{e}_tol_{t}"] = f"Efficacy {el}, tolerance {tl}"
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 4.6), sharey=True)
    y = np.arange(len(rows))[::-1]
    for ax, (key, scale, xlab) in zip(axes, (("knee_diff_rmst", 1.0, "RMST difference (months)"),
                                             ("knee_diff_anc3", 100.0, "Grade $\\geq$3 neutropenia\ndifference (percentage points)"),
                                             ("knee_diff_diar", 1.0, "Grade $\\geq$2 diarrhea days\ndifference"))):
        m = np.array([r[key][0] for r in rows]) * scale
        lo = np.array([r[key][1] for r in rows]) * scale
        hi = np.array([r[key][2] for r in rows]) * scale
        col = ["#8E44AD" if not r["standard_dominated"] else "#1F4E79" for r in rows]
        ax.errorbar(m, y, xerr=[m - lo, hi - m], fmt="none", ecolor="#555555", elinewidth=0.8, capsize=2)
        ax.scatter(m, y, c=col, s=14, zorder=3)
        ax.axvline(0, color="#999999", linewidth=0.6, linestyle=":")
        ax.set_xlabel(xlab)
    axes[0].set_yticks(y, [labels[r["scenario"]] for r in rows], fontsize=7.5)
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "figures", "fig_e4_knee.pdf"))
    fig.savefig(os.path.join(args.out, "figures", "fig_e4_knee.png"))
    for r in rows:
        print(f"{r['scenario']:20s} dominated {str(r['standard_dominated']):5s} n_dom {r['n_dominating_standard']:4d} "
              f"trade feas {str(r['trade_feasible']):5s} trade dominated {str(r['trade_dominated']):5s} "
              f"knee {np.round(r['knee_policy'], 2).tolist()} dRMST {r['knee_diff_rmst']}")


if __name__ == "__main__":
    main()
