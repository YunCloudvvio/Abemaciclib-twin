"""Collect the runs of the main experiment into one file per instance (analysis input).

For every run (instance, algorithm, seed): the final set as unique decoded policies with the objectives and
constraints on the run's own SAA batch, the number of evaluations, the runtime and the 20 checkpoints
(evaluations, unique policies, objectives, constraints). PlatEMO .mat files hold the final population (may
contain duplicates); MOSI .npz files hold the de-duplicated reported set. For the PlatEMO algorithms run with
Deb's rule (SPEA2, MOEADDE, LMPFE) the .mat already holds the true values (twin/true_values.py).

Run:  python scripts/analysis/collect.py --res results --structure time --out analysis
Writes analysis/runs_<instance>.pkl (list of dicts) and prints a completeness table.
"""
import argparse
import glob
import os
import pickle

import numpy as np
from scipy.io import loadmat

MOEA = ["SPEA2", "NSGAII", "GDE3", "MOEADDE", "NSGAIII", "AGEMOEAII", "LMPFE", "CMOES", "APSEA", "CMOCEADDAP"]
MOSI = ["M001_MOGWO", "M004_MSSA", "M014_MOAVOA", "M103_MOCGO", "M105_MOEOSMA", "M212_MOGNDO",
        "M231_MORIME", "M306_MaOMPA", "M315_MOSRS", "M323_C-MOBRO"]
ALGS = MOEA + MOSI


def unique_rows(X, F, G):
    """Unique decision rows (first occurrence) with their objective and constraint rows."""
    if len(X) == 0:
        return X, F, G
    _, idx = np.unique(X, axis=0, return_index=True)
    idx = np.sort(idx)
    return X[idx], F[idx], G[idx]


def load_run(path):
    if path.endswith(".mat"):
        d = loadmat(path)
        X, F, G = d["Dec"], d["Obj"], d["Con"]
        fe = int(np.ravel(d["info"]["FE"][0][0])[0])
        runtime = float(np.ravel(d["info"]["runtime"][0][0])[0])
        cfe = d["ckpt_FE"].ravel().astype(int)
        cX = [np.asarray(c, dtype=float) for c in d["ckpt_Dec"].ravel()]
        cF = [np.asarray(c, dtype=float) for c in d["ckpt_Obj"].ravel()]
        cG = [np.asarray(c, dtype=float) for c in d["ckpt_Con"].ravel()]
    else:
        d = np.load(path)
        X, F, G = d["X"], d["F"], d["G"]
        fe, runtime = int(d["fes"]), float(d["runtime"])
        cfe = d["ckpt_fe"].astype(int)
        cX = [d["ckpt_X"][d["ckpt_id"] == i] for i in range(len(cfe))]
        cF = [d["ckpt_F"][d["ckpt_id"] == i] for i in range(len(cfe))]
        cG = [d["ckpt_G"][d["ckpt_id"] == i] for i in range(len(cfe))]
    X, F, G = unique_rows(np.asarray(X, float), np.asarray(F, float), np.asarray(G, float))
    ck = [unique_rows(a, b, c) for a, b, c in zip(cX, cF, cG)]
    return {"X": X, "F": F, "G": G, "fe": fe, "runtime": runtime, "ckpt_fe": cfe,
            "ckpt": [{"X": a, "F": b, "G": c} for a, b, c in ck]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--res", default="results")
    ap.add_argument("--structure", default="time")
    ap.add_argument("--out", default="analysis")
    ap.add_argument("--instances", nargs="+", default=["P1", "P2", "P3", "P4"])
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    for inst in args.instances:
        runs, missing = [], []
        for alg in ALGS:
            files = sorted(glob.glob(os.path.join(args.res, args.structure, inst, alg, "seed*.mat")) +
                           glob.glob(os.path.join(args.res, args.structure, inst, alg, "seed*.npz")))
            files = [f for f in files if ".tmp" not in f and ".tv." not in f and ".failed." not in f]
            for f in files:
                seed = int(os.path.basename(f)[4:].split(".")[0])
                r = load_run(f)
                r.update(alg=alg, seed=seed, family="MOEA" if alg in MOEA else "MOSI", file=f)
                runs.append(r)
            if len(files) == 0:
                missing.append(alg)
        with open(os.path.join(args.out, f"runs_{inst}.pkl"), "wb") as fh:
            pickle.dump(runs, fh)
        counts = {a: sum(r["alg"] == a for r in runs) for a in ALGS}
        print(f"{inst}: {len(runs)} runs; per algorithm {sorted(set(counts.values()))}; missing {missing}")


if __name__ == "__main__":
    main()
