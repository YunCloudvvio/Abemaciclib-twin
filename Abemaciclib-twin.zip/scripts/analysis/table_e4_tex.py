"""LaTeX Table S3 (scenario analysis) from paper/tables/e4_summary.json -> paper/tables/table_e4.tex."""
import json
import sys
from decimal import ROUND_HALF_UP, Decimal

def r1(x, sign=False):
    """One decimal, rounding halves up (exact k/10000 proportions such as 37.55 must give 37.6)."""
    d = Decimal(repr(round(float(x), 9))).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    return f"{d:+.1f}" if sign else f"{d:.1f}"


src = sys.argv[1] if len(sys.argv) > 1 else "paper/tables/e4_summary.json"
out = sys.argv[2] if len(sys.argv) > 2 else "paper/tables/table_e4.tex"
rows = json.load(open(src))
lab = {"base": "Main analysis", "exposure": "Exposure-based tolerance", "anc_low": "Neutrophil slope $\\div$1.5",
       "anc_high": "Neutrophil slope $\\times$1.5", "rdi_0.5": "Dose intensity $\\geq$0.5",
       "rdi_0.7": "Dose intensity $\\geq$0.7", "window_18": "Follow-up 18 months", "window_36": "Follow-up 36 months"}
for e, el in (("low", "low"), ("mid", "central"), ("high", "high")):
    for t, tl in (("low", "slow"), ("mid", "calibrated"), ("high", "fast")):
        lab[f"eff_{e}_tol_{t}"] = f"Efficacy {el}, tolerance {tl}"
L = [r"\begin{table}[h]",
     r"\caption{Scenario analysis on P1 with three algorithms and 10 runs per scenario, evaluated on the test population of "
     r"each scenario. Label: restricted mean survival time in months, grade~$\geq$3 neutropenia in \%, and grade~$\geq$2 "
     r"diarrhea days of the label regimen. Dom.: number of test-feasible policies that dominate the label regimen. Knee "
     r"policy: $d_0$, $d_{\mathrm{tgt}}$, $\tau_{\mathrm{esc}}$, $\theta_{\mathrm{ANC}}$, $w$, $n_{\mathrm{pre}}$, "
     r"$\tau_{\mathrm{re}}$, and $r_{\max}$, with doses in mg, $\theta_{\mathrm{ANC}}$ in $10^9$/L, and $\tau_{\mathrm{esc}}$, $w$, "
     r"and $\tau_{\mathrm{re}}$ in days. Changes: differences of the knee policy from the label regimen in months, percentage "
     r"points, and days, with 95\% bootstrap confidence intervals in parentheses. The TRADE-like escalation was "
     r"infeasible and dominated in every scenario. The main-analysis row uses the runs of the same three algorithms and "
     r"seeds 3{,}000{,}001--3{,}000{,}010 of the main experiment, so its knee policy and number of dominating policies "
     r"differ from those of the full main experiment.}",
     r"\centering\scriptsize", r"\begin{tabular}{lcrlccc}", r"\toprule",
     r"\textbf{Scenario} & \textbf{Label} & \textbf{Dom.} & \textbf{Knee policy} & \textbf{RMST change} & "
     r"\textbf{Neutropenia change} & \textbf{Diarrhea change}\\", r"\midrule"]
for r in rows:
    s, k = r["standard_obj"], r["knee_policy"]
    pol = f"{50 * int(k[0])}, {50 * int(k[1])}, {int(k[2])}, {k[3]:.2f}, {int(k[4])}, {int(k[5])}, {int(k[6])}, {int(k[7])}"
    a, b, c = r["knee_diff_rmst"], r["knee_diff_anc3"], r["knee_diff_diar"]
    L.append(f"{lab[r['scenario']]} & {-s[0]:.2f}/{r1(100 * s[1])}/{r1(s[2])} & {r['n_dominating_standard']} & {pol} & "
             f"{a[0]:+.2f} ({a[1]:+.2f}, {a[2]:+.2f}) & {r1(100 * b[0], True)} ({r1(100 * b[1], True)}, {r1(100 * b[2], True)}) & "
             f"{c[0]:+.1f} ({c[1]:+.1f}, {c[2]:+.1f})\\\\")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
open(out, "w").write("\n".join(L) + "\n")
print("wrote", out)
