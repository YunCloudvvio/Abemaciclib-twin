"""Figure: differences from the label regimen within each of the 20 ensemble members (analysis/e3_members_P1.json).
Usage:  python scripts/analysis/fig_members.py"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for f in font_manager.findSystemFonts(os.path.expanduser("~/.local/share/fonts")):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "Times New Roman", "font.size": 8.5, "mathtext.fontset": "stix",
                     "savefig.dpi": 300, "savefig.bbox": "tight", "axes.linewidth": 0.7})
d = json.load(open(os.path.join(ROOT, "analysis", "e3_members_P1.json")))
pol = [("knee", "Knee policy", "#F39C12"), ("dominating", "Dominating policy", "#8E44AD"), ("trade", "TRADE-like", "#2E7D32")]
met = [("rmst", "RMST difference (months)"), ("anc3", "Grade $\\geq$3 neutropenia\ndifference (percentage points)"),
       ("diar", "Grade $\\geq$2 diarrhea days\ndifference")]
fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.7), sharey=True)
rng = np.random.default_rng(0)
ylab, ypos = [], []
for ax, (key, lab) in zip(axes, met):
    for i, (name, nlab, col) in enumerate(pol):
        for j, (struct, mk) in enumerate((("time", "o"), ("exposure", "^"))):
            y0 = i * 2.6 + j * 1.0
            v = np.array(d["structures"][struct][name][key]["per_member"])
            ax.scatter(v, y0 + rng.uniform(-0.22, 0.22, len(v)), s=9, marker=mk, color=col, alpha=0.8, lw=0)
            ax.plot([np.median(v)] * 2, [y0 - 0.38, y0 + 0.38], color="black", lw=1.0)
            if key == "rmst":
                ylab.append(f"{nlab}, {'time' if struct == 'time' else 'exposure'}")
                ypos.append(y0)
    ax.axvline(0, color="#999999", lw=0.6, ls=":")
    ax.set_xlabel(lab, fontsize=7.8)
    ax.tick_params(labelsize=7)
axes[0].set_yticks(ypos, ylab, fontsize=7)
axes[0].invert_yaxis()
fig.tight_layout()
fig.savefig(os.path.join(ROOT, "paper", "figures", "fig_members.pdf"))
fig.savefig(os.path.join(ROOT, "paper", "figures", "fig_members.png"))
for struct in ("time", "exposure"):
    s = d["structures"][struct]["dominating"]
    r, a, di = (np.array(s[k]["per_member"]) for k in ("rmst", "anc3", "diar"))
    print(struct, "dominating: all three better", int(np.sum((r > 0) & (a < 0) & (di < 0))),
          "none worse", int(np.sum((r >= 0) & (a <= 0) & (di <= 0))))
