"""Parameter uncertainty of the P1 comparisons: differences between representative policies and the label regimen
within each of the 20 ensemble members (500 test patients each), for both diarrhea tolerance structures.

Uses the policies of analysis/e3_P1.pkl and the same test population as test_eval.py / e3.py.
Writes analysis/e3_members_P1.json. Usage:  python scripts/analysis/e3_members.py
"""
import json
import os
import pickle
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, HERE)

from twin import kernel as K  # noqa: E402
from twin import problems  # noqa: E402
from e3 import per_patient  # noqa: E402
from test_eval import TEST_SEED  # noqa: E402

N_PER = 500
POLICIES = ("knee", "dominating", "trade", "best_f2", "best_f3")


def main():
    with open(os.path.join(ROOT, "analysis", "e3_P1.pkl"), "rb") as fh:
        e3 = pickle.load(fh)
    reps = e3["representatives"]
    out = {"n_per_member": N_PER, "structures": {}}
    for struct in ("time", "exposure"):
        inst = problems.Instance(os.path.join(ROOT, "calibration", f"ensemble_{struct}.json"),
                                 os.path.join(ROOT, "calibration", f"stage3_{struct}.json"),
                                 TEST_SEED, n_per_member=N_PER, name="P1")
        m = len(inst.groups)
        assert inst.n == m * N_PER
        base = per_patient(inst, np.array(reps["standard"]["policy"]))
        res = {}
        for name in POLICIES:
            pp = per_patient(inst, np.array(reps[name]["policy"]))
            d = {}
            for key, scale in (("rmst", 1.0), ("anc3", 100.0), ("diar", 1.0), ("anc4", 100.0), ("disc", 100.0)):
                a = pp[key].reshape(m, N_PER)
                b = base[key].reshape(m, N_PER)
                if key == "disc":
                    a, b = (a > 0).astype(float), (b > 0).astype(float)
                diff = (a.mean(axis=1) - b.mean(axis=1)) * scale
                d[key] = {"per_member": diff.tolist(), "min": float(diff.min()), "max": float(diff.max()),
                          "median": float(np.median(diff)), "n_negative": int((diff < 0).sum()),
                          "n_positive": int((diff > 0).sum())}
            # paired check of the whole-population numbers against e3 (same patients, same policies)
            pooled = float(np.mean(pp["rmst"] - base["rmst"]))
            ref = reps[name][struct]["diff_vs_standard"]["rmst"][0]
            assert abs(pooled - ref) < 1e-9, (name, struct, pooled, ref)
            res[name] = d
        out["structures"][struct] = res
        print(struct, {n: {k: (round(v["min"], 3), round(v["max"], 3), v["n_negative"]) for k, v in res[n].items()}
                       for n in res})
    with open(os.path.join(ROOT, "analysis", "e3_members_P1.json"), "w") as fh:
        json.dump(out, fh, indent=1)


if __name__ == "__main__":
    K  # noqa: B018  (kernel import keeps the numba cache warm)
    main()
