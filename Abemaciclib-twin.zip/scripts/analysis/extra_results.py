"""Additional figures and tables from existing analysis outputs (no new simulation).

Figures (paper/figures):
  fig_sobol            total-effect Sobol indices, label regimen and escalation-minus-label differences
  fig_ranks            HV rank of every algorithm on every instance and mean rank
  fig_generalization   objectives on the optimization batch versus the test population (P1 final solutions)
  fig_policy_vars      decision variables of the P1 reference-front policies, by efficacy tertile
  fig_instances        reference fronts of P2, P3, P4 with the label regimen and the TRADE-like escalation
  fig_p3_schedules     weekly dose levels of the P3 reference-front schedules, ordered by RMST
Tables (paper/tables):
  table_reps.tex       representative P1 policies with clinical indicators (time- and exposure-based tolerance)
  table_p1_algs.tex    feasibility, front size and convergence of the 20 algorithms on P1
  table_instances.tex  label regimen, TRADE-like escalation and knee policy on each instance
Also writes analysis/extra_results.json with every number used in the text.
Run from the repository root:  python scripts/analysis/extra_results.py
"""
import csv
import json
import os
import pickle
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
from collect import ALGS, MOEA  # noqa: E402
from tables_tex import NAMES  # noqa: E402
from decimal import ROUND_HALF_UP, Decimal

def r1(x, sign=False):
    """One decimal, rounding halves up (exact k/10000 proportions such as 37.55 must give 37.6)."""
    d = Decimal(repr(round(float(x), 9))).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    return f"{d:+.1f}" if sign else f"{d:.1f}"


for f in font_manager.findSystemFonts(os.path.expanduser("~/.local/share/fonts")):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "Times New Roman", "font.size": 8.5, "axes.labelsize": 8.5, "legend.fontsize": 7.5,
                     "mathtext.fontset": "stix", "savefig.dpi": 300, "savefig.bbox": "tight", "axes.linewidth": 0.7})

AN = os.path.join(ROOT, "analysis")
FIG = os.path.join(ROOT, "paper", "figures")
TAB = os.path.join(ROOT, "paper", "tables")
INST = ["P1", "P2", "P3", "P4"]
NAVY, TEAL, RED, ORANGE, PURPLE, GREY = "#3C5488", "#00A087", "#C0392B", "#E08E45", "#8E6BB0", "#7F8C8D"
OUT = {}


def load(name):
    with open(os.path.join(AN, name), "rb") as fh:
        return pickle.load(fh)


def front(inst):
    """Test-feasible non-dominated policies found by the runs (same definition as metrics.py and e3.py)."""
    test, runs = load(f"test_{inst}.pkl"), load(f"runs_{inst}.pkl")
    P, F, G = np.asarray(test["policies"], float), test["F"], test["G"]
    found = {np.asarray(x, float).tobytes() for r in runs for x in r["X"]}
    from_run = np.array([x.tobytes() in found for x in P])
    feas = np.all(G <= 0, axis=1) & from_run
    c = np.nonzero(feas)[0]
    Fc = F[c]
    nd = np.array([not np.any(np.all(Fc <= Fc[k], axis=1) & np.any(Fc < Fc[k], axis=1)) for k in range(len(c))])
    idx = c[nd]
    find = {x.tobytes(): i for i, x in enumerate(P)}
    i_std = find[np.asarray(test["standard"], float).tobytes()]
    i_trade = find[np.asarray(test["trade"], float).tobytes()]
    return dict(P=P, F=F, G=G, feas=feas, nd=idx, i_std=i_std, i_trade=i_trade, test=test, runs=runs)


def knee(fr, met):
    ideal, nadir = met["ideal"], met["nadir"]
    span = np.where(nadir > ideal, nadir - ideal, 1.0)
    nd = fr["nd"]
    return int(nd[np.argmin(np.linalg.norm((fr["F"][nd] - ideal) / span, axis=1))])


# ------------------------------------------------------------------ Sobol
def fig_sobol():
    names = {"anc_slope": "Neutrophil slope", "anc_slope_cv": "Variability of neutrophil slope", "q01": "Diarrhea rate 0$\\to$1",
             "q12": "Diarrhea rate 1$\\to$2", "q23": "Diarrhea rate 2$\\to$3", "tolerance": "Tolerance rate",
             "beta": "Exposure exponent $\\beta$", "g2_rule_frac": "Grade 2 rule fraction",
             "anc3_rule_frac": "Grade 3 rule fraction", "oth_red": "Other-AE reduction rate",
             "oth_disc": "Other-AE discontinuation rate", "oth_k": "Other-AE decline", "e_abe": "Abemaciclib tumor effect",
             "hz_conc": "Concentration effect on hazard", "hz_cfb": "Size effect on hazard",
             "anc_mtt_h": "Neutrophil transit time", "anc_gamma": "Neutrophil feedback $\\gamma$",
             "e_ai": "Aromatase inhibitor effect", "hazard_mult": "First-line hazard multiplier"}
    panels = [("std_f1", "Label regimen: RMST"), ("std_f2", "Label regimen: grade $\\geq$3 neutropenia"),
              ("std_f3", "Label regimen: diarrhea days"), ("d_f1", "Escalation $-$ label: RMST"),
              ("d_f2", "Escalation $-$ label: neutropenia"), ("d_f3", "Escalation $-$ label: diarrhea days")]
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.6))
    res = {}
    for struct, col, off in (("time", NAVY, -0.2), ("exposure", ORANGE, 0.2)):
        d = json.load(open(os.path.join(ROOT, "calibration", f"sobol_{struct}.json")))
        res[struct] = d
    params = res["time"]["parameters"]
    for ax, (key, title) in zip(axes.ravel(), panels):
        st = {s: np.array([res[s]["outputs"][key]["total"][p][0] for p in params]) for s in res}
        order = np.argsort(-(st["time"] + st["exposure"]))[:6][::-1]
        y = np.arange(len(order))
        for struct, col, off in (("time", NAVY, -0.18), ("exposure", ORANGE, 0.18)):
            ax.barh(y + off, np.clip(st[struct][order], 0, None), height=0.34, color=col,
                    label="Time-based tolerance" if struct == "time" else "Exposure-based tolerance")
        ax.set_yticks(y, [names[params[i]] for i in order], fontsize=7)
        ax.set_xlim(0, 1)
        ax.set_title(title, fontsize=8)
        ax.tick_params(axis="x", labelsize=7)
        ax.spines[["top", "right"]].set_visible(False)
    for ax in axes[1]:
        ax.set_xlabel("Total-effect index")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=2, frameon=False)
    fig.savefig(os.path.join(FIG, "fig_sobol.pdf"))
    fig.savefig(os.path.join(FIG, "fig_sobol.png"))
    plt.close(fig)


# ------------------------------------------------------------------ ranks
def fig_ranks():
    summ = json.load(open(os.path.join(AN, "summary.json")))
    rows = {i: {r["alg"]: r for r in csv.DictReader(open(os.path.join(AN, "tables", f"e2_{i}.csv")))} for i in INST}
    from scipy.stats import rankdata
    R = np.array([rankdata([-float(rows[i][a]["hv_mean"]) for a in ALGS]) for i in INST]).T
    mean = R.mean(axis=1)
    order = np.argsort(mean)
    fig, ax = plt.subplots(figsize=(4.4, 5.2))
    im = ax.imshow(R[order], cmap="RdYlBu", vmin=1, vmax=20, aspect="auto")
    for r, a in enumerate(order):
        for c in range(4):
            mark = rows[INST[c]][ALGS[a]]["hv_mark"]
            ax.text(c, r, f"{int(R[a, c])}" + ("*" if mark == "best" else ("" if mark == "-" else "$^{\\approx}$")),
                    ha="center", va="center", fontsize=6.8, color="black")
        ax.text(4.0, r, f"{mean[a]:.2f}", ha="center", va="center", fontsize=6.8)
    ax.set_xticks(range(5), INST + ["Mean"])
    ax.set_xlim(-0.5, 4.5)
    ax.set_yticks(range(len(ALGS)), [NAMES[ALGS[a]] + (" (MOSI)" if ALGS[a] not in MOEA else "") for a in order],
                  fontsize=7)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
    cb.set_label("Rank of mean test HV", fontsize=7.5)
    cb.set_ticks([1, 5, 10, 15, 20])
    cb.ax.tick_params(labelsize=7)
    fig.savefig(os.path.join(FIG, "fig_ranks.pdf"))
    fig.savefig(os.path.join(FIG, "fig_ranks.png"))
    plt.close(fig)
    OUT["mean_rank"] = {a: float(m) for a, m in zip(ALGS, mean)}
    assert np.allclose([summ["friedman_mean_rank_hv"][a] for a in ALGS], mean)


# ------------------------------------------------------------------ batch versus test
def fig_generalization(fr):
    look = {x.tobytes(): i for i, x in enumerate(fr["P"])}
    Fb, Ft, feas_b, feas_t, run_id = [], [], [], [], []
    for q, r in enumerate(fr["runs"]):
        for x, f, g in zip(r["X"], r["F"], r["G"]):
            j = look[np.asarray(x, float).tobytes()]
            Fb.append(f), Ft.append(fr["F"][j]), feas_b.append(np.all(g <= 0)), feas_t.append(np.all(fr["G"][j] <= 0))
            run_id.append(q)
    Fb, Ft, feas_b, feas_t, run_id = map(np.array, (Fb, Ft, feas_b, feas_t, run_id))
    within = {}
    for j in range(3):
        rs = []
        for q in np.unique(run_id):
            m = (run_id == q) & feas_b
            if m.sum() >= 5 and np.std(Fb[m, j]) > 0 and np.std(Ft[m, j]) > 0:
                rs.append(np.corrcoef(Fb[m, j], Ft[m, j])[0, 1])
        within[j] = (float(np.median(rs)), float(np.percentile(rs, 25)), float(np.percentile(rs, 75)), len(rs))
    sel = feas_b
    rng = np.random.default_rng(1)
    k = rng.choice(np.nonzero(sel)[0], min(12000, sel.sum()), replace=False)
    lab = ["RMST (months)", "Grade $\\geq$3 neutropenia (%)", "Grade $\\geq$2 diarrhea days"]
    sc = [(-1, 1), (100, 1), (1, 1)]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6))
    for j, ax in enumerate(axes):
        b, t = Fb[k, j] * sc[j][0], Ft[k, j] * sc[j][0]
        ax.scatter(b[~feas_t[k]], t[~feas_t[k]], s=1.2, color=RED, alpha=0.35, lw=0, label="Infeasible on test")
        ax.scatter(b[feas_t[k]], t[feas_t[k]], s=1.2, color=NAVY, alpha=0.35, lw=0, label="Feasible on test")
        lo, hi = min(b.min(), t.min()), max(b.max(), t.max())
        ax.plot([lo, hi], [lo, hi], color="black", lw=0.7, ls="--")
        ax.set_xlabel(lab[j] + ", batch", fontsize=7.5)
        ax.set_ylabel(lab[j] + ", test", fontsize=7.5)
        ax.tick_params(labelsize=7)
        r = np.corrcoef(Fb[sel, j], Ft[sel, j])[0, 1]
        bias = float(np.mean((Ft[sel, j] - Fb[sel, j]) * sc[j][0]))
        ax.text(0.04, 0.95, f"within-run r = {within[j][0]:.2f}\nmean test $-$ batch = " + f"{bias:+.2f}".replace("-", "\u2212"),
                transform=ax.transAxes, va="top", fontsize=6.8)
        OUT.setdefault("generalization", {})[["f1", "f2", "f3"][j]] = {
            "r_pooled": float(r), "r_within_median_iqr_n": within[j], "mean_test_minus_batch": bias}
    h, l = axes[0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=2, frameon=False, markerscale=6)
    fig.savefig(os.path.join(FIG, "fig_generalization.pdf"))
    fig.savefig(os.path.join(FIG, "fig_generalization.png"))
    plt.close(fig)
    OUT["generalization"]["n_batch_feasible"] = int(sel.sum())
    OUT["generalization"]["frac_test_feasible_of_batch_feasible"] = float(feas_t[sel].mean())


# ------------------------------------------------------------------ decision variables on the P1 front
def fig_policy_vars(fr):
    X, F = fr["P"][fr["nd"]].copy(), fr["F"][fr["nd"]]
    X[:, 0] = np.minimum(X[:, 0], X[:, 1])          # effective starting dose (start above target is clipped)
    rm = -F[:, 0]
    t1, t2 = np.quantile(rm, [1 / 3, 2 / 3])
    groups = [(rm >= t2, "Highest RMST third", NAVY), ((rm >= t1) & (rm < t2), "Middle third", TEAL),
              (rm < t1, "Lowest RMST third", ORANGE)]
    spec = [(0, "Effective starting dose (mg)", [1, 2, 3], ["50", "100", "150"]), (1, "Target dose (mg)", [2, 3], ["100", "150"]),
            (2, "Escalation interval (days)", None, None), (3, "ANC threshold ($10^9$/L)", None, None),
            (4, "Diarrhea-free days $w$", None, None), (5, "Preventive reduction $n_{\\mathrm{pre}}$", [0, 1, 2, 3],
                                                       ["off", "1", "2", "3"]),
            (6, "Re-escalation delay (days)", None, None), (7, "Re-escalations $r_{\\max}$", [0, 1, 2], ["0", "1", "2"])]
    fig, axes = plt.subplots(2, 4, figsize=(7.2, 3.6))
    for ax, (j, title, cats, labels) in zip(axes.ravel(), spec):
        if cats is not None:
            w = 0.26
            for g, (m, lab, col) in enumerate(groups):
                frac = [np.mean(X[m, j] == c) for c in cats]
                ax.bar(np.arange(len(cats)) + (g - 1) * w, frac, width=w, color=col, label=lab)
            ax.set_xticks(range(len(cats)), labels)
            ax.set_ylim(0, 1)
        else:
            lo, hi = X[:, j].min(), X[:, j].max()
            bins = np.linspace(lo, hi, 12)
            for m, lab, col in groups:
                ax.hist(X[m, j], bins=bins, histtype="step", lw=1.1, color=col, density=True, label=lab)
            ax.set_yticks([])
        ax.set_title(title, fontsize=7.6)
        ax.tick_params(labelsize=6.8)
        ax.spines[["top", "right"]].set_visible(False)
    axes[0, 0].set_ylabel("Fraction of policies", fontsize=7.5)
    axes[1, 1].set_ylabel("Fraction of policies", fontsize=7.5)
    for a in (axes[0, 2], axes[0, 3], axes[1, 0], axes[1, 2]):
        a.set_ylabel("Density", fontsize=7.5)
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=3, frameon=False)
    fig.savefig(os.path.join(FIG, "fig_policy_vars.pdf"))
    fig.savefig(os.path.join(FIG, "fig_policy_vars.png"))
    plt.close(fig)
    OUT["policy_vars"] = {"rmst_tertiles": [float(t1), float(t2)], "n_front": int(len(X))}
    for m, lab, _ in groups:
        OUT["policy_vars"][lab] = {"start": {str(c): float(np.mean(X[m, 0] == c)) for c in (1, 2, 3)},
                                   "target150": float(np.mean(X[m, 1] == 3)),
                                   "n_pre_on": float(np.mean(X[m, 5] > 0)),
                                   "rmax2": float(np.mean(X[m, 7] == 2)), "rmax_ge1": float(np.mean(X[m, 7] >= 1)),
                                   "effective_start": {str(c): float(np.mean(X[m, 0] == c)) for c in (1, 2, 3)},
                                   "median_esc": float(np.median(X[m, 2])), "median_anc": float(np.median(X[m, 3])),
                                   "rmst_range": [float(rm[m].min()), float(rm[m].max())],
                                   "anc3_range": [float(F[m, 1].min()), float(F[m, 1].max())],
                                   "diar_range": [float(F[m, 2].min()), float(F[m, 2].max())]}


# ------------------------------------------------------------------ other instances
def fig_instances(frs):
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.7))
    for ax, inst in zip(axes, ["P2", "P3", "P4"]):
        fr = frs[inst]
        F = fr["F"][fr["nd"]]
        sc = ax.scatter(F[:, 2], -F[:, 0], c=100 * F[:, 1], s=4, cmap="viridis", lw=0)
        for i, mk, col, lab in ((fr["i_std"], "s", "black", "Label regimen"),
                                (fr["i_trade"], "^", "#2E7D32", "TRADE-like escalation")):
            f = fr["F"][i]
            ax.scatter(f[2], -f[0], marker=mk, s=34, facecolors=col if mk == "s" else "none", edgecolors=col,
                       lw=1.0, zorder=3, label=lab)
        k = fr["knee"]
        ax.scatter(fr["F"][k, 2], -fr["F"][k, 0], marker="o", s=34, facecolors="none", edgecolors="#F39C12", lw=1.0,
                   zorder=3, label="Knee policy")
        ax.set_xlabel("Grade $\\geq$2 diarrhea days")
        ax.set_ylabel("CVaR$_{0.2}$ of PFS (months)" if inst == "P4" else "RMST (months)")
        ax.set_title({"P2": "P2: second line", "P3": "P3: weekly schedule", "P4": "P4: worst 20% of patients"}[inst],
                     fontsize=8)
        ax.tick_params(labelsize=7)
        cb = fig.colorbar(sc, ax=ax, fraction=0.05, pad=0.02)
        cb.ax.tick_params(labelsize=6.5)
        cb.set_label("Grade $\\geq$3 neutropenia (%)", fontsize=7)
    h, l = axes[0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=3, frameon=False)
    fig.savefig(os.path.join(FIG, "fig_instances.pdf"))
    fig.savefig(os.path.join(FIG, "fig_instances.png"))
    plt.close(fig)


def fig_p3_schedules(fr):
    X, F = fr["P"][fr["nd"]], fr["F"][fr["nd"]]
    order = np.argsort(F[:, 0])            # highest RMST first
    X, F = X[order], F[order]
    fig = plt.figure(figsize=(7.2, 3.3))
    gs = fig.add_gridspec(1, 3, width_ratios=[5.2, 1.1, 1.1], wspace=0.08)
    ax = fig.add_subplot(gs[0])
    cmap = matplotlib.colors.ListedColormap(["#F2F2F2", "#C6DBEF", "#6BAED6", "#08519C"])
    ax.imshow(X, aspect="auto", cmap=cmap, vmin=-0.5, vmax=3.5, interpolation="nearest")
    ax.set_xticks(range(0, 24, 2), [str(w) for w in range(1, 25, 2)], fontsize=7)
    ax.set_xlabel("Week")
    ax.set_ylabel("Front schedules, ordered by RMST")
    ax.set_yticks([])
    handles = [matplotlib.patches.Patch(color=cmap(i), label=l) for i, l in
               enumerate(["Holiday", "50 mg", "100 mg", "150 mg"])]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=4, frameon=False, fontsize=7)
    y = np.arange(len(F))
    for col, (j, lab, s) in enumerate(((0, "RMST\n(months)", -1), (2, "Diarrhea\ndays", 1))):
        a2 = fig.add_subplot(gs[col + 1], sharey=ax)
        a2.plot(F[:, j] * s, y, color=NAVY if j == 0 else ORANGE, lw=1.0)
        a2.set_xlabel(lab, fontsize=7)
        a2.tick_params(labelsize=6.5, labelleft=False)
        a2.spines[["top", "right"]].set_visible(False)
    fig.savefig(os.path.join(FIG, "fig_p3_schedules.pdf"))
    fig.savefig(os.path.join(FIG, "fig_p3_schedules.png"))
    plt.close(fig)
    full = (X == 3).mean(axis=1)
    OUT["p3"] = {"n_front": int(len(X)), "frac_weeks_150_median": float(np.median(full)),
                 "first4_mean_level_top_third": float(X[: len(X) // 3, :4].mean()),
                 "first4_mean_level_bottom_third": float(X[-(len(X) // 3):, :4].mean()),
                 "holiday_any": float(np.mean((X == 0).any(axis=1))),
                 "rmst_range": [float(-F[:, 0].max()), float(-F[:, 0].min())],
                 "anc3_range": [float(F[:, 1].min()), float(F[:, 1].max())],
                 "diar_range": [float(F[:, 2].min()), float(F[:, 2].max())]}


# ------------------------------------------------------------------ tables
def table_reps():
    e3 = load("e3_P1.pkl")
    order = [("standard", "Label regimen"), ("trade", "TRADE-like"), ("knee", "Knee"), ("dominating", "Dominating"),
             ("best_f1", "Best RMST"), ("best_f2", "Best neutropenia"), ("best_f3", "Best diarrhea")]
    rows = [("Policy $\\boldsymbol{\\theta}$", None), ("RMST, months", "rmst"),
            ("Grade $\\geq$3 neutropenia, true, \\%", "anc3_true"), ("Grade $\\geq$3 neutropenia, detected, \\%", "anc3_detected"),
            ("Grade 4 neutropenia, \\%", "anc4_true"), ("Grade $\\geq$2 diarrhea days", "diar_days"),
            ("Grade $\\geq$2 diarrhea, \\%", "diar_incidence"), ("Median relative dose intensity", "median_rdi"),
            ("Any dose reduction, \\%", "reduced"), ("Discontinuation, \\%", "discontinued")]
    pct = {"anc3_true", "anc3_detected", "anc4_true", "diar_incidence", "reduced", "discontinued"}
    L = ["\\begin{tabular}{l" + "c" * len(order) + "}", "\\toprule",
         " & " + " & ".join(f"\\textbf{{{n}}}" for _, n in order) + "\\\\", "\\midrule"]
    for struct, head in (("time", "Time-based tolerance"), ("exposure", "Exposure-based tolerance")):
        L.append(f"\\multicolumn{{{len(order) + 1}}}{{l}}{{\\emph{{{head}}}}}\\\\")
        for lab, key in rows:
            if key is None:
                if struct == "exposure":
                    continue
                cells = []
                for name, _ in order:
                    x = e3["representatives"][name]["policy"]
                    cells.append(f"{50 * int(min(x[0], x[1]))}/{50 * int(x[1])}")
                L.append("Starting/target dose, mg & " + " & ".join(cells) + "\\\\")
                continue
            cells = []
            for name, _ in order:
                v = e3["representatives"][name][struct]["summary"][key]
                cells.append(r1(100 * v) if key in pct else f"{v:.2f}")
            L.append(lab + " & " + " & ".join(cells) + "\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    open(os.path.join(TAB, "table_reps.tex"), "w").write("\n".join(L) + "\n")
    OUT["reps_policies"] = {n: e3["representatives"][n]["policy"] for n, _ in order}
    OUT["reps_summary"] = {n: {s: e3["representatives"][n][s]["summary"] for s in ("time", "exposure")} for n, _ in order}


def big(v):
    """Integer with a thin thousands separator from 10,000 on, as in the text."""
    return f"{v:,.0f}".replace(",", "{,}") if v >= 10000 else f"{v:.0f}"


def table_p1_algs():
    rows = {r["alg"]: r for r in csv.DictReader(open(os.path.join(AN, "tables", "e2_P1.csv")))}
    L = ["\\begin{tabular}{lcccc}", "\\toprule",
         "\\textbf{Algorithm} & \\textbf{Feasible on test, \\%} & \\textbf{Runs without} & \\textbf{Non-dominated} & "
         "\\textbf{Evaluations to}\\\\",
         " & & \\textbf{feasible solution} & \\textbf{solutions} & \\textbf{95\\% of HV}\\\\", "\\midrule"]
    for a in ALGS:
        if a == ALGS[len(MOEA)]:
            L.append("\\midrule")
        r = rows[a]
        L.append(f"{NAMES[a]} & {r1(100 * float(r['feas_test']))} & {int(float(r['igdp_undefined_runs']))} & "
                 f"{r1(float(r['n_nd']))} & {big(float(r['fe95_median']))}\\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    open(os.path.join(TAB, "table_p1_algs.tex"), "w").write("\n".join(L) + "\n")


def table_instances(frs):
    lab = {"P1": "P1, first line", "P2": "P2, second line", "P3": "P3, weekly schedule", "P4": "P4, worst 20\\%"}
    L = ["\\begin{tabular}{llcccc}", "\\toprule",
         "\\textbf{Instance} & \\textbf{Policy} & \\textbf{Efficacy, months} & \\textbf{Neutropenia, \\%} & "
         "\\textbf{Diarrhea days} & \\textbf{Feasible}\\\\", "\\midrule"]
    OUT["instances"] = {}
    for inst in INST:
        fr = frs[inst]
        F, G = fr["F"], fr["G"]
        dom = fr["feas"] & np.all(F <= F[fr["i_std"]], axis=1) & np.any(F < F[fr["i_std"]], axis=1)
        k = fr["knee"]
        info = {"front": int(len(fr["nd"])), "n_dominating_label": int(dom.sum())}
        for name, i in (("Label regimen", fr["i_std"]), ("TRADE-like", fr["i_trade"]), ("Knee policy", k)):
            f = F[i]
            feas = "yes" if np.all(G[i] <= 0) else "no"
            first = lab[inst] if name == "Label regimen" else ""
            L.append(f"{first} & {name} & {-f[0]:.2f} & {r1(100 * f[1])} & {r1(f[2])} & {feas}\\\\")
            info[name] = {"f": [float(v) for v in f], "feasible": feas == "yes", "policy": fr["P"][i].tolist(),
                          "G": [float(v) for v in G[i]]}
        n_on = len(set(np.nonzero(dom)[0].tolist()) & set(np.asarray(fr["nd"]).tolist()))
        note = (f"{int(dom.sum())} feasible policies dominate the label regimen, {n_on} on the front"
                if dom.sum() else "no policy dominates the label regimen")
        L.append(f" & \\multicolumn{{5}}{{l}}{{\\footnotesize {len(fr['nd'])} front policies; {note}}}\\\\")
        if inst != "P4":
            L.append("\\midrule")
        OUT["instances"][inst] = info
    L += ["\\bottomrule", "\\end{tabular}"]
    open(os.path.join(TAB, "table_instances.tex"), "w").write("\n".join(L) + "\n")


def main():
    os.makedirs(FIG, exist_ok=True)
    frs = {}
    for inst in INST:
        frs[inst] = front(inst)
        frs[inst]["knee"] = knee(frs[inst], load(f"metrics_{inst}.pkl"))
    e3 = load("e3_P1.pkl")
    assert len(frs["P1"]["nd"]) == e3["n_nd"], "front definition differs from e3.py"
    assert np.array_equal(frs["P1"]["P"][frs["P1"]["knee"]], np.array(e3["representatives"]["knee"]["policy"]))
    fig_sobol()
    fig_ranks()
    fig_generalization(frs["P1"])
    fig_policy_vars(frs["P1"])
    fig_instances(frs)
    fig_p3_schedules(frs["P3"])
    table_reps()
    table_p1_algs()
    table_instances(frs)
    with open(os.path.join(AN, "extra_results.json"), "w") as fh:
        json.dump(OUT, fh, indent=1)
    print(json.dumps({k: OUT[k] for k in ("generalization", "p3", "instances")}, indent=1)[:4000])
    print(json.dumps(OUT["policy_vars"], indent=1))


if __name__ == "__main__":
    main()
