"""Independent validation population for the P1 policies selected on the test population.

The representative policies (label regimen, TRADE-like escalation, knee, dominating, best per objective) and all
test-feasible policies that dominate the label regimen are selected on the test population (seed 9,000,001). They are
re-evaluated here on a validation population that plays no part in any selection: the same 20-member ensemble,
500 virtual patients per member (10,000), seed 9,000,002. Paired differences from the label regimen use the same
validation patients, with 95% percentile bootstrap CIs (2000 resamples of patients), as in e3.py.

Twin Python on a compute node:  python scripts/analysis/validation.py
Writes analysis/validation_P1.json.
"""
import json
import os
import pickle
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from twin import problems  # noqa: E402
from e3 import paired_ci, per_patient, summary  # noqa: E402

VALIDATION_SEED = 9_000_002
INST = "P1"


def dominating_policies(an):
    """Test-feasible policies found by the runs that dominate the label regimen (same rule as e3.py)."""
    with open(os.path.join(an, f"test_{INST}.pkl"), "rb") as fh:
        test = pickle.load(fh)
    with open(os.path.join(an, f"runs_{INST}.pkl"), "rb") as fh:
        runs = pickle.load(fh)
    Pol, F, G = np.asarray(test["policies"], float), test["F"], test["G"]
    found = {np.asarray(x, float).tobytes() for r in runs for x in r["X"]}
    from_run = np.array([x.tobytes() in found for x in Pol])
    i_std = {x.tobytes(): i for i, x in enumerate(Pol)}[np.asarray(test["standard"], float).tobytes()]
    feas = np.all(G <= 0, axis=1) & from_run
    dom = feas & np.all(F <= F[i_std], axis=1) & np.any(F < F[i_std], axis=1)
    return Pol[dom]


def main():
    an = os.path.join(ROOT, "analysis")
    with open(os.path.join(an, f"e3_{INST}.pkl"), "rb") as fh:
        e3 = pickle.load(fh)
    reps = {k: np.asarray(v["policy"], float) for k, v in e3["representatives"].items()}
    std = reps["standard"]
    rng = np.random.default_rng(20261115)
    res = {"seed": VALIDATION_SEED, "n_per_member": 500, "representatives": {}}
    insts = {s: problems.Instance(os.path.join(ROOT, "calibration", f"ensemble_{s}.json"),
                                  os.path.join(ROOT, "calibration", f"stage3_{s}.json"),
                                  VALIDATION_SEED, n_per_member=500, name=INST) for s in ("time", "exposure")}
    base = {s: per_patient(insts[s], std) for s in insts}
    for name, x in reps.items():
        entry = {"policy": x.tolist()}
        for s, inst in insts.items():
            pp = per_patient(inst, x)
            Fs, Gs = inst.evaluate(x)
            entry[s] = {"summary": summary(pp), "objectives": Fs[0].tolist(), "constraints": Gs[0].tolist(),
                        "feasible": bool(np.all(Gs[0] <= 0)),
                        "diff_vs_standard": {k: paired_ci(pp[k], base[s][k], rng)
                                             for k in ("rmst", "anc3", "diar", "anc4", "disc")}}
        res["representatives"][name] = entry
    # every policy that dominated the label regimen on the test population
    D = dominating_policies(an)
    inst = insts["time"]
    Fd, Gd = inst.evaluate(D)
    f_std = inst.evaluate(std)[0][0]
    feas = np.all(Gd <= 0, axis=1)
    obj_dom = np.all(Fd <= f_std, axis=1) & np.any(Fd < f_std, axis=1)
    gain = f_std - Fd
    res["dominating_set"] = {
        "n": int(len(D)), "feasible": int(feas.sum()), "objectives_dominate": int(obj_dom.sum()),
        "still_dominating": int((feas & obj_dom).sum()),
        "violations": {"rdi": int((Gd[:, 0] > 0).sum()), "anc4": int((Gd[:, 1] > 0).sum()),
                       "disc": int((Gd[:, 2] > 0).sum())},
        "median_disc_excess_pp": float(100 * np.median(Gd[:, 2])),
        "max_gain": {"rmst_months": float(gain[:, 0].max()), "anc3_pp": float(100 * gain[:, 1].max()),
                     "diar_days": float(gain[:, 2].max())},
        "median_gain": {"rmst_months": float(np.median(gain[:, 0])), "anc3_pp": float(100 * np.median(gain[:, 1])),
                        "diar_days": float(np.median(gain[:, 2]))}}
    with open(os.path.join(an, f"validation_{INST}.json"), "w") as fh:
        json.dump(res, fh, indent=1)
    print(json.dumps(res["dominating_set"], indent=1))
    for name in ("standard", "trade", "knee", "dominating"):
        t = res["representatives"][name]["time"]
        print(name, "feasible", t["feasible"], "G", np.round(t["constraints"], 4).tolist(),
              {k: np.round(v, 4).tolist() for k, v in t["diff_vs_standard"].items()})


if __name__ == "__main__":
    main()
