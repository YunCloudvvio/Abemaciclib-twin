"""Figure 1: study overview (schematic). a, virtual population; b, digital twin loop; c, multi-objective optimization.
The small curves are schematic illustrations, not data. Usage:
    python scripts/analysis/fig_twin.py paper/figures
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle  # noqa: E402

for f in font_manager.findSystemFonts(os.path.expanduser("~/.local/share/fonts")):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "Times New Roman", "mathtext.fontset": "stix", "savefig.dpi": 400,
                     "savefig.bbox": "tight", "savefig.pad_inches": 0.02})

# palette (muted, colour-blind safe)
NAVY, TEAL, RED, BLUE, ORANGE, GREY, PURPLE = "#3C5488", "#00A087", "#C0392B", "#4DBBD5", "#E08E45", "#7F8C8D", "#8E6BB0"
INK = "#2B2B2B"

out = sys.argv[1] if len(sys.argv) > 1 else "paper/figures"
W, H = 100.0, 60.0
fig = plt.figure(figsize=(7.2, 7.2 * H / W))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, W)
ax.set_ylim(0, H)
ax.axis("off")


def lighten(c, a=0.86):
    rgb = np.array(matplotlib.colors.to_rgb(c))
    return tuple(rgb + (1 - rgb) * a)


CARD_ICONS = []


def header_band(x, y, w, h, r, color):
    """Header band with rounded top corners and a straight bottom edge (one path, same stroke as the card)."""
    from matplotlib.path import Path
    from matplotlib.patches import PathPatch
    k = 0.5523 * r                      # cubic Bezier approximation of a quarter circle
    verts = [(x, y), (x + w, y), (x + w, y + h - r),
             (x + w, y + h - r + k), (x + w - r + k, y + h), (x + w - r, y + h),
             (x + r, y + h),
             (x + r - k, y + h), (x, y + h - r + k), (x, y + h - r),
             (x, y)]
    codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.LINETO,
             Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    return PathPatch(Path(verts, codes), fc=color, ec=color, lw=0.9, joinstyle="round", zorder=3)



def card(x, y, w, h, color, title, body=None, title_size=7.0, body_size=6.6, header=3.0, body_dy=1.4, icon_kind=None,
         center=True):
    """Rounded card with a coloured header band."""
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.0", fc="none",
                                ec=color, lw=0.9, zorder=2))
    ax.add_patch(header_band(x, y + h - header, w, header, 1.0, color))
    ax.text(x + w / 2, y + h - header / 2, title, ha="center", va="center", color="white", fontsize=title_size,
            fontweight="bold", zorder=4)
    if icon_kind:
        CARD_ICONS.append((icon_kind, x + 0.1, y + h + 0.1, color))
    if body and center:          # body text centred in the body area
        ax.text(x + w / 2, y + (h - header) / 2, body, ha="center", va="center", color=INK, fontsize=body_size,
                linespacing=1.25, zorder=4)
    elif body:                   # body text at the top, schematic curve below
        ax.text(x + w / 2, y + h - header - body_dy, body, ha="center", va="top", color=INK, fontsize=body_size,
                linespacing=1.25, zorder=4)


def panel(x, y, w, h, color, letter, title):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.6", fc=lighten(color, 0.93),
                                ec=lighten(color, 0.55), lw=0.8, zorder=0))
    ax.text(x + 1.2, y + h - 1.6, letter, ha="left", va="center", fontsize=10, fontweight="bold", color=INK)
    ax.text(x + 4.0, y + h - 1.6, title, ha="left", va="center", fontsize=8.2, fontweight="bold", color=color)


def arrow(p, q, color=INK, lw=1.0, style="-|>", rad=0.0, ls="-", z=5):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle=style, mutation_scale=8, lw=lw, color=color, linestyle=ls,
                                 connectionstyle=f"arc3,rad={rad}", shrinkA=0, shrinkB=0, zorder=z))


def poly(points, color=INK, lw=1.0, ls="-", head=True):
    xs, ys = zip(*points)
    ax.plot(xs[:-1] if head else xs, ys[:-1] if head else ys, color=color, lw=lw, ls=ls, zorder=5,
            solid_capstyle="butt")
    if head:
        arrow(points[-2], points[-1], color=color, lw=lw)


def inset(x, y, w, h, kind, color):
    """Schematic mini-plot drawn in data coordinates of the main axes."""
    t = np.linspace(0, 1, 200)
    if kind == "pk":
        k = np.arange(0, 1, 1 / 7.0)
        c = sum(np.where(t >= s, np.exp(-(t - s) * 9) - np.exp(-(t - s) * 40), 0) for s in k)
        yv = c / c.max()
    elif kind == "anc":
        yv = 1 - 0.55 * (1 - np.exp(-t * 7)) + 0.08 * np.sin(t * 9) * np.exp(-t * 3)
        yv = (yv - 0.35) / 0.7
    elif kind == "diar":
        steps = np.array([0, 1, 2, 2, 1, 0, 1, 1, 0, 0, 0, 0])
        yv = steps[np.minimum((t * len(steps)).astype(int), len(steps) - 1)] / 2.4 + 0.08
    elif kind == "tumor":
        yv = 0.85 - 0.5 * (1 - np.exp(-t * 5)) + 0.45 * np.clip(t - 0.55, 0, None) ** 1.3
    elif kind == "front":
        xx = np.linspace(0.05, 0.95, 26)
        yy = 1 - (1 - (1 - xx) ** 2) ** 0.5 * 0.9
        ax.scatter(x + xx * w, y + (1 - yy) * h * 0.9, s=2.2, color=color, zorder=6, lw=0)
        ax.scatter([x + 0.93 * w], [y + 0.88 * h], marker="s", s=9, color=INK, zorder=7, lw=0)
        fx, fy = xx, (1 - yy) * 0.9
        kk = int(np.argmin(np.hypot(fx, 0.9 - fy)))           # closest to the ideal corner (low toxicity, high efficacy)
        ax.scatter([x + fx[kk] * w], [y + fy[kk] * h], s=22, facecolors="none", edgecolors="#F39C12", lw=1.0,
                   zorder=8)
        ax.text(x + fx[kk] * w - 0.5, y + fy[kk] * h + 0.6, "knee", ha="right", va="bottom", fontsize=6.0,
                color="#D35400", zorder=8)
        ax.plot([x, x, x + w], [y + h, y, y], color=GREY, lw=0.5, zorder=6)
        return
    ax.plot(x + t * w, y + np.clip(yv, 0, 1) * h, color=color, lw=0.9, zorder=6)
    ax.plot([x, x, x + w], [y + h, y, y], color=GREY, lw=0.5, zorder=6)



# ------------------------------------------------------------------ icons (simple vector glyphs inside round badges)
from matplotlib.patches import Circle, Ellipse, Polygon, Wedge  # noqa: E402
from matplotlib.transforms import Affine2D  # noqa: E402


def _rot(patch, cx, cy, deg):
    patch.set_transform(Affine2D().rotate_deg_around(cx, cy, deg) + ax.transData)
    return patch


def icon(kind, cx, cy, c, r=1.25):
    z = 9
    if kind == "pill":
        w, h = 2.0 * r, 0.95 * r
        a = FancyBboxPatch((cx - w / 2, cy - h / 2), w / 2, h, boxstyle=f"round,pad=0,rounding_size={h / 2}",
                           fc=c, ec=c, lw=0.6, zorder=z)
        b = FancyBboxPatch((cx, cy - h / 2), w / 2, h, boxstyle=f"round,pad=0,rounding_size={h / 2}",
                           fc="white", ec=c, lw=0.8, zorder=z)
        for p_ in (_rot(a, cx, cy, 40), _rot(b, cx, cy, 40)):
            ax.add_patch(p_)
    elif kind == "pk":
        t = np.linspace(0, 1, 60)
        y = (np.exp(-t * 3) - np.exp(-t * 18)) / 0.62
        ax.plot(cx - r + t * 2 * r, cy - 0.8 * r + y * 1.5 * r, color=c, lw=1.1, zorder=z)
        ax.plot([cx - r, cx - r, cx + r], [cy + 0.8 * r, cy - 0.8 * r, cy - 0.8 * r], color=c, lw=0.7, zorder=z)
    elif kind == "tumor":
        rng = np.random.default_rng(3)
        ang = np.linspace(0, 2 * np.pi, 13)[:-1]
        rad = r * (0.78 + 0.22 * rng.random(12))
        ax.add_patch(Polygon(np.c_[cx + rad * np.cos(ang), cy + rad * np.sin(ang)], closed=True, fc=lighten(c, 0.55),
                             ec=c, lw=0.8, zorder=z, joinstyle="round"))
        for dx, dy in ((-0.3, 0.2), (0.35, 0.15), (0.0, -0.35)):
            ax.add_patch(Circle((cx + dx * r, cy + dy * r), 0.17 * r, fc=c, ec="none", zorder=z + 1))
    elif kind == "neutrophil":
        ax.add_patch(Circle((cx, cy), r, fc=lighten(c, 0.6), ec=c, lw=0.8, zorder=z))
        for dx, dy in ((-0.38, 0.12), (0.0, -0.25), (0.38, 0.12)):
            ax.add_patch(Circle((cx + dx * r, cy + dy * r), 0.28 * r, fc=c, ec="none", zorder=z + 1))
    elif kind == "gut":
        t = np.linspace(0, 1, 200)
        x = cx - 0.9 * r + 1.8 * r * t
        y = cy + 0.55 * r * np.sin(t * 3 * np.pi)
        ax.plot(x, y, color=c, lw=2.2, solid_capstyle="round", zorder=z)
        ax.plot(x, y, color="white", lw=0.8, solid_capstyle="round", zorder=z + 1)
    elif kind == "warning":
        ax.add_patch(Polygon([(cx - r, cy - 0.8 * r), (cx + r, cy - 0.8 * r), (cx, cy + 0.95 * r)], closed=True,
                             fc=c, ec=c, lw=0.8, joinstyle="round", zorder=z))
        ax.text(cx, cy - 0.12 * r, "!", ha="center", va="center", color="white", fontsize=6.5, fontweight="bold",
                zorder=z + 1)
    elif kind == "clipboard":
        ax.add_patch(FancyBboxPatch((cx - 0.75 * r, cy - r), 1.5 * r, 1.85 * r, boxstyle="round,pad=0,rounding_size=0.2",
                                    fc="white", ec=c, lw=0.9, zorder=z))
        ax.add_patch(Rectangle((cx - 0.35 * r, cy + 0.68 * r), 0.7 * r, 0.32 * r, fc=c, ec="none", zorder=z + 1))
        for k in range(3):
            yy = cy + 0.3 * r - k * 0.45 * r
            ax.plot([cx - 0.45 * r, cx + 0.45 * r], [yy, yy], color=c, lw=0.8, zorder=z + 1)
    elif kind == "sliders":
        for k, pos in enumerate((0.3, 0.7, 0.45)):
            yy = cy + (0.6 - 0.6 * k) * r
            ax.plot([cx - r, cx + r], [yy, yy], color=c, lw=0.9, zorder=z)
            ax.add_patch(Circle((cx - r + 2 * r * pos, yy), 0.24 * r, fc="white", ec=c, lw=0.9, zorder=z + 1))
    elif kind == "person":
        ax.add_patch(Circle((cx, cy + 0.42 * r), 0.36 * r, fc=c, ec="none", zorder=z))
        ax.add_patch(Wedge((cx, cy - 0.85 * r), 0.85 * r, 0, 180, fc=c, ec="none", zorder=z))
    elif kind == "network":
        pts = [(cx - 0.75 * r, cy - 0.5 * r), (cx + 0.75 * r, cy - 0.5 * r), (cx, cy + 0.75 * r), (cx, cy - 0.05 * r)]
        for i_, j_ in ((0, 1), (0, 2), (1, 2), (0, 3), (1, 3), (2, 3)):
            ax.plot([pts[i_][0], pts[j_][0]], [pts[i_][1], pts[j_][1]], color=c, lw=0.7, zorder=z)
        for k, (px, py) in enumerate(pts):
            ax.add_patch(Circle((px, py), 0.24 * r, fc=c if k < 3 else "white", ec=c, lw=0.8, zorder=z + 1))
    elif kind == "target":
        for k, rr in enumerate((1.0, 0.66, 0.32)):
            ax.add_patch(Circle((cx, cy), rr * r, fc=c if k % 2 == 0 else "white", ec=c, lw=0.6, zorder=z + k))
    elif kind == "scatter":
        ax.plot([cx - r, cx - r, cx + r], [cy + r, cy - r, cy - r], color=c, lw=0.7, zorder=z)
        t = np.linspace(0.1, 0.9, 6)
        ax.scatter(cx - r + t * 2 * r, cy - r + (np.sqrt(1 - (1 - t) ** 2)) * 1.6 * r, s=3.5, color=c, zorder=z + 1,
                   lw=0)


def badge(kind, cx, cy, color, rad=1.2):
    ax.add_patch(Circle((cx, cy), rad, fc="white", ec=color, lw=1.0, zorder=8))
    icon(kind, cx, cy, color, r=rad * 0.62)

# ------------------------------------------------------------------ panel a: virtual population
PT = 59.5      # top of the panels
panel(0.5, 0.5, 22.5, PT - 0.5, NAVY, "a", "Virtual population")
ax.text(11.75, 55.2, "Calibration data", ha="center", va="center", fontsize=6.6, color=NAVY, fontweight="bold")
ax.text(11.75, 52.7, "MONARCH 1, MONARCH 2,\nMONARCH 3 control arm", ha="center", va="center", fontsize=6.4,
        color=NAVY, linespacing=1.2)
arrow((11.75, 51.2), (11.75, 48.8), color=NAVY)
for k in range(4, -1, -1):
    ax.add_patch(FancyBboxPatch((3.2 + 0.9 * k, 34.0 + 1.0 * k), 13.5, 10.6, boxstyle="round,pad=0,rounding_size=0.8",
                                fc=lighten(NAVY, 0.93) if k == 0 else lighten(NAVY, 0.8 - 0.08 * k), ec=NAVY, lw=0.7, zorder=2))
ax.text(9.95, 40.9, "20 calibrated\nparameter sets", ha="center", va="center", fontsize=7.2, color=INK, zorder=4,
        linespacing=1.2)
ax.text(9.95, 37.3, r"$\chi^2$ likelihood region", ha="center", va="center", fontsize=6.3, color=GREY, zorder=4,
        style="italic")
arrow((11.75, 33.4), (11.75, 30.0), color=NAVY)
card(2.5, 18.0, 18.5, 11.6, NAVY, "Virtual patients",
     "between-patient variability\nMONARCH covariates:\nmeasurable disease, liver\nmetastases, performance status", icon_kind="person")
for i in range(7):
    cx = 4.6 + i * 2.35
    ax.add_patch(plt.Circle((cx, 12.4), 0.62, color=lighten(NAVY, 0.25), zorder=3, lw=0))
    ax.add_patch(FancyBboxPatch((cx - 0.85, 9.6), 1.7, 2.0, boxstyle="round,pad=0,rounding_size=0.6",
                                fc=lighten(NAVY, 0.25), ec="none", zorder=3))
ax.text(11.75, 5.0, "200 per optimization run\n10,000 test patients", ha="center", va="center", fontsize=6.4,
        color=INK, linespacing=1.2)

# ------------------------------------------------------------------ panel b: digital twin
panel(24.5, 0.5, 49.5, PT - 0.5, TEAL, "b", "Digital twin of abemaciclib treatment")
TOP_Y = 40.0
card(26.0, TOP_Y, 14.0, 11.5, NAVY, "Dosing", "policy $\\theta$ and\nlabel rules:\n150 / 100 / 50 mg", icon_kind="pill")
card(44.5, TOP_Y, 12.25, 11.5, TEAL, "Pharmacokinetics", "concentration $C(t)$", icon_kind="pk", center=False)
inset(45.9, TOP_Y + 0.9, 9.5, 3.8, "pk", TEAL)
arrow((40.0, TOP_Y + 6.2), (44.5, TOP_Y + 6.2))
ax.text(42.25, TOP_Y + 7.1, "dose", ha="center", fontsize=6.2, style="italic", color=INK)
card(58.75, TOP_Y, 12.25, 11.5, PURPLE, "Tumor and PFS", "size $S(t)$, hazard $h(t)$", body_size=6.4, icon_kind="tumor",
     center=False)
inset(60.1, TOP_Y + 0.9, 9.5, 3.8, "tumor", PURPLE)
arrow((56.75, TOP_Y + 6.2), (58.75, TOP_Y + 6.2))
# toxicity group
GX, GY, GW, GH = 43.0, 9.6, 29.5, 27.4
ax.add_patch(FancyBboxPatch((GX, GY), GW, GH, boxstyle="round,pad=0,rounding_size=1.0", fc=lighten(RED, 0.95),
                            ec=lighten(RED, 0.35), lw=0.8, ls=(0, (3, 2)), zorder=1))
ax.text(GX + GW - 1.0, GY + GH - 1.5, "Toxicity", ha="right", va="center", fontsize=6.8, style="italic", color=RED)
card(44.5, 21.6, 12.25, 12.0, RED, "Neutrophils", "Friberg model\nlinear drug effect", icon_kind="neutrophil", center=False)
inset(45.9, 22.5, 9.5, 3.4, "anc", RED)
card(58.75, 21.6, 12.25, 12.0, ORANGE, "Diarrhea", "Markov chain\ngrades 0–3", icon_kind="gut", center=False)
inset(60.1, 22.5, 9.5, 3.4, "diar", ORANGE)
card(44.5, 10.6, 26.5, 7.4, GREY, "Other adverse reactions", "dose reductions and discontinuations", icon_kind="warning")
arrow((50.625, TOP_Y), (50.625, GY + GH), color=TEAL)
ax.text(51.3, (TOP_Y + GY + GH) / 2, "$C(t)$", ha="left", va="center", fontsize=6.6, color=TEAL)
# observation and feedback through the label rules
card(26.0, 21.6, 14.0, 12.0, GREY, "Clinical observation", "blood counts every\n2 weeks, then monthly,\nthen every 12 weeks;\ndiarrhea grade", icon_kind="clipboard")
arrow((GX, 27.6), (40.0, 27.6), color=RED)
arrow((33.0, 33.6), (33.0, TOP_Y), color=INK)
ax.text(33.8, 36.8, "hold\nreduce\nstop", ha="left", va="center", fontsize=6.2, style="italic", color=INK,
        linespacing=1.15)
ax.text(49.25, 5.0, "6 h steps over 24 months or until progression; verified against an adaptive solver",
        ha="center", va="center", fontsize=6.2, color=GREY, style="italic")

# ------------------------------------------------------------------ panel c: optimization
panel(75.5, 0.5, 24.0, PT - 0.5, RED, "c", "Multi-objective optimization")
card(77.5, 42.0, 20.0, 9.5, RED, "20 algorithms", "10 MOEAs and 10 MOSI\npopulation 100, 30 runs\n10,000 evaluations", icon_kind="network")
card(77.5, 25.7, 20.0, 12.8, NAVY, "Objectives",
     "$f_1$: $-$RMST over 24 months\n$f_2$: grade $\\geq$3 neutropenia\n$f_3$: grade $\\geq$2 diarrhea days, 6 months\n"
     "constraints: dose intensity,\ngrade 4 neutropenia, discontinuation", body_size=6.1, icon_kind="target")
card(77.5, 9.6, 20.0, 12.6, TEAL, "Pareto front", None, icon_kind="scatter")
inset(81.2, 11.9, 13.5, 6.0, "front", TEAL)
ax.text(87.95, 11.4, "toxicity", ha="center", va="top", fontsize=6.0, color=GREY)
ax.text(80.5, 14.9, "efficacy", ha="center", va="center", fontsize=6.0, color=GREY, rotation=90)
ax.text(93.1, 18.15, "label regimen", ha="right", va="center", fontsize=6.0, color=INK)
ax.text(87.5, 5.0, "re-evaluated on test patients", ha="center", va="center", fontsize=6.2, color=GREY,
        style="italic")
arrow((87.5, 42.0), (87.5, 38.5), color=RED)
arrow((87.5, 25.7), (87.5, 22.2), color=NAVY)
# links between panels
poly([(77.5, 46.75), (75.0, 46.75), (75.0, 55.0), (33.0, 55.0), (33.0, TOP_Y + 11.5)], color=RED, lw=1.0)
ax.text(54.5, 55.8, "candidate policy $\\theta$", ha="center", va="bottom", fontsize=6.6, color=RED, style="italic")
poly([(71.0, TOP_Y + 6.2), (73.3, TOP_Y + 6.2), (73.3, 32.0), (77.5, 32.0)], color=PURPLE, lw=1.0)
poly([(GX + GW, 27.6), (74.8, 27.6), (74.8, 30.0), (77.5, 30.0)], color=RED, lw=1.0)
poly([(21.0, 23.8), (23.75, 23.8), (23.75, TOP_Y + 3.0), (26.0, TOP_Y + 3.0)], color=NAVY, lw=1.0)

badge("sliders", 3.3, 44.7, NAVY)
for kind, bx, by, col in CARD_ICONS:
    badge(kind, bx, by, col)
fig.savefig(os.path.join(out, "fig_twin.pdf"))
fig.savefig(os.path.join(out, "fig_twin.png"))
print("fig_twin done")
