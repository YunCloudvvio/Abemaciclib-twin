"""Why do the policies dominating the standard policy (time-based tolerance) not dominate it with
exposure-based tolerance? Re-evaluates them on the exposure-structure test population and splits the reasons:
objectives no worse / strictly better in one, and each constraint. Writes analysis/e3_robust_<inst>.json."""
import argparse
import json
import os
import pickle
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from twin import problems  # noqa: E402
from test_eval import TEST_SEED  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inst", default="P1")
    ap.add_argument("--analysis", default=os.path.join(ROOT, "analysis"))
    args = ap.parse_args()
    with open(os.path.join(args.analysis, f"test_{args.inst}.pkl"), "rb") as fh:
        test = pickle.load(fh)
    with open(os.path.join(args.analysis, f"runs_{args.inst}.pkl"), "rb") as fh:
        runs = pickle.load(fh)
    Pol, F, G = test["policies"], test["F"], test["G"]
    found = {np.asarray(x, float).tobytes() for r in runs for x in r["X"]}
    from_run = np.array([x.tobytes() in found for x in np.asarray(Pol, float)])
    i_std = {x.tobytes(): i for i, x in enumerate(Pol)}[np.asarray(test["standard"], float).tobytes()]
    feas = np.all(G <= 0, axis=1) & from_run
    dom = feas & np.all(F <= F[i_std], axis=1) & np.any(F < F[i_std], axis=1)
    di = np.nonzero(dom)[0]
    inst = problems.Instance(os.path.join(ROOT, "calibration", "ensemble_exposure.json"),
                             os.path.join(ROOT, "calibration", "stage3_exposure.json"), TEST_SEED, n_per_member=500,
                             name=args.inst)
    Fe, Ge = inst.evaluate(Pol[di])
    fs = inst.evaluate(test["standard"])[0][0]
    weak = np.all(Fe <= fs, axis=1)
    strict = weak & np.any(Fe < fs, axis=1)
    res = {"n_dominating_time": int(len(di)), "objectives_dominate_exposure": int(strict.sum()),
           "feasible_exposure": int(np.all(Ge <= 0, axis=1).sum()),
           "constraint_violated_exposure": {k: int((Ge[:, c] > 0).sum()) for c, k in enumerate(("rdi", "anc4", "disc"))},
           "objective_worse_exposure": {k: int((Fe[:, c] > fs[c]).sum()) for c, k in enumerate(("f1", "f2", "f3"))},
           "both": int((strict & np.all(Ge <= 0, axis=1)).sum()),
           "max_disc_excess": float(Ge[:, 2].max()), "median_disc_excess": float(np.median(Ge[:, 2])),
           "max_anc4_excess": float(Ge[:, 1].max())}
    with open(os.path.join(args.analysis, f"e3_robust_{args.inst}.json"), "w") as fh:
        json.dump(res, fh, indent=1)
    print(res)


if __name__ == "__main__":
    main()
