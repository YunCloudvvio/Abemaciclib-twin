"""Task list of the main experiment: one line per independent run (instance, algorithm, seed).

20 algorithms (10 PlatEMO MOEAs under Octave, 10 MOSI Python ports) x instances x 30 seeds,
N = 100, 10,000 evaluations. Seed k (3,000,001-3,000,030) fixes both the
algorithm's random numbers and the SAA patient batch of the run, so all algorithms meet the same
patients in run k (common random numbers).

Run from the project root:  python scripts/make_tasks.py --instances P1 P2 P3 P4 --out results/tasks.txt
"""
import argparse
import os

MOEA = ["SPEA2", "NSGAII", "GDE3", "MOEADDE", "NSGAIII", "AGEMOEAII", "LMPFE", "CMOES", "APSEA", "CMOCEADDAP"]
MOSI = ["M001_MOGWO", "M004_MSSA", "M014_MOAVOA", "M103_MOCGO", "M105_MOEOSMA", "M212_MOGNDO",
        "M231_MORIME", "M306_MaOMPA", "M315_MOSRS", "M323_C-MOBRO"]
SEED0 = 3_000_000


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--instances", nargs="+", default=["P1", "P2", "P3", "P4"])
    ap.add_argument("--runs", type=int, default=30)
    ap.add_argument("--algs", nargs="*", default=MOEA + MOSI)
    ap.add_argument("--out", default="results/tasks.txt")
    args = ap.parse_args()
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    n = 0
    with open(args.out, "w") as f:
        for inst in args.instances:
            for k in range(1, args.runs + 1):            # seed-major: early chunks cover every algorithm
                for alg in args.algs:
                    kind = "moea" if alg in MOEA else "mosi"
                    f.write(f"{inst} {kind} {alg} {SEED0 + k}\n")
                    n += 1
    print(f"{n} tasks -> {args.out}")


if __name__ == "__main__":
    main()
