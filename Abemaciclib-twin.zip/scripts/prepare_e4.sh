#!/bin/bash
# prepare_e4.sh ALG1 ALG2 ALG3 : E4 task list and the base cell (links to the main-experiment runs, seeds 1-10).
set -eu
cd "$(dirname "$0")/.."
PY=${PYTHON:-python}
$PY scripts/make_e4_tasks.py --algs "$@" --out results_e4/tasks.txt
for A in "$@"; do
  mkdir -p results_e4/base/time/P1/$A
  for k in $(seq 1 10); do
    for f in results/time/P1/$A/seed$((3000000 + k)).mat results/time/P1/$A/seed$((3000000 + k)).npz; do
      [ -s $f ] && ln -sfn ../../../../../$f results_e4/base/time/P1/$A/$(basename $f)
    done
  done
  ls -L results_e4/base/time/P1/$A | wc -l
done
