"""Numerical verification of the simulation kernel.

1. Fixed-step kernel against an adaptive ODE solver (LSODA, rtol 1e-9) on 100
   virtual patients with their own PK, neutrophil and tumour parameters, at 150 mg
   without dose modification: relative error of ANC and tumour size at days
   14, 28, 56, 112, 180.
2. Diarrhoea chain: with exposure- and time-independent rates the grade
   occupancy must match the stationary distribution of the birth-death chain.

Run from the project root:  python scripts/verify_numerics.py
Writes calibration/verify_numerics.json.
"""
import json
import math
import os
import sys

import numpy as np
from scipy.integrate import solve_ivp

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from twin import kernel as K  # noqa: E402
from twin import params as P  # noqa: E402
from twin import population as pm  # noqa: E402

DAYS = (13, 27, 55, 111, 179)   # trace rows = end of day 14, 28, 56, 112, 180


def reference(pop_row, n_days):
    ka, ke, vol = pop_row[pm.C_KA], pop_row[pm.C_KE], pop_row[pm.C_V]
    ktr, base, gamma, slope = pop_row[pm.C_KTR], pop_row[pm.C_ANC_BASE], pop_row[pm.C_GAMMA], pop_row[pm.C_SLOPE]
    s0, kgrow, ktrans = pop_row[pm.C_S0], pop_row[pm.C_KGROW], pop_row[pm.C_KTRANS]
    e_et, e_abe, resist, delay = pop_row[pm.C_E_ET], pop_row[pm.C_E_ABE], pop_row[pm.C_RESIST], pop_row[pm.C_DELAY]
    mw = P.MW_ABEMA / 1000.0

    def rhs(t, y):
        gut, cen, prol, t1, t2, t3, circ, h, d1, d2, d3 = y
        conc = cen / vol
        fb = (base / max(circ, 1e-3)) ** gamma
        t_wk = t / 168.0
        decay = math.exp(-resist * max(0.0, t_wk - delay))
        ks = (e_et + e_abe * conc / mw) * decay / 168.0
        kt = ktrans / 168.0
        return [-ka * gut, ka * gut - ke * cen,
                ktr * prol * ((1.0 - slope * conc) * fb - 1.0),
                ktr * (prol - t1), ktr * (t1 - t2), ktr * (t2 - t3), ktr * (t3 - circ),
                kgrow / 168.0 - ks * h, ks * h - kt * d1, kt * (d1 - d2), kt * (d2 - d3)]

    y = np.array([0.0, 0.0] + [base] * 5 + [s0, 0.0, 0.0, 0.0])
    res = {}
    dose = 150.0 * (P.PK_F_INTERCEPT + P.PK_F_SLOPE * 150.0)
    for j in range(n_days * 2):
        y[0] += dose
        y = solve_ivp(rhs, (j * 12.0, j * 12.0 + 12.0), y, method="LSODA", rtol=1e-9, atol=1e-12).y[:, -1]
        if j % 2 == 1:
            res[j // 2] = (y[6], y[7:].sum())
    return res


def check_odes(n=100, n_days=180):
    pop = pm.sample_patients(n, seed=9001)
    pop[:, pm.C_MEAS] = 1.0
    pop[:, pm.C_KGROW] = np.minimum(pop[:, pm.C_KGROW], 1.0)   # keep tumours finite in the reference solver
    pop[:, pm.C_SLOPE] = np.minimum(pop[:, pm.C_SLOPE], 1.5)    # no ANC collapse to the 1e-3 floor
    no_rules = np.zeros(n_days + 1, dtype=np.bool_)             # no blood counts -> no neutropenia rule
    dcon = pm.diarrhoea_constants()
    dcon[:3] = 0.0                                              # no diarrhoea -> no diarrhoea rule
    dcon[11:14] = 0.0                                           # no other adverse reactions
    errors_anc, errors_ts = [], []
    for i in range(n):
        out = np.zeros((1, K.N_OUT))
        trace = np.zeros((n_days, K.N_TRACE))
        u = np.full((1, n_days * P.STEPS_PER_DAY), 0.9, dtype=np.float32)
        K.simulate(K.standard_policy(), pop[i:i + 1], np.array([1e9]), u, no_rules, dcon,
                   pm.pk_constants(), n_days, out, trace)
        ref = reference(pop[i], n_days)
        for d in DAYS:
            errors_anc.append(abs(trace[d, K.TR_ANC] / ref[d][0] - 1.0))
            errors_ts.append(abs(trace[d, K.TR_TUMOUR] / ref[d][1] - 1.0))
    return {"n_patients": n, "anc_max_rel_error": float(np.max(errors_anc)),
            "anc_p95_rel_error": float(np.percentile(errors_anc, 95)),
            "tumour_max_rel_error": float(np.max(errors_ts)),
            "tumour_p95_rel_error": float(np.percentile(errors_ts, 95))}


def check_diarrhoea_chain(n=2000, n_days=730, burn_in=100):
    pop = pm.sample_patients(n, seed=9002)
    pop[:, pm.C_DI_MULT] = 1.0
    pop[:, pm.C_SLOPE] = 0.0
    pop[:, pm.C_G2_STRICT] = 0.0
    threshold = np.full(n, 1e9)
    u = np.random.default_rng(9003).random((n, n_days * P.STEPS_PER_DAY), dtype=np.float32)
    dcon = pm.diarrhoea_constants()
    # Per hour, constant (beta = 0, no tolerance). No 2 -> 3 transition: grade 3 would trigger
    # holds and reductions and finally discontinuation, which switches the chain off.
    dcon[0:3] = [0.004, 0.003, 0.0]
    dcon[6] = 0.0
    dcon[7] = 0.0
    dcon[11:14] = 0.0
    trace_grades = np.zeros((n, n_days))
    # Grade occupancy from the daily trace of each patient (trace holds patient 0 only).
    for i in range(n):
        out = np.zeros((1, K.N_OUT))
        trace = np.zeros((n_days, K.N_TRACE))
        K.simulate(K.standard_policy(), pop[i:i + 1], threshold[i:i + 1], u[i:i + 1], pm.cbc_schedule(n_days),
                   dcon, pm.pk_constants(), n_days, out, trace)
        trace_grades[i] = trace[:, K.TR_GRADE]
    occ = np.array([np.mean(trace_grades[:, burn_in:] == g) for g in range(4)])
    p_up = 1.0 - np.exp(-np.array(dcon[0:3]) * P.STEP_H)
    p_dn = 1.0 - np.exp(-np.array(dcon[3:6]) * P.STEP_H)
    pi = np.ones(4)
    for g in range(3):
        pi[g + 1] = pi[g] * p_up[g] / p_dn[g]
    pi /= pi.sum()
    se = np.sqrt(pi * (1 - pi) / (n * 4))   # rough: about 4 effectively independent samples per patient
    return {"simulated": occ.round(4).tolist(), "analytic": pi.round(4).tolist(),
            "max_abs_diff": float(np.max(np.abs(occ - pi))), "rough_se": se.round(4).tolist()}


def main():
    report = {"ode": check_odes(), "diarrhoea_chain": check_diarrhoea_chain()}
    os.makedirs("calibration", exist_ok=True)
    with open("calibration/verify_numerics.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
