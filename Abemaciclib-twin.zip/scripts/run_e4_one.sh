#!/bin/bash
# One E4 scenario run on P1: run_e4_one.sh SCENARIO KIND ALG SEED
# SCENARIO is a key of twin/scenarios.py, or "exposure" (base scenario, cumulative-exposure tolerance).
# Results: results_e4/<SCENARIO>/<STRUCT>/P1/<ALG>/seed<SEED>.{mat,npz}
set -u
SCEN=$1; KIND=$2; ALG=$3; SEED=$4
if [ "$SCEN" = exposure ]; then
  export TWIN_SCENARIO=base STRUCT=exposure
else
  export TWIN_SCENARIO=$SCEN STRUCT=time
fi
export RES=results_e4/$SCEN
exec "$(dirname "$0")/run_one.sh" P1 $KIND $ALG $SEED
