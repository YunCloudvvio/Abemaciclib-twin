#!/bin/bash
# One run of the main experiment: run_one.sh INSTANCE KIND ALG SEED   (KIND = moea | mosi)
# Environment: FES (default 10000), STRUCT (time), CAL (calibration), RES (results), PYTHON, OCTAVE_CLI.
# Skips finished runs.
set -u
INST=$1; KIND=$2; ALG=$3; SEED=$4
FES=${FES:-10000}; STRUCT=${STRUCT:-time}; CAL=${CAL:-calibration}; RES=${RES:-results}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd $ROOT
PY=${PYTHON:-python}
OCTAVE_CLI=${OCTAVE_CLI:-octave-cli}
export NUMBA_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
OUT=$RES/$STRUCT/$INST/$ALG; mkdir -p $OUT
if [ "$KIND" = mosi ]; then
  F=$OUT/seed$SEED.npz
  [ -s $F ] && exit 0
  $PY -m twin.si_runner --alg $ALG --instance $INST --seed $SEED --max-fes $FES --structure $STRUCT \
      --calibration $CAL --out $F.tmp.npz > $OUT/seed$SEED.log 2>&1 && mv $F.tmp.npz $F
else
  F=$OUT/seed$SEED.mat
  [ -s $F ] && exit 0
  # Algorithms without constraint handling of their own get Deb's rule through the objectives
  # (platemo/twin_constraints.m); their true objectives/constraints are recomputed afterwards.
  case $ALG in SPEA2|MOEADDE|LMPFE) DEB=1 ;; *) DEB=0 ;; esac
  D=$(mktemp -d ${FIFO_ROOT:-/dev/shm}/abema_${INST}_${ALG}_${SEED}_XXXX)
  trap 'kill ${SPID:-} 2>/dev/null; rm -rf $D' EXIT     # clean up on every exit path
  trap 'exit 143' TERM INT                               # a signal ends the task (and runs the EXIT trap)
  $PY -m twin.platemo_server --dir $D --instance $INST --ensemble $CAL/ensemble_$STRUCT.json \
      --stage3 $CAL/stage3_$STRUCT.json --seed $SEED > $OUT/seed$SEED.server.log 2>&1 &
  SPID=$!
  for i in $(seq 1 120); do [ -f $D/ready ] && break; sleep 1; done
  TWIN_DEB=$DEB TWIN_FIFO_DIR=$D timeout 7200 $OCTAVE_CLI --no-gui --quiet --eval \
    "addpath('platemo'); run_twin('$ALG','ABEMA_$INST',100,$FES,$SEED,'$F.tmp.mat')" > $OUT/seed$SEED.log 2>&1
  RC=$?
  sleep 1; kill $SPID 2>/dev/null; wait $SPID 2>/dev/null; rm -rf $D
  if [ $RC -ne 0 ] || [ ! -s $F.tmp.mat ]; then
    echo "run failed (octave exit $RC)" >> $OUT/seed$SEED.log
    exit 1
  fi
  if [ $DEB = 1 ]; then
    if $PY -m twin.true_values --inp $F.tmp.mat --out $F.tv.mat --instance $INST --seed $SEED \
          --structure $STRUCT --calibration $CAL >> $OUT/seed$SEED.log 2>&1; then
      mv $F.tv.mat $F && rm -f $F.tmp.mat
    else
      mv $F.tmp.mat $F.failed.mat                        # keep the Octave result for inspection
      rm -f $F.tv.mat
      exit 1
    fi
  else
    mv $F.tmp.mat $F
  fi
fi
