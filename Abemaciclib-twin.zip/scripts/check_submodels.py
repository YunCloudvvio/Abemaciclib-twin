"""Sub-model reproduction checks with the
calibrated toxicity parameters.

1. Chigutsa 2026 Figure 5: fixed doses without dose modification, MONARCH 2 population.
   Paper: 0 mg about 9.5, 50 mg about 13, 100 mg about 16.5, 150 mg 19.6, 200 mg about 22 months.
2. Chigutsa 2026 Figure S4: PFS by quartile of the steady-state peak concentration in the
   abemaciclib arm of MONARCH 2 (17.5 / 16.9 / 14.1 / 14.5 months, Q1 to Q4). The paper explains
   the falling trend by dose reductions in high-exposure patients (confounding); a twin that
   reproduces it shows that PK + rules + PFS interact as in the trial.
3. Chigutsa 2026 Figure S2: number of dose reductions in the abemaciclib arm of MONARCH 2.
4. Neutrophil time course at 200 mg (MONARCH 1): nadir 2-4 weeks after the start, then stable.

Run from the project root:
    python scripts/check_submodels.py --toxicity calibration/stage12_time.json
Writes calibration/check_submodels_<structure>.json.
"""
import argparse
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from twin import kernel as K  # noqa: E402
from twin import params as P  # noqa: E402
from twin import population as pm  # noqa: E402
from twin import trials as T  # noqa: E402
from calibrate_stage12 import STRUCTURE, apply_parameters, toxicity_constants  # noqa: E402

N_DAYS = T.N_DAYS_EFFICACY


def km(out, trial="monarch2", seed=0):
    obs, event = T.observed_pfs_days(out[:, K.O_PFS_DAYS], trial, N_DAYS, seed=seed)
    return T.km_median_months(obs, event)


def figure5(n):
    """Fixed dose, no toxicity and no dose modification."""
    res = {}
    for dose in (0, 50, 100, 150, 200):
        pop = pm.sample_patients(n, seed=11, control_arm=(dose == 0))
        noise = pm.sample_noise(n, N_DAYS, 12)
        dcon = pm.diarrhoea_constants()
        dcon[0:3] = 0.0
        dcon[11:14] = 0.0
        pop[:, pm.C_SLOPE] = 0.0
        theta = K.standard_policy()
        theta[K.T_START_LEVEL] = theta[K.T_TARGET_LEVEL] = dose / K.DOSE_PER_LEVEL
        out = T.run(pop, noise, pm.cbc_schedule(N_DAYS), dcon, n_days=N_DAYS, theta=theta)
        res[f"{dose} mg"] = {"median_raw": float(np.median(out[:, K.O_PFS_DAYS])) / P.DAYS_PER_MONTH,
                             "median_km_scans": km(out)}
    res["paper"] = {"0 mg": 9.5, "50 mg": 13.0, "100 mg": 16.5, "150 mg": 19.6, "200 mg": 22.0}
    return res


def cmax_ss(pop, dose_mg):
    """Steady-state peak concentration (mg/L) of the one-compartment model, 12-hourly dosing."""
    ka, ke, v = pop[:, pm.C_KA], pop[:, pm.C_KE], pop[:, pm.C_V]
    f = P.PK_F_INTERCEPT + P.PK_F_SLOPE * dose_mg
    tau = 12.0
    t = np.linspace(0.0, tau, 241)[None, :]
    c = (f * dose_mg / v)[:, None] * (ka / (ka - ke))[:, None] * (
        np.exp(-ke[:, None] * t) / (1 - np.exp(-ke[:, None] * tau))
        - np.exp(-ka[:, None] * t) / (1 - np.exp(-ka[:, None] * tau)))
    return c.max(axis=1)


def monarch2_arm(n, tox, structure, seed=21):
    pop = apply_parameters(T.monarch2_population(n, seed, tox["m2_force_median"]), tox)
    rng = np.random.default_rng(seed + 2)
    pop[:, pm.C_G2_STRICT] = rng.random(n) < tox["g2_rule_frac"]
    pop[:, pm.C_ANC3_STRICT] = rng.random(n) < tox["anc3_rule_frac"]
    noise = pm.sample_noise(n, N_DAYS, seed + 1)
    out = T.run(pop, noise, T.trial_cbc_schedule(N_DAYS), toxicity_constants(tox, structure), n_days=N_DAYS)
    return pop, out


def figure_s4(pop, out):
    start_dose = pop[:, pm.C_START_LEVEL] * K.DOSE_PER_LEVEL
    cmax = cmax_ss(pop, start_dose)
    q = np.quantile(cmax, [0.25, 0.5, 0.75])
    groups = np.digitize(cmax, q)
    res = {}
    obs, event = T.observed_pfs_days(out[:, K.O_PFS_DAYS], "monarch2", N_DAYS)
    for g in range(4):
        m = groups == g
        res[f"Q{g + 1}"] = {"median_pfs_months": T.km_median_months(obs[m], event[m]),
                            "cmax_ng_ml_range": [float(cmax[m].min() * 1000), float(cmax[m].max() * 1000)],
                            "reduced_pct": 100.0 * float(np.mean(out[m, K.O_N_RED] > 0)),
                            "median_rdi": float(np.median(out[m, K.O_RDI]))}
    res["paper"] = {"Q1": 17.5, "Q2": 16.9, "Q3": 14.1, "Q4": 14.5}
    return res


def neutrophil_course(tox):
    pop = np.zeros((1, pm.N_COLS))
    pop[0] = pm.sample_patients(1, 1)[0]
    pop[0, pm.C_KA] = P.PK_KA
    pop[0, pm.C_KE] = P.PK_CL / P.PK_V
    pop[0, pm.C_ANC_BASE] = P.ANC_BASE
    pop[0, pm.C_KTR] = 4.0 / P.ANC_MTT_H
    pop[0, pm.C_SLOPE] = tox["anc_slope"]
    n_days = 112
    theta = K.standard_policy()
    theta[K.T_START_LEVEL] = theta[K.T_TARGET_LEVEL] = 4
    dcon = pm.diarrhoea_constants()
    dcon[0:3] = 0.0
    dcon[11:14] = 0.0
    out = np.zeros((1, K.N_OUT))
    trace = np.zeros((n_days, K.N_TRACE))
    K.simulate(theta, pop, np.array([1e9]), np.full((1, n_days * 4), 0.9, dtype=np.float32),
               np.zeros(n_days + 1, dtype=np.bool_), dcon, pm.pk_constants(), n_days, out, trace)
    anc = trace[:, K.TR_ANC]
    drop = P.ANC_BASE - anc
    day95 = int(np.argmax(drop >= 0.95 * drop.max())) + 1
    return {"nadir_day": int(np.argmin(anc)) + 1, "day_95pct_of_drop": day95,
            "nadir_anc": float(anc.min()), "anc_day84": float(anc[83]),
            "baseline": P.ANC_BASE, "paper": "nadir 2-4 weeks after the start, then stable (MONARCH 1)"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--toxicity", required=True)
    ap.add_argument("--n", type=int, default=20000)
    args = ap.parse_args()
    with open(args.toxicity, encoding="utf-8") as f:
        stage12 = json.load(f)
    tox, structure_name = stage12["parameters"], stage12["structure"]
    structure = STRUCTURE[structure_name]

    pop, out = monarch2_arm(args.n, tox, structure)
    report = {
        "structure": structure_name,
        "figure5_fixed_dose": figure5(args.n),
        "figure_s4_cmax_quartiles": figure_s4(pop, out),
        "figure_s2_reductions": {"simulated": T.reduction_counts(out), "paper": [0.483, 0.306, 0.161, 0.050]},
        "neutrophils_200mg_typical": neutrophil_course(tox),
    }
    os.makedirs("calibration", exist_ok=True)
    with open(f"calibration/check_submodels_{structure_name}.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
