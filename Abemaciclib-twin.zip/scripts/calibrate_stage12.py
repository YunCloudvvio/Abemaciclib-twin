"""Stages 1 and 2 of the calibration: neutrophils, diarrhoea chain, dose-rule adherence.

Fits the toxicity parameters to MONARCH 1 and MONARCH 2 summary statistics with
CMA-ES (several restarts, IPOP population doubling). Every evaluated parameter
set is archived; the sets whose fitted targets all fall inside the published 95%
CIs form the candidate pool of the twin ensemble.
The best set is then checked on fresh virtual patients, including the MONARCH 3
setting that is not used for fitting.

Run from the project root:
    python scripts/calibrate_stage12.py --structure time      (main analysis)
    python scripts/calibrate_stage12.py --structure exposure  (alternative tolerance)
Writes calibration/stage12_<structure>.json and calibration/stage12_<structure>_archive.npz.
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from twin import cmaes  # noqa: E402
from twin import kernel as K  # noqa: E402
from twin import params as P  # noqa: E402
from twin import population as pm  # noqa: E402
from twin import trials as T  # noqa: E402

# name, start, lower, upper, transform ("log" or "logit")
PARAMETERS = [
    ("anc_slope", 0.20, 0.02, 2.0, "log"),          # per mg/L, typical value
    ("anc_slope_cv", 0.288, 0.05, 1.5, "log"),      # between-patient CV of the slope
    ("q01", 0.20, 0.01, 5.0, "log"),                # per day at C_REF, t = 0
    ("q12", 0.05, 0.002, 2.0, "log"),
    ("q23", 0.03, 0.001, 1.0, "log"),
    ("tolerance", None, None, None, "log"),         # kh per day or kc per mg.h/L, set per structure
    ("beta", 1.0, 0.1, 4.0, "log"),
    ("g2_rule_frac", 0.15, 0.01, 0.99, "logit"),
    ("anc3_rule_frac", 0.50, 0.01, 0.99, "logit"),
    ("m1_hazard_mult", 2.3, 0.5, 10.0, "log"),
    ("oth_red", 0.002, 1e-5, 0.05, "log"),          # per day at C_REF: reductions for other adverse reactions
    ("oth_disc", 0.0005, 1e-6, 0.02, "log"),        # per day at C_REF: discontinuation for other adverse reactions
    ("oth_k", 0.003, 1e-5, 0.1, "log"),             # per day: decline of the reduction rate with time
    ("m2_force_median", 34.0, 5.0, 150.0, "log"),   # days: median of the MONARCH 2 mandated 200 -> 150 mg time
]
TOLERANCE = {"time": (0.03, 0.001, 0.5), "exposure": (0.03 / 24.0 / 0.247, 1e-5, 0.5 / 24.0 / 0.247 * 3)}
STRUCTURE = {"time": K.TOL_TIME, "exposure": K.TOL_EXPOSURE}

FIT_KEYS = {
    "monarch1": ["anc3_lab", "diar_any", "diar_g2", "diar_g3", "diar_onset_days", "held_diar", "reduced_diar",
                 "held_anc", "reduced_anc", "median_pfs_smooth_months", "reduced_ae", "discontinued"],
    "monarch2": ["anc3_lab", "diar_any", "diar_g3", "diar_onset_days", "held_diar", "reduced_diar",
                 "held_anc", "reduced_anc", "reduced_ae", "discontinued", "on_200mg_days"],
}
RANGE_KEYS = {"monarch2": ["anc3_first_day", "anc3_duration_lab"]}   # label ranges, pooled trials


def transforms(structure):
    rows = []
    for name, x0, lo, hi, tr in PARAMETERS:
        if name == "tolerance":
            x0, lo, hi = TOLERANCE[structure]
        rows.append((name, x0, lo, hi, tr))
    return rows


def forward(v, tr):
    return math.log(v / (1.0 - v)) if tr == "logit" else math.log(v)


def backward(x, tr):
    return 1.0 / (1.0 + math.exp(-x)) if tr == "logit" else math.exp(x)


# MONARCH 1 neutropenia (200 mg, 26.9%) is lower than MONARCH 2 (150 mg, 32.5%) and its
# diarrhoea onset is later (7.0 vs 6.0 days): no exposure-driven model can match both trials.
# These two MONARCH 1 targets keep half weight in the loss and do not count for acceptance.
DOWNWEIGHTED = {("monarch1", "anc3_lab"), ("monarch1", "diar_onset_days")}


def scale(key, target, n_trial):
    """Residual scale: binomial standard error of the trial (at least 1.5 points), 1 day for
    onset times, 0.5 month for the median PFS."""
    if key == "on_200mg_days":
        return 3.0
    if key.endswith("_days"):
        return 1.0
    if key.endswith("_months"):
        return 0.5
    return max(1.5, math.sqrt(target * (100.0 - target) / n_trial))


def within_ci(key, sim, target, n_trial):
    """Acceptance for the ensemble: inside the binomial 95% CI for proportions,
    within 20% for times (no CI is published for them)."""
    if key.endswith("_days") or key.endswith("_months"):
        return abs(sim - target) <= 0.2 * target
    half = 1.96 * math.sqrt(target * (100.0 - target) / n_trial)
    return abs(sim - target) <= half


class Setting:
    """One trial with fixed virtual patients and random numbers (common random numbers)."""

    def __init__(self, name, n, seed):
        self.name = name
        self.seed = seed
        self.n = n
        self.noise = pm.sample_noise(n, T.N_DAYS, seed + 1)
        rng = np.random.default_rng(seed + 2)
        self.u_g2 = rng.random(n)
        self.u_anc3 = rng.random(n)
        self.cbc = T.trial_cbc_schedule(T.N_DAYS, day15=(name != "monarch3"))
        self.base = T.monarch3_population_approx(n, seed) if name == "monarch3" else None

    def population(self, par):
        if self.name == "monarch1":
            pop = T.monarch1_population(self.n, self.seed, par["m1_hazard_mult"])
        elif self.name == "monarch2":
            pop = T.monarch2_population(self.n, self.seed, par["m2_force_median"])
        else:
            pop = self.base
        pop = apply_parameters(pop, par)
        pop[:, pm.C_G2_STRICT] = self.u_g2 < par["g2_rule_frac"]
        pop[:, pm.C_ANC3_STRICT] = self.u_anc3 < par["anc3_rule_frac"]
        return pop

    def simulate(self, par, structure):
        self.last_pop = self.population(par)
        return T.run(self.last_pop, self.noise, self.cbc, toxicity_constants(par, structure))

    def summary(self, par, structure):
        out = self.simulate(par, structure)
        sim = T.summarize(out, self.name)
        if self.name == "monarch2":
            sim["on_200mg_days"] = T.days_on_200mg(out, self.last_pop)
        return sim, out


def toxicity_constants(par, structure):
    return T.diarrhoea_constants(par["q01"], par["q12"], par["q23"], par["tolerance"], par["beta"], structure,
                                 other=(par["oth_red"], par["oth_disc"], par["oth_k"]))


def apply_parameters(pop, par):
    """Typical slope and its between-patient CV; the patient's standard normal draw is kept."""
    pop = pop.copy()
    omega_old = math.sqrt(math.log(1.0 + P.ANC_CV_SLOPE ** 2))
    omega_new = math.sqrt(math.log(1.0 + par["anc_slope_cv"] ** 2))
    eta = np.log(pop[:, pm.C_SLOPE] / P.ANC_SLOPE) / omega_old
    pop[:, pm.C_SLOPE] = par["anc_slope"] * np.exp(omega_new * eta)
    return pop


def residuals(summaries):
    """Standardised residuals of every fitted target, plus the acceptance flag."""
    res, accepted = [], True
    for name, sim in summaries.items():
        target = T.TARGETS[name]
        for key in FIT_KEYS[name]:
            r = (sim[key] - target[key]) / scale(key, target[key], target["n"])
            if (name, key) in DOWNWEIGHTED:
                res.append(r * math.sqrt(0.5))
            else:
                res.append(r)
                accepted &= within_ci(key, sim[key], target[key], target["n"])
        for key in RANGE_KEYS.get(name, []):
            lo, hi = T.LABEL_RANGES[key]
            v = sim[key]
            gap = 0.0 if lo <= v <= hi else min(abs(v - lo), abs(v - hi))
            res.append(gap if not math.isnan(v) else 10.0)
            accepted &= gap <= 0.2 * (lo + hi) / 2.0
    return np.array(res), bool(accepted)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--structure", choices=["time", "exposure"], default="time")
    ap.add_argument("--n-fit", type=int, default=3000)
    ap.add_argument("--n-check", type=int, default=20000)
    ap.add_argument("--restarts", type=int, default=4)
    ap.add_argument("--evals", type=int, default=1500, help="evaluations per restart (first one)")
    ap.add_argument("--seed", type=int, default=7001)
    args = ap.parse_args()
    structure = STRUCTURE[args.structure]
    rows = transforms(args.structure)
    names = [r[0] for r in rows]

    fit = [Setting("monarch1", args.n_fit, 101), Setting("monarch2", args.n_fit, 202)]
    archive_x, archive_f, archive_ok, archive_res = [], [], [], []

    def to_par(x):
        return {n: backward(v, r[4]) for n, v, r in zip(names, x, rows)}

    def loss(x):
        par = to_par(x)
        summaries = {s.name: s.summary(par, structure)[0] for s in fit}
        res, ok = residuals(summaries)
        f = float(np.sum(res ** 2))
        archive_x.append(np.array([par[n] for n in names]))
        archive_f.append(f)
        archive_ok.append(ok)
        archive_res.append(res)
        return f

    lower = np.array([forward(r[2], r[4]) for r in rows])
    upper = np.array([forward(r[3], r[4]) for r in rows])
    x0 = np.array([forward(r[1], r[4]) for r in rows])
    t0 = time.perf_counter()
    rng = np.random.default_rng(args.seed)
    best = None
    popsize = None
    for restart in range(args.restarts):
        start = x0 if restart == 0 else lower + rng.random(len(rows)) * (upper - lower)

        def log(es, evals, restart=restart):
            if es.gen % 10 == 0:
                print(f"  restart {restart} gen {es.gen:4d} evals {evals:5d} best {es.best_f:9.3f} "
                      f"sigma {es.sigma:.3g}  ({time.perf_counter() - t0:.0f} s)", flush=True)

        es = cmaes.minimize(loss, start, 0.5, lower, upper, args.evals * (2 ** restart),
                            popsize=popsize, seed=args.seed + restart, log=log)
        print(f"restart {restart}: best {es.best_f:.3f} after {es.evals} evaluations, "
              f"stop {es.stop_reason}, lambda {es.lam}", flush=True)
        if best is None or es.best_f < best.best_f:
            best = es
        popsize = es.lam * 2
    par = to_par(best.best_x)

    os.makedirs("calibration", exist_ok=True)
    tag = f"calibration/stage12_{args.structure}"
    np.savez_compressed(f"{tag}_archive.npz", names=np.array(names), x=np.array(archive_x),
                        loss=np.array(archive_f), accepted=np.array(archive_ok), residuals=np.array(archive_res))

    check = [Setting("monarch1", args.n_check, 303), Setting("monarch2", args.n_check, 404),
             Setting("monarch3", args.n_check, 505)]
    report = {"structure": args.structure, "parameters": par, "fit_loss": best.best_f,
              "n_fit": args.n_fit, "n_check": args.n_check, "n_evaluations": len(archive_f),
              "n_accepted": int(np.sum(archive_ok)), "trials": {}}
    for s in check:
        sim, out = s.summary(par, structure)
        target = T.TARGETS[s.name]
        used = FIT_KEYS.get(s.name, []) if s.name != "monarch3" else []
        rows_out = {k: {"simulated": round(v, 2), "target": target.get(k, T.LABEL_RANGES.get(k)),
                        "used_for_fit": k in used or k in RANGE_KEYS.get(s.name, [])} for k, v in sim.items()}
        if s.name == "monarch2":
            rows_out["reductions_0_1_2_3plus"] = {"simulated": [round(v, 3) for v in T.reduction_counts(out)],
                                                  "target": [0.483, 0.306, 0.161, 0.050], "used_for_fit": False}
        report["trials"][s.name] = rows_out
    # TRADE: escalation from 50 mg in early breast cancer, held out (tolerability only).
    n_trade = args.n_check
    pop = pm.sample_patients(n_trade, 606)
    pop = apply_parameters(pop, par)
    rng = np.random.default_rng(608)
    pop[:, pm.C_G2_STRICT] = rng.random(n_trade) < par["g2_rule_frac"]
    pop[:, pm.C_ANC3_STRICT] = rng.random(n_trade) < par["anc3_rule_frac"]
    _, u_trade = pm.sample_noise(n_trade, T.TRADE_DAYS, 607)
    dcon = toxicity_constants(par, structure)
    trade = T.run_trade(pop, u_trade, dcon)
    report["trials"]["trade"] = {k: {"simulated": round(v, 2), "target": T.TRADE_TARGETS.get(k), "used_for_fit": False}
                                 for k, v in trade.items()}
    # monarchE: early breast cancer at full dose, held out.
    pop = apply_parameters(T.monarche_population(args.n_check, 707), par)
    rng = np.random.default_rng(709)
    pop[:, pm.C_G2_STRICT] = rng.random(args.n_check) < par["g2_rule_frac"]
    pop[:, pm.C_ANC3_STRICT] = rng.random(args.n_check) < par["anc3_rule_frac"]
    _, u_e = pm.sample_noise(args.n_check, T.N_DAYS, 708)
    sim = T.summarize(T.run_monarche(pop, u_e, dcon))
    report["trials"]["monarche"] = {k: {"simulated": round(v, 2), "target": T.TARGETS["monarche"].get(k),
                                        "used_for_fit": False} for k, v in sim.items()
                                    if k not in ("median_pfs_months", "median_pfs_smooth_months")}
    with open(f"{tag}.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print(f"\nstructure {args.structure}; {len(archive_f)} evaluations, {int(np.sum(archive_ok))} accepted; "
          f"{time.perf_counter() - t0:.0f} s")
    for k, v in par.items():
        print(f"  {k:16s} {v:.4g}")
    for name, rows_out in report["trials"].items():
        print(f"\n{name} (fresh patients, n = {args.n_check})")
        for k, r in rows_out.items():
            tag2 = "fit " if r["used_for_fit"] else ("HELD" if r["target"] is not None else "    ")
            print(f"  {tag2} {k:22s} simulated {r['simulated']!s:>24}   target {r['target']!s}")


if __name__ == "__main__":
    main()
