function [F, C] = twin_constraints(F, C)
%TWIN_CONSTRAINTS  Constraint handling seen by the algorithm.
%   Default: objectives and constraints unchanged (algorithms with their own constraint handling).
%   With the environment variable TWIN_DEB=1 (algorithms without constraint handling: SPEA2,
%   MOEA/D-DE, LMPFE): Deb's constraint-domination rule expressed through Pareto dominance, the same
%   transform as twin/si_runner.py for the swarm algorithms: feasible solutions keep F, infeasible ones
%   get U + CV in every objective (U = [0 1 182], upper bounds of f1, f2, f3; CV = sum of positive
%   constraint values), and the algorithm sees no constraints. The true objectives and constraints are
%   recomputed from the decision vectors after the run (twin/true_values.py).
    if strcmp(getenv('TWIN_DEB'), '1')
        cv = sum(max(C, 0), 2);
        bad = find(cv > 0);
        U = [0 1 182];
        nb = numel(bad);
        if nb > 0                               % (an empty logical index of a 1 x 1 cv gives 0 x 0 in Octave)
            F(bad, :) = repmat(U, nb, 1) + repmat(reshape(cv(bad), nb, 1), 1, size(F, 2));
        end
        C = zeros(size(C));
    end
end
