function [nn, xx] = hist(varargin)
%HIST  Octave shim for PlatEMO: MATLAB's hist returns zero counts for an empty data vector
%   (PlatEMO calls hist(Loc, 1:max(Loc)) on empty sets, e.g. in NDSort when no solution is
%   infeasible); Octave's hist raises an error instead. Any other call goes to Octave's own
%   hist (copied unchanged as octave_hist_orig.m, only the function name differs).
    if nargin >= 1 && isempty(varargin{1})
        if nargin >= 2 && isnumeric(varargin{2}) && numel(varargin{2}) ~= 1
            xx = reshape(varargin{2}, 1, []);     % bin centres given
            nn = zeros(size(xx));
        else
            m = 10;                               % MATLAB default number of bins
            if nargin >= 2 && isnumeric(varargin{2}), m = varargin{2}; end
            nn = zeros(1, m);                     % MATLAB: m empty bins (centres are not defined here)
            xx = zeros(1, m);
        end
        return;
    end
    if nargout == 0
        octave_hist_orig(varargin{:});
    else
        [nn, xx] = octave_hist_orig(varargin{:});
    end
end
