function y = round(x, n, type)
%ROUND  Octave shim for PlatEMO: MATLAB's round(X, N) rounds to N decimal digits (N < 0: to the left
%   of the decimal point); Octave's builtin round takes one argument. round(X) goes to the builtin.
%   Used by AGE-MOEA-II (round(objs, 12)). The 'significant' form is not needed and is refused.
    if nargin == 1
        y = builtin('round', x);
        return;
    end
    if nargin == 3 && ~strcmpi(type, 'decimals')
        error('round shim: only the ''decimals'' form is supported');
    end
    if n >= 0
        p = 10 ^ n;
        y = builtin('round', x .* p) ./ p;
    else
        p = 10 ^ (-n);
        y = builtin('round', x ./ p) .* p;
    end
end
