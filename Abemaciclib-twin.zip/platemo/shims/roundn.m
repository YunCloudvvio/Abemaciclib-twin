function y = roundn(x, n)
%ROUNDN  Octave shim for PlatEMO (MATLAB Mapping Toolbox function): round to the nearest multiple of
%   10^N, as MATLAB's roundn. Used by DominationCal (CMOEA-CD helper, called by CMOCEA-DDAP):
%   roundn(PopObj, -10).
    if n < 0
        p = 10 ^ (-n);
        y = round(x .* p) ./ p;
    else
        p = 10 ^ n;
        y = round(x ./ p) .* p;
    end
end
