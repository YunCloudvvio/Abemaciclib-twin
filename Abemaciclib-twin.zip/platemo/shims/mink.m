function [B, I] = mink(A, k, dim)
%MINK  Octave shim for PlatEMO (MATLAB R2017b function missing in Octave 10): the k smallest elements
%   of A along dimension dim (default: first non-singleton), in ascending order, with their indices.
%   Ties keep their original order (stable sort); NaN are placed last, as in MATLAB.
%   Used by AGE-MOEA-II (SurvivalScore: mink(distances, neighbors, 2)).
    if nargin < 3
        dim = find(size(A) ~= 1, 1);
        if isempty(dim), dim = 1; end
    end
    [S, J] = sort(A, dim, 'ascend');
    k = min(k, size(A, dim));
    idx = repmat({':'}, 1, ndims(A));
    idx{dim} = 1:k;
    B = S(idx{:});
    I = J(idx{:});
end
