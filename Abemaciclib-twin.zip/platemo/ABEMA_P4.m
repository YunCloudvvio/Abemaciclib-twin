classdef ABEMA_P4 < PROBLEM
% ABEMA_P4  Abemaciclib dosing policy, problem P4 (see twin/problems.py).
%   Three objectives (-CVaR_0.2 of PFS, P(grade >= 3 neutropenia), grade >= 2 diarrhoea days), three
%   constraints (<= 0 feasible), 8 decision variables (1 real, 7 integer). The objectives are
%   computed by the Python twin (twin/platemo_server.py) over named pipes; see twin/problems.py.
    methods
        function Setting(obj)
            obj.M        = 3;
            obj.D        = 8;
            obj.lower    = [1 2  7 1.0  0 0 28 0];
            obj.upper    = [3 3 28 2.0 14 3 84 2];
            obj.encoding = [2 2  2 1    2 2  2 2];
        end
        function Population = Evaluation(obj, varargin)
            PopDec     = obj.CalDec(varargin{1});
            R          = twin_call(PopDec, 6);
            [F, C]     = twin_constraints(R(:,1:3), R(:,4:6));
            Population = SOLUTION(PopDec, F, C, varargin{2:end});
            obj.FE     = obj.FE + size(PopDec,1);
        end
    end
end
