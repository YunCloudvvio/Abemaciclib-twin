classdef ABEMA_P3 < PROBLEM
% ABEMA_P3  Abemaciclib dosing policy, problem P3 (first line, aromatase inhibitor partner, fixed weekly schedule).
%   Three objectives (-RMST, P(grade >= 3 neutropenia), grade >= 2 diarrhoea days), three
%   constraints (<= 0 feasible), 24 integer decision variables (dose level of weeks 1-24, 0 = holiday). The objectives are
%   computed by the Python twin (twin/platemo_server.py) over named pipes; see twin/problems.py.
    methods
        function Setting(obj)
            obj.M        = 3;
            obj.D        = 24;
            obj.lower    = zeros(1, 24);
            obj.upper    = 3 * ones(1, 24);
            obj.encoding = 2 * ones(1, 24);
        end
        function Population = Evaluation(obj, varargin)
            PopDec     = obj.CalDec(varargin{1});
            R          = twin_call(PopDec, 6);
            [F, C]     = twin_constraints(R(:,1:3), R(:,4:6));
            Population = SOLUTION(PopDec, F, C, varargin{2:end});
            obj.FE     = obj.FE + size(PopDec,1);
        end
    end
end
