function run_twin(alg, prob, N, maxFE, seed, outfile, nckpt)
%RUN_TWIN  One seeded, headless PlatEMO run on a twin problem (Octave).
%   Saves the final population (Dec, Obj, Con) and NCKPT checkpoints (default 20): PlatEMO's 'save'
%   option splits the budget into NCKPT equal parts and keeps the population at the end of each part.
%   Checkpoint i: ckpt_FE(i) evaluations, ckpt_Dec{i}, ckpt_Obj{i}, ckpt_Con{i}.
%   Seeding and settings through plat_seed and OctSet (platemo/octave), with 'save' = NCKPT.
    if nargin < 7, nckpt = 20; end
    here = fileparts(mfilename('fullpath'));
    addpath(fullfile(here, 'octave'));         % plat_setup/plat_seed and the Octave patches
    addpath(here);
    addpath(fullfile(here, 'shims'));        % Octave compatibility shims, see shims/hist.m
    plat_setup();
    Problem = feval(prob);
    Problem.OctSet('N', N, 'maxFE', maxFE);
    Algorithm = feval(alg);
    Algorithm.OctSet('save', nckpt, 'outputFcn', @plat_nooutput);
    plat_seed(seed);
    t0 = tic;
    Algorithm.Solve(Problem);
    runtime = toc(t0);
    R = Algorithm.result;
    n = size(R, 1);
    ckpt_FE = zeros(1, n);
    ckpt_Dec = cell(1, n); ckpt_Obj = cell(1, n); ckpt_Con = cell(1, n);
    for i = 1:n
        ckpt_FE(i) = R{i, 1};
        P = R{i, 2};
        ckpt_Dec{i} = P.decs; ckpt_Obj{i} = P.objs; ckpt_Con{i} = P.cons;
    end
    P = R{end, 2};
    Dec = P.decs; Obj = P.objs; Con = P.cons;
    info = struct('FE', Problem.FE, 'runtime', runtime, 'M', Problem.M, 'D', Problem.D, 'N', numel(P), ...
                  'nckpt', nckpt);
    if ~isempty(outfile)
        save('-v7', outfile, 'Dec', 'Obj', 'Con', 'info', 'ckpt_FE', 'ckpt_Dec', 'ckpt_Obj', 'ckpt_Con');
    end
    twin_call([], 0);
    printf('%s %s seed %d: FE %d, runtime %.1f s, final N %d, feasible %d, checkpoints %d\n', alg, prob, seed, ...
           Problem.FE, runtime, numel(P), sum(all(Con <= 0, 2)), n);
end
