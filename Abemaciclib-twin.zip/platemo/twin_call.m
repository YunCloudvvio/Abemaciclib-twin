function R = twin_call(PopDec, ncol)
%TWIN_CALL  Send a decision matrix to the Python twin server and read [objectives, constraints].
%   twin_call([], 0) closes the connection (the server exits).
    persistent fq fr
    if isempty(fq)
        d  = getenv('TWIN_FIFO_DIR');
        fq = fopen(fullfile(d, 'req'), 'w');    % blocks until the server opens its end
        fr = fopen(fullfile(d, 'resp'), 'r');
        if fq < 0 || fr < 0
            error('twin_call: cannot open the pipes in %s', d);
        end
    end
    if ncol == 0
        fwrite(fq, [0 0], 'double'); fflush(fq);
        fclose(fq); fclose(fr); fq = []; fr = [];
        R = [];
        return;
    end
    [n, D] = size(PopDec);
    if n == 0                                   % n = 0 on the pipe means "close": never send it here
        R = zeros(0, ncol);
        return;
    end
    fwrite(fq, [n D], 'double');
    fwrite(fq, PopDec.', 'double');             % row-major
    fflush(fq);
    R = fread(fr, [ncol, n], 'double').';
    if size(R, 1) ~= n
        error('twin_call: short response (%d of %d rows)', size(R, 1), n);
    end
end
