function drawnow(varargin)
% OCTAVE SHIM: headless no-op (PlatEMO calls drawnow(limitrate), unsupported in Octave)
end
