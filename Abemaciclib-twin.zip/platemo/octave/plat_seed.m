function plat_seed(seed)
%PLAT_SEED  Seed Octave's rand/randn/randi (Mersenne twister).
    rand('twister',seed);
    randn('twister',seed);
    rande('twister',seed); randg('twister',seed); randp('twister',seed);
end
