function plat_nooutput(Algorithm,Problem)
% no-op outputFcn for headless runs
end
