function obj = subsasgn(obj,s,val)
    if ~isa(obj,'SOLUTION')
        if ~isempty(obj), error('SOLUTION:subsasgn','cannot assign SOLUTION into %s',class(obj)); end
        obj = SOLUTION();
    end
    switch s(1).type
        case '()'
            k = sol_index(obj,s(1).subs);
            N = size(obj.dec,1);
            if numel(s) == 1 && ~isa(val,'SOLUTION')
                if isempty(val)              % P(k) = []
                    keep = true(1,N); keep(k) = false;
                    obj = sol_select(obj,find(keep));
                    return;
                end
                error('SOLUTION:subsasgn','can only assign SOLUTION objects');
            end
            if numel(s) > 1
                sub = subsasgn(sol_select(obj,k),s(2:end),val);
                val = sub;
            end
            if isempty(k), return; end
            nv = size(val.dec,1);
            if nv == 0                       % P(1:n) = SOLUTION(): placeholder rows
                val = sol_placeholder(numel(k));
                nv  = numel(k);
            end
            if nv == 1 && numel(k) > 1
                val = sol_select(val,ones(1,numel(k)));
            elseif nv ~= numel(k)
                error('SOLUTION:subsasgn','size mismatch (%d vs %d)',numel(k),nv);
            end
            if isempty(k), return; end
            if max(k) > N                    % grow with placeholder rows
                obj = [obj, sol_placeholder(max(k)-N)];
            end
            D = max(size(obj.dec,2),size(val.dec,2)); M = max(size(obj.obj,2),size(val.obj,2));
            C = max(size(obj.con,2),size(val.con,2)); A = max(size(obj.add,2),size(val.add,2));
            obj = sol_widen(obj,D,M,C,A); val = sol_widen(val,D,M,C,A);
            obj.dec(k,:) = val.dec; obj.obj(k,:) = val.obj; obj.con(k,:) = val.con;
            obj.add(k,:) = val.add; obj.hasadd(k) = val.hasadd;
        case '.'
            if numel(s) > 1
                cur = subsref(obj,s(1));
                val = subsasgn(cur,s(2:end),val);
            end
            f = s(1).subs;
            if ~any(strcmp(f,{'dec','obj','con','add'}))
                error('SOLUTION:subsasgn','cannot set %s',f);
            end
            N = size(obj.dec,1);
            if N ~= 1 && size(val,1) == 1 && N > 1
                val = repmat(val,N,1);
            end
            val = reshape(double(val),N,[]);
            obj.(f) = val;
            if strcmp(f,'add'), obj.hasadd(:) = true; end
        otherwise
            error('SOLUTION:subsasgn','{} assignment not supported');
    end
end

function P = sol_placeholder(n)
    s = struct('dec',zeros(n,0),'obj',zeros(n,0),'con',zeros(n,0),'add',zeros(n,0),'hasadd',false(n,1));
    P = class(s,'SOLUTION');
end
