function P = best(obj)
    Feasible = find(all(obj.con<=0,2));
    if isempty(Feasible)
        Best = [];
    elseif size(obj.obj,2) > 1
        Best = NDSort(obj.obj(Feasible,:),1) == 1;
    else
        [~,Best] = min(obj.obj(Feasible,:));
    end
    P = sol_select(obj,reshape(Feasible(Best),1,[]));
end
