function disp(obj)
    fprintf('SOLUTION array 1x%d\n',size(obj.dec,1));
end
