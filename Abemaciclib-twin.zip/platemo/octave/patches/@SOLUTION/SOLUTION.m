function obj = SOLUTION(PopDec,PopObj,PopCon,PopAdd)
% OCTAVE PATCH P3: old-style value class replacing the handle classdef SOLUTION (Octave cannot
% build classdef object arrays). One object = a whole population stored as row-aligned matrices:
% dec N x D, obj N x M, con N x C, add N x A (NaN where a solution has no add), hasadd N x 1.
% Supported: P(idx) (numeric/logical/end/:), P(idx)=Q, P(idx)=[], P(i).add=v, [P,Q], [P;Q],
% P.decs/objs/cons/adds(Default)/best, P(i).dec/obj/con/add, length/numel/size/isempty/end.
% Difference to PlatEMO: value semantics (P.adds(Add) does not write the defaults back).
    if nargin == 0
        s = struct('dec',zeros(0,0),'obj',zeros(0,0),'con',zeros(0,0),'add',zeros(0,0),'hasadd',false(0,1));
        obj = class(s,'SOLUTION');
        return;
    end
    if isa(PopDec,'SOLUTION')
        obj = PopDec; return;
    end
    N = size(PopDec,1);
    s.dec = double(PopDec);
    s.obj = reshape(double(PopObj),N,[]);
    s.con = reshape(double(PopCon),N,[]);
    if nargin > 3
        s.add = reshape(double(PopAdd(1:N,:)),N,[]);
        s.hasadd = true(N,1);
    else
        s.add = zeros(N,0);
        s.hasadd = false(N,1);
    end
    obj = class(s,'SOLUTION');
end
