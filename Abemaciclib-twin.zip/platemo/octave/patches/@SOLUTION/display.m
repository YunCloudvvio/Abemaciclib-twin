function display(obj)
    fprintf('%s = SOLUTION array 1x%d (D=%d, M=%d, C=%d)\n',inputname(1),size(obj.dec,1),size(obj.dec,2),size(obj.obj,2),size(obj.con,2));
end
