function varargout = size(obj,d)
    sz = [1, size(obj.dec,1)];
    if nargin > 1
        varargout = {sz(d)};
        if d > 2, varargout = {1}; end
    elseif nargout <= 1
        varargout = {sz};
    else
        varargout = num2cell([sz, ones(1,nargout-2)]);
    end
end
