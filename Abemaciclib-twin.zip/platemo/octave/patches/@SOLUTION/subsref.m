function varargout = subsref(obj,s)
    switch s(1).type
        case '()'
            r = sol_select(obj,sol_index(obj,s(1).subs));
            s = s(2:end);
        case '.'
            switch s(1).subs
                case 'decs', r = obj.dec;
                case 'objs', r = obj.obj;
                case 'cons', r = obj.con;
                case 'adds'
                    if numel(s) > 1 && strcmp(s(2).type,'()')
                        Add = s(2).subs{1};
                        miss = ~obj.hasadd;
                        if any(miss)
                            if isempty(obj.add) || size(Add,2) > size(obj.add,2)
                                obj.add = [obj.add, nan(size(obj.add,1),size(Add,2)-size(obj.add,2))];
                            end
                            obj.add(miss,:) = Add(miss,:);
                        end
                        s = s(2:end);
                    end
                    r = obj.add;
                case 'best', r = best(obj);
                case {'dec','obj','con','add'}
                    r = obj.(s(1).subs);
                    if size(r,1) > 1 && nargout > 1
                        varargout = num2cell(r,2);
                        return;
                    elseif size(r,1) > 1
                        r = reshape(r',1,[]);   % [P.obj] == horizontal concatenation of the rows
                    end
                otherwise
                    error('SOLUTION:subsref','unknown property or method %s',s(1).subs);
            end
            s = s(2:end);
        otherwise
            error('SOLUTION:subsref','{} indexing not supported');
    end
    if ~isempty(s)
        r = subsref(r,s);
    end
    varargout = {r};
end
