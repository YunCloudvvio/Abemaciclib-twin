function obj = horzcat(varargin)
    keep = {};
    for i = 1:nargin
        v = varargin{i};
        if isa(v,'SOLUTION')
            if size(v.dec,1) > 0, keep{end+1} = v; end
        elseif ~isempty(v)
            error('SOLUTION:cat','cannot concatenate SOLUTION with %s',class(v));
        end
    end
    if isempty(keep), obj = SOLUTION(); return; end
    D = max(cellfun(@(p)size(p.dec,2),keep)); M = max(cellfun(@(p)size(p.obj,2),keep));
    C = max(cellfun(@(p)size(p.con,2),keep)); A = max(cellfun(@(p)size(p.add,2),keep));
    for i = 1:numel(keep), keep{i} = sol_widen(keep{i},D,M,C,A); end
    obj = keep{1};
    obj.dec = cell2mat(cellfun(@(p)p.dec,keep,'UniformOutput',false)');
    obj.obj = cell2mat(cellfun(@(p)p.obj,keep,'UniformOutput',false)');
    obj.con = cell2mat(cellfun(@(p)p.con,keep,'UniformOutput',false)');
    obj.add = cell2mat(cellfun(@(p)p.add,keep,'UniformOutput',false)');
    obj.hasadd = cell2mat(cellfun(@(p)p.hasadd,keep,'UniformOutput',false)');
end
