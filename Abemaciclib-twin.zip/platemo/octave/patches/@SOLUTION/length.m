function n = length(obj)
    n = size(obj.dec,1);
end
