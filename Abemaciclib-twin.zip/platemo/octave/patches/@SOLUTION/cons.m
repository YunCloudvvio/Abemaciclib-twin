function v = cons(obj)
    v = obj.con;
end
