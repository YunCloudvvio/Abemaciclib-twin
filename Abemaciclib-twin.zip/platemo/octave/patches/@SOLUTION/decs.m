function v = decs(obj)
    v = obj.dec;
end
