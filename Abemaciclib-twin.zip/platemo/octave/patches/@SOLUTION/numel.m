function n = numel(obj,varargin)
    if nargin > 1
        n = 1;
    else
        n = size(obj.dec,1);
    end
end
