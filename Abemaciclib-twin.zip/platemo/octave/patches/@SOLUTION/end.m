function e = end(obj,k,n)
    if n == 1 || k == 2
        e = size(obj.dec,1);
    else
        e = 1;
    end
end
