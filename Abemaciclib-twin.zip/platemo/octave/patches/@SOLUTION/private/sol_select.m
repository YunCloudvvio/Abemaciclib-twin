function r = sol_select(obj,k)
    N = size(obj.dec,1);
    if any(k > N) || any(k < 1) || any(k ~= round(k))
        error('SOLUTION:index','index (%d) out of bound %d',max(k),N);
    end
    r = obj;
    r.dec = obj.dec(k,:); r.obj = obj.obj(k,:); r.con = obj.con(k,:);
    r.add = obj.add(k,:); r.hasadd = obj.hasadd(k);
end
