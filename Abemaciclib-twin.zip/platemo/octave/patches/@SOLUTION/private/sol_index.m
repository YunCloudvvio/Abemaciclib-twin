function k = sol_index(obj,subs)
% convert '()' subscripts of a 1 x N object array to row indices
    N = size(obj.dec,1);
    if numel(subs) == 1
        k = subs{1};
    elseif numel(subs) == 2
        k = subs{2};
        if ~(ischar(subs{1}) || isequal(subs{1},1))
            error('SOLUTION:index','SOLUTION arrays are 1 x N');
        end
    else
        error('SOLUTION:index','too many subscripts');
    end
    if ischar(k) && strcmp(k,':')
        k = 1:N;
    elseif islogical(k)
        if numel(k) > N && any(k(N+1:end)), error('SOLUTION:index','index out of bound'); end
        k = find(k(1:min(end,N)));
    end
    k = reshape(double(k),1,[]);
end
