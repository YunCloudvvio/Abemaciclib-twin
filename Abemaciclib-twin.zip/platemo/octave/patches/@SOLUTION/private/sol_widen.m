function obj = sol_widen(obj,D,M,C,A)
% pad columns with NaN up to the given widths (used for placeholder rows / mixed adds)
    N = size(obj.dec,1);
    if size(obj.dec,2) < D, obj.dec = [obj.dec, nan(N,D-size(obj.dec,2))]; end
    if size(obj.obj,2) < M, obj.obj = [obj.obj, nan(N,M-size(obj.obj,2))]; end
    if size(obj.con,2) < C, obj.con = [obj.con, nan(N,C-size(obj.con,2))]; end
    if size(obj.add,2) < A, obj.add = [obj.add, nan(N,A-size(obj.add,2))]; end
end
