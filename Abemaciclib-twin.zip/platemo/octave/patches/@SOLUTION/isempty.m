function t = isempty(obj)
    t = size(obj.dec,1) == 0;
end
