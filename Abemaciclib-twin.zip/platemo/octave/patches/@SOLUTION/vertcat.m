function obj = vertcat(varargin)
    obj = horzcat(varargin{:});
end
