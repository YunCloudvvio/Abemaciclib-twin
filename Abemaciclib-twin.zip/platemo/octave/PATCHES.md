# PlatEMO under Octave 10.3 — patches

`platemo/PlatEMO_oct/` is made by `apply_patches.sh` from PlatEMO v4.16 (BIMK/PlatEMO, commit d25e65d).
The original clone is not modified. Every change is listed here; grep `OCTAVE PATCH` in the copy to find
them. Files use CRLF line endings (the patches keep them). PlatEMO itself is not redistributed here.

| ID | File | Change | Why |
|----|------|--------|-----|
| P1 | `Problems/PROBLEM.m`, `Algorithms/ALGORITHM.m` | `classdef X < handle & matlab.mixin.Heterogeneous` → `classdef X < handle` | Octave has no `matlab.mixin.Heterogeneous` |
| P2 | same | first `methods(Access = protected)` (the constructor) → `methods` | Octave refuses to run a protected superclass constructor from an implicit subclass constructor |
| P3 | `Problems/SOLUTION.m` → `Problems/@SOLUTION/` | classdef handle class replaced by an old-style **value** class that stores a whole population as row-aligned matrices (dec, obj, con, add, hasadd). Overloads: `subsref` (`P(idx)`, `P.decs/objs/cons/adds(Default)/best`, `P(i).dec/obj/con/add`, `[P.obj]` = concatenated rows), `subsasgn` (`P(idx)=Q`, `P(idx)=[]`, `P(1:n)=SOLUTION()` placeholders, growth, `P(i).add=v`), `horzcat/vertcat`, `numel/length/size/end/isempty`, `best`. The original is PlatEMO's `Problems/SOLUTION.m` | Octave cannot build classdef object arrays (`obj(1,N) = SOLUTION` → "mark_as_constructed: invalid object") |
| P4 | `Algorithms/ALGORITHM.m` (NotTerminated) | `drawnow('limitrate')` removed; plus shim `platemo/octave/shims/drawnow.m` (no-op) for all other callers | Octave's `drawnow` only accepts `'expose'` |
| P5 | `Problems/PROBLEM.m`, `Algorithms/ALGORITHM.m` | new public method `OctSet(obj, 'Name', Value, ...)` with the constructor's body (PROBLEM: also re-runs `Setting`, `GetOptimum(10000)`, `GetPF`) | Octave's implicit subclass constructors (e.g. `DTLZ2('M',5)`) do **not** forward their arguments to the superclass constructor, so N/M/D/maxFE/parameter/save/outputFcn were silently ignored. Use `P = DTLZ2(); P.OctSet('M',5,'D',14)` (done by `platemo/run_twin.m`) |

Environment
- Octave (tested with 10.3) and the Octave Forge **statistics** package 1.7.7 (`pkg load statistics`).
- `plat_seed.m` seeds `rand`/`randn`/`rande`/`randg`/`randp` with `'twister'`; PlatEMO's `platemo.m` is
  bypassed because it calls `rng('shuffle')`.
