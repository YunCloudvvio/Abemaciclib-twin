#!/bin/bash
# Makes the Octave-compatible PlatEMO copy used by the MOEA runs:
#   bash platemo/octave/apply_patches.sh /path/to/PlatEMO      (the PlatEMO folder of a BIMK/PlatEMO clone)
# Tested with PlatEMO v4.16, commit d25e65d1ffba58dbf4d7e1b5259786187d12968a. The copy is written to
# platemo/PlatEMO_oct; the original clone is not modified. See PATCHES.md.
set -eu
SRC=${1:?path to the PlatEMO folder}
HERE=$(cd "$(dirname "$0")" && pwd)
DST=$(dirname "$HERE")/PlatEMO_oct
rm -rf "$DST"; mkdir -p "$DST"
cp -r "$SRC"/Algorithms "$SRC"/Metrics "$SRC"/Problems "$SRC"/platemo.m "$DST"/
patch -d "$DST" -p1 --binary < "$HERE/patches/PROBLEM.m.diff"
patch -d "$DST" -p1 --binary < "$HERE/patches/ALGORITHM.m.diff"
rm "$DST/Problems/SOLUTION.m"
cp -r "$HERE/patches/@SOLUTION" "$DST/Problems/"
echo "patched PlatEMO copy: $DST"
