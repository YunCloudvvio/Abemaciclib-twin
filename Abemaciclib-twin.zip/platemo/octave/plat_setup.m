function root = plat_setup()
%PLAT_SETUP  Add the Octave-patched PlatEMO copy (without GUI) to the path once.
%   The copy is platemo/PlatEMO_oct (made by platemo/octave/apply_patches.sh) or the folder in the
%   environment variable PLATEMO_OCT. Needs the Octave Forge statistics package; set OCTAVE_PKG_LIST to a
%   local package list if the package is not installed globally.
    persistent done
    here = fileparts(mfilename('fullpath'));
    root = getenv('PLATEMO_OCT');
    if isempty(root), root = fullfile(fileparts(here), 'PlatEMO_oct'); end
    if isempty(done)
        warning('off','all');
        if ~isempty(getenv('OCTAVE_PKG_LIST')), pkg('local_list', getenv('OCTAVE_PKG_LIST')); end
        pkg('load','statistics');
        addpath(fullfile(here,'shims'));
        p = strsplit(genpath(root),pathsep);
        p = p(~cellfun(@isempty,p) & cellfun(@isempty,strfind(p,[filesep 'GUI'])));
        addpath(strjoin(p,pathsep));
        addpath(here);
        done = true;
    end
end
