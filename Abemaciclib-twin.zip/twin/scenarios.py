"""Scenarios of the sensitivity analysis (E4): one factor changed at a time on P1, plus the 3 x 3 grid of the
exposure-efficacy slope and the diarrhoea tolerance rate.

A scenario is selected with the environment variable TWIN_SCENARIO (unset or "base": the main analysis),
so that every program that builds an Instance (optimisation server, MOSI runner, true-value
recomputation, cross-check, test-population evaluation) uses the same scenario. The cumulative-exposure
tolerance scenario uses STRUCT=exposure with the base scenario.

Keys:
  e_abe, hz_conc  typical abemaciclib tumour-shrinkage effect (1/week per umol/L) and concentration
                  coefficient of the hazard (per umol/L); low / high = bootstrap 95% CI of Chigutsa 2026
  tol_mult        multiplier of the calibrated diarrhoea tolerance rate of every ensemble member
  anc_mult        multiplier of the calibrated typical neutrophil drug-effect slope of every member
  rdi_min         lower bound of the median relative dose intensity (constraint 1)
  months          simulation window in months (f1 = -RMST over the window; f3 stays 6 months)
The low / high multipliers 1/1.5 and 1.5 are the ranges of the global sensitivity analysis.
"""
import os

from . import params as P

EFFICACY = {"low": {"e_abe": 0.0259, "hz_conc": 0.820}, "mid": {}, "high": {"e_abe": 0.0661, "hz_conc": 2.34}}
TOLERANCE = {"low": {"tol_mult": 1.0 / 1.5}, "mid": {}, "high": {"tol_mult": 1.5}}

SCENARIOS = {"base": {}}
for _e, _ev in EFFICACY.items():
    for _t, _tv in TOLERANCE.items():
        if _e == "mid" and _t == "mid":
            continue
        SCENARIOS[f"eff_{_e}_tol_{_t}"] = {**_ev, **_tv}
SCENARIOS.update({
    "anc_low": {"anc_mult": 1.0 / 1.5},
    "anc_high": {"anc_mult": 1.5},
    "rdi_0.5": {"rdi_min": 0.5},
    "rdi_0.7": {"rdi_min": 0.7},
    "window_18": {"months": 18},
    "window_36": {"months": 36},
})
KEYS = {"e_abe", "hz_conc", "tol_mult", "anc_mult", "rdi_min", "months"}


def current():
    """(name, settings) of the scenario selected by TWIN_SCENARIO."""
    name = os.environ.get("TWIN_SCENARIO", "") or "base"
    if name not in SCENARIOS:
        raise ValueError(f"unknown scenario {name!r}")
    return name, dict(SCENARIOS[name])


def window_days(months):
    return int(round(months * P.DAYS_PER_MONTH))
