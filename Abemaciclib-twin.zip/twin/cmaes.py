"""Minimal (mu/mu_w, lambda)-CMA-ES (Hansen 2016, "The CMA Evolution Strategy: A Tutorial").

Used only for calibrating the twin, so that the calibration does not depend on the
`cma` package. Box bounds are handled by evaluating the clipped point and
adding a quadratic penalty for the distance to the box.
"""
import math

import numpy as np


class CMAES:
    def __init__(self, x0, sigma0, lower, upper, popsize=None, seed=0):
        self.n = n = len(x0)
        self.mean = np.asarray(x0, dtype=float).copy()
        self.sigma = float(sigma0)
        self.lower = np.asarray(lower, dtype=float)
        self.upper = np.asarray(upper, dtype=float)
        self.lam = popsize or 4 + int(3 * math.log(n))
        self.mu = self.lam // 2
        w = math.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.w = w / w.sum()
        self.mueff = 1.0 / np.sum(self.w ** 2)
        self.cc = (4 + self.mueff / n) / (n + 4 + 2 * self.mueff / n)
        self.cs = (self.mueff + 2) / (n + self.mueff + 5)
        self.c1 = 2 / ((n + 1.3) ** 2 + self.mueff)
        self.cmu = min(1 - self.c1, 2 * (self.mueff - 2 + 1 / self.mueff) / ((n + 2) ** 2 + self.mueff))
        self.damps = 1 + 2 * max(0.0, math.sqrt((self.mueff - 1) / (n + 1)) - 1) + self.cs
        self.chin = math.sqrt(n) * (1 - 1 / (4 * n) + 1 / (21 * n * n))
        self.pc = np.zeros(n)
        self.ps = np.zeros(n)
        self.C = np.eye(n)
        self.B = np.eye(n)
        self.D = np.ones(n)
        self.gen = 0
        self.rng = np.random.default_rng(seed)
        self.best_f = math.inf
        self.best_x = self.mean.copy()
        self.history = []

    def ask(self):
        z = self.rng.standard_normal((self.lam, self.n))
        return self.mean + self.sigma * (z * self.D) @ self.B.T

    def clip(self, x):
        return np.clip(x, self.lower, self.upper)

    def penalty(self, x):
        return 1e3 * float(np.sum((x - self.clip(x)) ** 2))

    def tell(self, xs, fs):
        xs = np.asarray(xs)
        fs = np.asarray(fs, dtype=float)
        order = np.argsort(fs)
        if fs[order[0]] < self.best_f:
            self.best_f = float(fs[order[0]])
            self.best_x = self.clip(xs[order[0]]).copy()
        self.history.append(float(fs[order[0]]))
        old = self.mean
        sel = xs[order[:self.mu]]
        self.mean = self.w @ sel
        y = (self.mean - old) / self.sigma
        inv_sqrt_c = self.B @ np.diag(1.0 / self.D) @ self.B.T
        self.ps = (1 - self.cs) * self.ps + math.sqrt(self.cs * (2 - self.cs) * self.mueff) * inv_sqrt_c @ y
        self.gen += 1
        hsig = (np.linalg.norm(self.ps) / math.sqrt(1 - (1 - self.cs) ** (2 * self.gen)) / self.chin
                < 1.4 + 2 / (self.n + 1))
        self.pc = (1 - self.cc) * self.pc + hsig * math.sqrt(self.cc * (2 - self.cc) * self.mueff) * y
        art = (sel - old) / self.sigma
        self.C = ((1 - self.c1 - self.cmu) * self.C
                  + self.c1 * (np.outer(self.pc, self.pc) + (1 - hsig) * self.cc * (2 - self.cc) * self.C)
                  + self.cmu * art.T @ np.diag(self.w) @ art)
        self.sigma *= math.exp((self.cs / self.damps) * (np.linalg.norm(self.ps) / self.chin - 1))
        self.C = np.triu(self.C) + np.triu(self.C, 1).T
        d2, self.B = np.linalg.eigh(self.C)
        self.D = np.sqrt(np.clip(d2, 1e-20, None))

    def stop(self, tolx=1e-3, tolfun=1e-3):
        window = 10 + int(math.ceil(30 * self.n / self.lam))   # Hansen's TolHistFun window
        if self.sigma * float(np.max(self.D)) < tolx:
            return "tolx"
        if len(self.history) >= window and max(self.history[-window:]) - min(self.history[-window:]) < tolfun:
            return "tolfun"
        if float(np.max(self.D)) > 1e7 * float(np.min(self.D)):
            return "condition"
        return None


def minimize(fun, x0, sigma0, lower, upper, max_evals, popsize=None, seed=0, log=None):
    """One CMA-ES run. fun(x) is called on the clipped point; returns the optimiser."""
    es = CMAES(x0, sigma0, lower, upper, popsize=popsize, seed=seed)
    evals = 0
    while evals < max_evals:
        xs = es.ask()
        fs = [fun(es.clip(x)) + es.penalty(x) for x in xs]
        evals += len(xs)
        es.tell(xs, fs)
        if log is not None:
            log(es, evals)
        reason = es.stop()
        if reason:
            es.stop_reason = reason
            break
    else:
        es.stop_reason = "max_evals"
    es.evals = evals
    return es
