"""Post-run step for PlatEMO algorithms run with TWIN_DEB=1 (no constraint handling of their own).

Those algorithms saw Deb-transformed objectives and zero constraints (platemo/twin_constraints.m). This
step recomputes the true objectives and constraints of every stored decision vector (final population
and all checkpoints) with the same SAA instance, checks that the values the algorithm saw are exactly the
Deb transform of the true values (and that its constraints were all zero), and writes a .mat file in
which Obj/Con and ckpt_Obj/ckpt_Con hold the TRUE values; the algorithm's values are kept as
ObjAlg/ConAlg and ckpt_ObjAlg/ckpt_ConAlg. Any mismatch is an error and no output is written.

Run from the project root:
  python -m twin.true_values --inp run.tmp.mat --out run.mat --instance P1 --seed 3000001 --structure time
"""
import argparse
import os
import sys

import numpy as np
from scipy.io import loadmat, savemat

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, ROOT)

from twin import problems  # noqa: E402
from twin.si_runner import constrained_objectives  # noqa: E402


def deb(F, G):
    return np.array([constrained_objectives(f, g) for f, g in zip(F, G)]).reshape(F.shape)


def recompute(inst, X, cache):
    F = np.zeros((len(X), problems.N_OBJ))
    G = np.zeros((len(X), problems.N_CON))
    for j, x in enumerate(X):
        key = np.asarray(x, dtype=float).tobytes()
        if key not in cache:
            Fx, Gx = inst.evaluate(x)
            cache[key] = (Fx[0], Gx[0])
        F[j], G[j] = cache[key]
    return F, G


def check(F_alg, C_alg, F, G, where):
    if C_alg.size and np.any(C_alg != 0):
        raise SystemExit(f"{where}: the algorithm saw non-zero constraints (TWIN_DEB not active?)")
    if F_alg.shape != F.shape or not np.allclose(F_alg, deb(F, G), rtol=0.0, atol=1e-9):
        diff = np.max(np.abs(F_alg - deb(F, G))) if F_alg.shape == F.shape else "shape"
        raise SystemExit(f"{where}: stored objectives are not the Deb transform of the true values ({diff})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inp", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--instance", required=True, choices=problems.INSTANCES)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--structure", default="time")
    ap.add_argument("--calibration", default=os.path.join(ROOT, "calibration"))
    args = ap.parse_args()
    d = loadmat(args.inp)
    inst = problems.Instance(os.path.join(args.calibration, f"ensemble_{args.structure}.json"),
                             os.path.join(args.calibration, f"stage3_{args.structure}.json"),
                             args.seed, name=args.instance)
    cache = {}
    F, G = recompute(inst, d["Dec"], cache)
    check(d["Obj"], d["Con"], F, G, "final population")
    out = {k: v for k, v in d.items() if not k.startswith("__")}
    out["ObjAlg"], out["ConAlg"] = d["Obj"], d["Con"]
    out["Obj"], out["Con"] = F, G
    n = d["ckpt_Dec"].size
    cF = np.empty((1, n), dtype=object)
    cG = np.empty((1, n), dtype=object)
    for i in range(n):
        Xi = np.asarray(d["ckpt_Dec"].ravel()[i])
        Fi, Gi = recompute(inst, Xi, cache)
        check(np.asarray(d["ckpt_Obj"].ravel()[i]), np.asarray(d["ckpt_Con"].ravel()[i]), Fi, Gi, f"checkpoint {i + 1}")
        cF[0, i], cG[0, i] = Fi, Gi
    out["ckpt_ObjAlg"], out["ckpt_ConAlg"] = d["ckpt_Obj"], d["ckpt_Con"]
    out["ckpt_Obj"], out["ckpt_Con"] = cF, cG
    out["true_values_recomputed"] = np.array([[1]])
    savemat(args.out, out)
    print(f"true values: {len(cache)} unique policies re-evaluated; final {len(F)} rows, "
          f"{int(np.all(G <= 0, axis=1).sum())} feasible; {n} checkpoints checked")


if __name__ == "__main__":
    main()
