"""Simulation of the published trials, used for calibration and held-out checks.

Targets are percentages unless stated. Sources:
  MONARCH 1: Dickler 2017 (Clin Cancer Res) and label Tables 16-17.
  MONARCH 2: Sledge 2017 (J Clin Oncol) and label Tables 12-13.
  MONARCH 3: Johnston 2019 (npj Breast Cancer) and label Tables 10-11.
  TRADE:     ClinicalTrials.gov NCT06001762 results (12 and 24 weeks).
Neutropenia targets are the laboratory-based grade >= 3 rates of the label.
"""
import math

import numpy as np

from . import kernel as K
from . import params as P
from . import population as pm

N_DAYS = P.N_DAYS_DEFAULT
N_DAYS_EFFICACY = 1460   # 48 months: long enough to observe every median PFS

TARGETS = {
    "monarch1": {"n": 132, "anc3_lab": 26.9, "diar_any": 90.2, "diar_g2": 28.8, "diar_g3": 19.7,
                 "diar_onset_days": 7.0, "held_diar": 24.0, "reduced_diar": 20.0,
                 "held_anc": 16.0, "reduced_anc": 11.0, "median_pfs_months": 6.0, "median_pfs_smooth_months": 6.0,
                 "reduced_ae": 49.0, "discontinued": 8.0},
    "monarch2": {"n": 441, "anc3_lab": 32.5, "diar_any": 86.4, "diar_g3": 13.4, "on_200mg_days": 34.0,
                 "diar_onset_days": 6.0, "held_diar": 19.0, "reduced_diar": 19.0,
                 "held_anc": 16.0, "reduced_anc": 10.0, "median_pfs_months": 16.4,
                 "reduced_ae": 43.0, "discontinued": 9.0},
    "monarch3": {"n": 327, "anc3_lab": 21.9, "diar_any": 82.3, "diar_g2": 30.3, "diar_g3": 9.5,
                 "diar_onset_days": 8.0, "held_diar": 15.0, "reduced_diar": 13.0,
                 "held_anc": 16.0, "reduced_anc": 11.0, "median_pfs_months": 28.18,
                 "reduced_ae": 43.0, "discontinued": 13.0},
    # monarchE (label, N = 2791): early breast cancer, 150 mg from the start for 2 years.
    "monarche": {"n": 2791, "anc3_lab": 18.7, "diar_any": 84.0, "diar_g3": 8.0,
                 "held_diar": 20.0, "held_anc": 16.0, "reduced_diar": 17.0, "reduced_anc": 8.0,
                 "reduced_ae": 44.0, "discontinued": 19.0},
    "monarch3_control": {"n": 165, "median_pfs_months": 14.76},
    "monarch2_control": {"n": 223, "median_pfs_months": 9.3},
}
# Confirmed objective response, patients with measurable disease (%):
# MONARCH 2 (Sledge 2017): 48.1 (95% CI 42.6-53.6) vs 21.3 (15.1-27.6);
# MONARCH 3 (Johnston 2019, Table 1 footnote): 55.4 vs 40.2; n measurable 267 and 132.
ORR_TARGETS = {"monarch2": 48.1, "monarch2_control": 21.3, "monarch3": 55.4, "monarch3_control": 40.2}
ORR_N = {"monarch2": 318, "monarch2_control": 164, "monarch3": 267, "monarch3_control": 132}

# Ranges from the label, section 5.2 (five trials pooled, laboratory based): median time to
# the first grade >= 3 episode 29-34 days, median duration 10-16 days. Compared with the
# detected (blood-count based) quantities; a simulated value inside the range costs nothing.
LABEL_RANGES = {
    "anc3_first_day": (29.0, 34.0),
    "anc3_duration_lab": (10.0, 16.0),
}

TRADE_TARGETS = {   # percentages of 89 evaluable patients (n = 90 for diarrhoea and neutropenia)
    "n": 89,
    "maintained_150_w12": 70.8, "not_reached_w12": 9.0, "discontinued_w12": 6.7, "reduced_w12": 13.5,
    "maintained_150_w24": 52.8, "not_reached_w24": 13.5, "discontinued_w24": 18.0, "reduced_w24": 32.6,
    "diar_g2plus_w24": 33.3, "diar_g3_w24": 5.6, "anc3_w24": 4.4,
}
# Discontinuation in TRADE is for any reason (7.9% for adverse events at 24 weeks, ESMO Open 2026);
# the twin only discontinues after intolerance of 50 mg, so it should fall below these values.

FRAC_200MG_START = 0.274       # MONARCH 2, Sledge 2017
MEDIAN_DAYS_ON_200MG = 34.0    # median; the distribution is not reported (assumed exponential)


# ------------------------------------------------------------------ schedules

def trial_cbc_schedule(n_days, day15=True):
    """Day 1 of each 28-day cycle, plus day 15 of cycle 1 (MONARCH 2; assumed for MONARCH 1)."""
    is_cbc = np.zeros(n_days + 1, dtype=np.bool_)
    is_cbc[np.arange(0, n_days + 1, 28)] = True
    if day15:
        is_cbc[14] = True
    return is_cbc


def imaging_days(trial, n_days):
    """Scheduled tumour assessments (days from first dose).
    MONARCH 2: every 8 weeks in the first year, then every 12 weeks.
    MONARCH 3: every 2 cycles up to cycle 18 (day 504), then every 3 cycles.
    MONARCH 1: every 2 cycles (assumed)."""
    if trial.startswith("monarch2"):
        first = np.arange(56, 365, 56)
        later = np.arange(first[-1] + 84, n_days + 85, 84)
    elif trial.startswith("monarch3"):
        first = np.arange(56, 505, 56)
        later = np.arange(first[-1] + 84, n_days + 85, 84)
    else:
        first = np.arange(56, n_days + 57, 56)
        later = np.zeros(0)
    return np.concatenate([first, later]).astype(float)


def observed_pfs_days(pfs_days, trial, n_days, window=7.0, seed=0):
    """Progression is seen at the next scheduled assessment; no event before the end -> censored.
    Each assessment of each patient falls uniformly within +/- `window` days of its scheduled
    day (visit window); without it the Kaplan-Meier median can only take the scheduled days,
    which are up to 12 weeks apart."""
    visits = imaging_days(trial, n_days)
    rng = np.random.default_rng(seed)
    actual = visits[None, :] + rng.uniform(-window, window, (pfs_days.size, visits.size))
    actual = np.maximum.accumulate(actual, axis=1)
    seen = actual >= pfs_days[:, None]
    idx = np.where(seen.any(axis=1), seen.argmax(axis=1), visits.size - 1)
    observed = actual[np.arange(pfs_days.size), idx]
    event = pfs_days < n_days
    return np.where(event, np.minimum(observed, float(n_days)), float(n_days)), event


def km_median_months(times, events):
    """Kaplan-Meier median (months); nan if the curve stays above 0.5."""
    order = np.argsort(times, kind="stable")
    t, e = times[order], events[order]
    n_at_risk = t.size - np.arange(t.size)
    surv = np.cumprod(np.where(e, 1.0 - 1.0 / n_at_risk, 1.0))
    below = np.nonzero(surv <= 0.5)[0]
    return float(t[below[0]]) / P.DAYS_PER_MONTH if below.size else float("nan")


# ------------------------------------------------------------------ policies and populations

def trial_policy():
    theta = K.standard_policy()
    theta[K.T_TARGET_LEVEL] = 4     # 200 mg is allowed in the trial settings
    return theta


def no_abemaciclib_policy():
    theta = K.standard_policy()
    theta[K.T_START_LEVEL] = 0
    theta[K.T_TARGET_LEVEL] = 0
    return theta


def monarch1_population(n, seed, hazard_mult):
    """200 mg monotherapy in heavily pretreated patients. No endocrine partner.

    The baseline hazard multiplier is a nuisance parameter fitted to the median
    PFS; it only sets how long patients stay at risk of toxicity."""
    pop = pm.sample_patients(n, seed, e_endocrine=0.0, frac_measurable=P.M1_FRAC_MEASURABLE,
                             frac_ecog1=P.M1_FRAC_ECOG1, frac_hepatic=P.M1_FRAC_HEPATIC)
    pop[:, pm.C_START_LEVEL] = 4
    pop[:, pm.C_HZ_BASE] *= hazard_mult
    return pop


def monarch2_population(n, seed, force_median_days=MEDIAN_DAYS_ON_200MG):
    """MONARCH 2: 27.4% started at 200 mg and were reduced to 150 mg by the protocol amendment.
    Sledge 2017: median 34 days on 200 mg before a dose reduction or discontinuation for any reason;
    the median of the mandated reduction time itself is calibrated so that the simulated time to the
    first reduction or discontinuation of these patients matches the 34 days."""
    pop = pm.sample_patients(n, seed)
    rng = np.random.default_rng(seed + 100003)
    high = rng.random(n) < FRAC_200MG_START
    pop[:, pm.C_START_LEVEL] = np.where(high, 4, 3)
    days = rng.exponential(force_median_days / math.log(2.0), n)
    pop[:, pm.C_FORCE_DAY] = np.where(high, days, np.inf)
    pop[:, pm.C_FORCE_LEVEL] = np.where(high, 3, 0)
    return pop


def monarch2_control_population(n, seed):
    return pm.sample_patients(n, seed, control_arm=True)


def monarch3_population(n, seed, e_ai=P.TS_E_FULV, hazard_mult=1.0, control_arm=False):
    """First-line, non-steroidal aromatase inhibitor partner (Goetz 2017 covariates).

    e_ai and hazard_mult are the two stage-3 parameters: the aromatase-inhibitor shrinkage effect and
    the first-line multiplier of the baseline hazard. The abemaciclib effect, the
    waning of the drug effect and the rest of the hazard model come from MONARCH 2.
    control_arm=True: aromatase inhibitor alone, with the drug-effect half-life of the endocrine-alone arm."""
    pop = pm.sample_patients(n, seed, e_endocrine=e_ai, control_arm=control_arm,
                             frac_measurable=P.M3_FRAC_MEASURABLE, frac_ecog1=P.M3_FRAC_ECOG1,
                             frac_hepatic=P.M3_FRAC_HEPATIC)
    pop[:, pm.C_HZ_BASE] *= hazard_mult
    if not control_arm:
        pop[:, pm.C_START_LEVEL] = 3
    return pop


def monarch3_population_approx(n, seed):
    """Toxicity checks before stage 3: MONARCH 3 covariates, all starting at 150 mg."""
    return monarch3_population(n, seed)


def apply_toxicity_parameters(pop, anc_slope):
    """Rescale the initial neutrophil slope to a new typical value."""
    pop = pop.copy()
    pop[:, pm.C_SLOPE] *= anc_slope / P.ANC_SLOPE
    return pop


def diarrhoea_constants(q01, q12, q23, tolerance, beta, structure=K.TOL_TIME, other=None):
    """tolerance: kh per day (time structure) or kc per mg.h/L (exposure structure).
    other: (reduction rate, discontinuation rate, decline rate) per day for other adverse reactions."""
    down = [math.log(2.0) / (d * 24.0) for d in P.DI_MEDIAN_DAYS]
    kh = tolerance / 24.0 if structure == K.TOL_TIME else 0.0
    kc = tolerance if structure == K.TOL_EXPOSURE else 0.0
    other = [P.OTH_RED_PER_DAY, P.OTH_DISC_PER_DAY, P.OTH_K_PER_DAY] if other is None else other
    return np.array([q01 / 24.0, q12 / 24.0, q23 / 24.0] + down
                    + [kh, beta, P.DI_C_REF, float(structure), kc] + [v / 24.0 for v in other])


# ------------------------------------------------------------------ running and summaries

def run(pop, noise, is_cbc, dcon, n_days=N_DAYS, theta=None):
    threshold, u = noise
    out = np.zeros((pop.shape[0], K.N_OUT))
    if theta is None:
        theta = trial_policy()
    K.simulate(theta, pop, threshold, u, is_cbc, dcon, pm.pk_constants(), n_days, out, K.NO_TRACE)
    return out


def _median_pfs(out, trial, n_days):
    if trial is None:
        return float(np.median(out[:, K.O_PFS_DAYS])) / P.DAYS_PER_MONTH
    obs, event = observed_pfs_days(out[:, K.O_PFS_DAYS], trial, n_days)
    return km_median_months(obs, event)


def smooth_median(values):
    """Harrell-Davis median: a smooth estimator for quantities that take only a few values
    (blood-count days, 6-hour steps), so that the calibration loss does not jump between them."""
    from scipy.stats.mstats import hdquantiles
    v = np.asarray(values, dtype=float)
    if v.size == 0:
        return float("nan")
    if v.size > 4000:
        v = np.sort(v)[np.linspace(0, v.size - 1, 4000).astype(int)]   # evenly spaced order statistics
    return float(hdquantiles(v, prob=[0.5])[0])


def _median_pfs_smooth(out, trial, n_days):
    """Median PFS (months) as a smooth function of the parameters, for the calibration loss: Harrell-Davis
    median of the continuous progression times plus the mean detection delay, half of the first scan
    interval (28 days for scans every 8 weeks). The scan-based Kaplan-Meier median is not smooth: with
    scans every 8 weeks it jumps between scan days (MONARCH 1: about 5.7 or 7.2 months depending on the
    sample). Patients without progression keep the end of the simulation (MONARCH 1: about 20% at
    730 days, well below the 50% that would make the median depend on the horizon)."""
    if trial is None:
        return float("nan")
    delay = 0.5 * imaging_days(trial, n_days)[0]
    pfs = out[:, K.O_PFS_DAYS]
    return smooth_median(np.where(pfs < n_days, pfs + delay, pfs)) / P.DAYS_PER_MONTH


def _median_where(values, mask):
    return float(np.median(values[mask])) if np.any(mask) else float("nan")


def summarize(out, trial=None, n_days=N_DAYS):
    """Summary statistics of one simulated trial. With `trial`, the median PFS is the
    Kaplan-Meier median of progression seen at that trial's scheduled scans."""
    pct = lambda mask: 100.0 * float(np.mean(mask))  # noqa: E731
    onset = out[:, K.O_DIAR_ONSET_DAY]
    first_anc = out[:, K.O_FIRST_ANC3_DAY]
    true_onset = out[:, K.O_ANC3_ONSET_TRUE]
    return {
        "anc3_lab": pct(out[:, K.O_ANC3_DETECTED] > 0),
        "anc4_lab": pct(out[:, K.O_ANC4_DETECTED] > 0),
        "anc3_true": pct(out[:, K.O_ANC3] > 0),
        # Times to onset are study days (first dose = day 1), as in the trial reports; durations are days.
        "anc3_first_day": smooth_median(first_anc[first_anc >= 0] + 1.0),
        "anc3_onset_days": smooth_median(true_onset[true_onset >= 0] + 1.0),
        "anc3_duration_days": smooth_median(out[true_onset >= 0, K.O_ANC3_DUR_TRUE]),
        "anc3_duration_lab": smooth_median(out[out[:, K.O_ANC3_DUR_LAB] >= 0, K.O_ANC3_DUR_LAB]),
        "diar_any": pct(out[:, K.O_MAX_DIAR] >= 1),
        "diar_g2": pct(out[:, K.O_MAX_DIAR] == 2),
        "diar_g3": pct(out[:, K.O_MAX_DIAR] >= 3),
        "diar_onset_days": smooth_median(onset[onset >= 0] + 1.0),
        "held_diar": pct(out[:, K.O_HELD_DIAR] > 0),
        "reduced_diar": pct(out[:, K.O_N_RED_DIAR] > 0),
        "held_anc": pct(out[:, K.O_HELD_ANC] > 0),
        "reduced_anc": pct(out[:, K.O_N_RED_ANC] > 0),
        "reduced_any": pct(out[:, K.O_N_RED] > 0),
        "reduced_ae": pct((out[:, K.O_N_RED_DIAR] + out[:, K.O_N_RED_ANC] + out[:, K.O_N_RED_AE_OTHER]) > 0),
        "reduced_other_ae": pct(out[:, K.O_N_RED_AE_OTHER] > 0),
        "discontinued": pct(out[:, K.O_DISCONTINUED] > 0),
        "median_pfs_months": _median_pfs(out, trial, n_days),
        "median_pfs_smooth_months": _median_pfs_smooth(out, trial, n_days),
        "median_rdi": float(np.median(out[:, K.O_RDI])),
    }


def confirmed_orr(out, pop):
    """Confirmed response rate (%) among patients with measurable disease."""
    meas = pop[:, pm.C_MEAS] > 0.5
    return 100.0 * float(np.mean(out[meas, K.O_PR_DAYS] >= 28))


def reduction_counts(out):
    """Fractions of patients with 0, 1, 2, >= 3 dose reductions (Chigutsa 2026, Figure S2)."""
    r = out[:, K.O_N_RED]
    return [float(np.mean(r == 0)), float(np.mean(r == 1)), float(np.mean(r == 2)), float(np.mean(r >= 3))]


# ------------------------------------------------------------------ TRADE (NCT06001762)

TRADE_DAYS = 168


def trade_cbc_schedule(n_days=TRADE_DAYS):
    """Protocol section 10: C1D1, C1D15, C2D1, C2D15, C3D1, then every 3 cycles."""
    is_cbc = np.zeros(n_days + 1, dtype=np.bool_)
    for d in (0, 14, 28, 42, 56):
        is_cbc[d] = True
    is_cbc[np.arange(56 + 84, n_days + 1, 84)] = True
    return is_cbc


def trade_policy():
    """50 mg for 14 days, 100 mg for 14 days, then 150 mg, each step only if tolerated
    (no grade >= 3 neutropenia at the last count, no grade >= 2 diarrhoea on the day);
    no re-escalation after a reduction (ESMO Open 2026)."""
    theta = np.zeros(K.N_THETA)
    theta[K.T_START_LEVEL] = 1
    theta[K.T_TARGET_LEVEL] = 3
    theta[K.T_ESC_DAYS] = 14
    theta[K.T_ANC_MIN] = 1.0
    theta[K.T_DIAR_FREE_DAYS] = 1
    theta[K.T_RE_DAYS] = 28
    theta[K.T_R_MAX] = 0
    return theta


def trade_summary(out12, out24):
    """TRADE end points from two runs (84 and 168 days) on the same patients and random numbers."""
    pct = lambda mask: 100.0 * float(np.mean(mask))  # noqa: E731
    res = {}
    # Week 12: the composite end point splits into mutually exclusive groups (6.7 + 13.5 + 9.0 = 29.2):
    # discontinued; else reduced; else 150 mg never reached. Week 24 (ClinicalTrials.gov) reports
    # overlapping counts: discontinued, any reduction, 150 mg never reached.
    for tag, out in (("w12", out12), ("w24", out24)):
        reached = out[:, K.O_MAX_LEVEL] >= 3
        reduced = out[:, K.O_N_RED] > 0
        disc = out[:, K.O_DISCONTINUED] > 0
        res[f"maintained_150_{tag}"] = pct(reached & ~reduced & ~disc)
        res[f"discontinued_{tag}"] = pct(disc)
        if tag == "w12":
            res["reduced_w12"] = pct(reduced & ~disc)
            res["not_reached_w12"] = pct(~reached & ~reduced & ~disc)
        else:
            res["reduced_w24"] = pct(reduced)
            res["not_reached_w24"] = pct(~reached)
    res["diar_g2plus_w24"] = pct(out24[:, K.O_MAX_DIAR] >= 2)
    res["diar_g3_w24"] = pct(out24[:, K.O_MAX_DIAR] >= 3)
    res["anc3_w24"] = pct(out24[:, K.O_ANC3_DETECTED] > 0)
    res["anc3_true_w24"] = pct(out24[:, K.O_ANC3] > 0)
    return res


def run_trade(pop, u, dcon):
    """pop: patients with toxicity parameters applied; progression is switched off (early disease)."""
    n = pop.shape[0]
    threshold = np.full(n, np.inf)
    cbc = trade_cbc_schedule()
    outs = []
    for days in (84, TRADE_DAYS):
        out = np.zeros((n, K.N_OUT))
        K.simulate(trade_policy(), pop, threshold, u, cbc, dcon, pm.pk_constants(), days, out, K.NO_TRACE)
        outs.append(out)
    return trade_summary(*outs)


# ------------------------------------------------------------------ monarchE (held out)

def monarche_population(n, seed):
    """Early breast cancer, 150 mg from the start; recurrence is not simulated (2 years of treatment)."""
    pop = pm.sample_patients(n, seed)
    pop[:, pm.C_START_LEVEL] = 3
    return pop


def run_monarche(pop, u, dcon, n_days=N_DAYS):
    n = pop.shape[0]
    out = np.zeros((n, K.N_OUT))
    K.simulate(trial_policy(), pop, np.full(n, np.inf), u, pm.cbc_schedule(n_days), dcon,
               pm.pk_constants(), n_days, out, K.NO_TRACE)
    return out


def days_on_200mg(out, pop):
    """MONARCH 2 patients who started at 200 mg: median day of the first reduction or discontinuation."""
    high = pop[:, pm.C_START_LEVEL] > 3.5
    d = out[high, K.O_FIRST_CHANGE_DAY]
    d = np.where(d >= 0, d + 1.0, np.inf)        # study day; never changed -> beyond every observed day
    return float(np.median(d))
