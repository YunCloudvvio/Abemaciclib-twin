"""Evaluation server for PlatEMO running under Octave.

PlatEMO (Octave) and this process talk over two named pipes in --dir:
  request  : float64 header [n, d] followed by the n x d decision matrix (row-major); n = 0 ends the server
  response : float64 n x (n_obj + n_con) matrix (row-major): objectives, then constraints (<= 0 feasible)
One request per PlatEMO evaluation call (a whole population), so there is no per-solution overhead.

Run (before starting Octave):
  python -m twin.platemo_server --dir /tmp/fifo --instance P1 --ensemble calibration/ensemble_time.json \
      --stage3 calibration/stage3_time.json --seed 1
"""
import argparse
import os
import struct
import sys
import time

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, ROOT)

from twin import problems  # noqa: E402


def read_exact(f, n):
    buf = b""
    while len(buf) < n:
        chunk = f.read(n - len(buf))
        if not chunk:
            raise EOFError
        buf += chunk
    return buf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--instance", default="P1")
    ap.add_argument("--ensemble", required=True)
    ap.add_argument("--stage3", required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--n-per-member", type=int, default=10)
    args = ap.parse_args()
    inst = problems.Instance(args.ensemble, args.stage3, args.seed, args.n_per_member, name=args.instance)
    req_path, resp_path = os.path.join(args.dir, "req"), os.path.join(args.dir, "resp")
    for p in (req_path, resp_path):
        if not os.path.exists(p):
            os.mkfifo(p)
    with open(os.path.join(args.dir, "ready"), "w") as f:
        f.write(str(os.getpid()))
    n_calls = n_evals = 0
    t_eval = 0.0
    with open(req_path, "rb") as req, open(resp_path, "wb") as resp:
        while True:
            try:
                n, d = struct.unpack("<2d", read_exact(req, 16))
            except EOFError:
                break
            n, d = int(n), int(d)
            if n == 0:
                break
            X = np.frombuffer(read_exact(req, 8 * n * d), dtype="<f8").reshape(n, d)
            t0 = time.perf_counter()
            F, G = inst.evaluate(X)
            t_eval += time.perf_counter() - t0
            resp.write(np.ascontiguousarray(np.hstack([F, G]), dtype="<f8").tobytes())
            resp.flush()
            n_calls += 1
            n_evals += n
    print(f"server: {n_calls} calls, {n_evals} evaluations, {t_eval:.1f} s in the twin", flush=True)


if __name__ == "__main__":
    main()
