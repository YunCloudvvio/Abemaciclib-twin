"""Simulation kernel: one call simulates every virtual patient under one dosing policy.

Time grid: 6-hour steps. PK uses the closed-form solution of the
one-compartment model over each step, neutrophils use RK4 on the 6-hour grid,
tumour size and progression hazard use RK4 on the 6-hour grid with the
step-average concentration (a daily grid was too coarse for patients with a very
large abemaciclib effect); progression is checked once a day.

Patients are independent and are simulated in parallel (numba prange); the
results do not depend on the number of threads.
"""
import math

import numpy as np
from numba import njit, prange

from . import params as P
from .population import (C_ANC_BASE, C_DELAY, C_DI_MULT, C_E_ABE, C_E_ET, C_FMULT, C_GAMMA,
                         C_HZ_BASE, C_HZ_CFB, C_HZ_CONC, C_HZ_DECAY, C_KA, C_KE, C_KGROW,
                         C_KTR, C_KTRANS, C_MEAS, C_RESIST, C_S0, C_SLOPE, C_V,
                         C_FORCE_DAY, C_FORCE_LEVEL, C_START_LEVEL, C_G2_STRICT, C_ANC3_STRICT,
                         C_OTH_RED1, C_OTH_DISC)

# Policy vector theta.
(T_START_LEVEL, T_TARGET_LEVEL, T_ESC_DAYS, T_ANC_MIN, T_DIAR_FREE_DAYS,
 T_N_PRE, T_RE_DAYS, T_R_MAX, T_MODE) = range(9)
# T_MODE 0: adaptive policy (entries above). T_MODE 1: weekly schedule (problem P3): the planned level
# of week w (0-3, 0 = drug holiday) is theta[T_SCHED + w] for w < N_SCHED_WEEKS, then 150 mg; the label
# rules still withhold and reduce (a reduction lowers the cap that limits every later week).
T_SCHED = 9
N_SCHED_WEEKS = 24
N_THETA = T_SCHED + N_SCHED_WEEKS

# Daily trace of the first patient, filled when `trace` has n_days rows.
(TR_CONC, TR_ANC, TR_TUMOUR, TR_LEVEL, TR_GRADE, TR_ON_HOLD, N_TRACE) = range(7)

# Output columns, one row per patient.
(O_PFS_DAYS, O_ANC3, O_ANC4, O_ANC3_DETECTED, O_DIAR_DAYS_6M, O_RDI,
 O_DISCONTINUED, O_LEVEL_DAY84,
 O_ANC4_DETECTED, O_FIRST_ANC3_DAY, O_MAX_DIAR, O_DIAR_ONSET_DAY,
 O_HELD_DIAR, O_HELD_ANC, O_N_RED_DIAR, O_N_RED_ANC, O_N_RED_OTHER,
 O_ANC3_ONSET_TRUE, O_ANC3_DUR_TRUE, O_DAYS_6M, O_DISC_DAY, O_N_RED,
 O_PR_DAYS, O_ANC3_DUR_LAB, O_MAX_LEVEL, O_N_RED_AE_OTHER, O_DISC_AE_OTHER, O_FIRST_CHANGE_DAY,
 N_OUT) = range(29)
# O_FIRST_CHANGE_DAY: day of the first dose reduction or discontinuation for any reason, -1 if none.
# O_N_RED_OTHER: protocol-mandated reductions (MONARCH 2 amendment); O_N_RED_AE_OTHER:
# reductions for other adverse reactions; O_DISC_AE_OTHER: discontinued for other adverse reactions.
# O_FIRST_ANC3_DAY: first blood count that shows grade >= 3 (detected).
# O_ANC3_ONSET_TRUE / O_ANC3_DUR_TRUE: onset day and duration (days) of the first
#   true grade >= 3 episode; the duration is censored at the end of the simulation.
# O_DAYS_6M: days simulated within the first 182 days (shorter after early progression).
# O_DISC_DAY: day of discontinuation of abemaciclib, -1 if never.
# O_N_RED: number of dose reductions for any reason.
# O_PR_DAYS: longest run of days with tumour size <= 70% of baseline before progression
#   (measurable disease only; >= 28 days approximates a confirmed RECIST response).
# O_ANC3_DUR_LAB: days from the first blood count showing grade >= 3 to the first later
#   count showing grade <= 2 (laboratory-based duration, as in the label); -1 if none.
# O_MAX_LEVEL: highest dose level given.

# Diarrhoea tolerance structures (dcon[9]).
TOL_TIME = 0       # rates fall with time on study, exp(-kh * t)
TOL_EXPOSURE = 1   # rates fall with cumulative exposure, exp(-kc * AUC(t))

DOSE_PER_LEVEL = 50.0      # mg; level 3 = 150 mg twice daily
REFERENCE_DOSE = 150.0
PREVENTIVE_WINDOW_DAYS = 56
DIARRHOEA_WINDOW_DAYS = 182
HOLD_RECHECK_DAYS = 7      # assumption: weekly blood count while withheld

_DT = P.STEP_H
_SPD = P.STEPS_PER_DAY
_MW = P.MW_ABEMA / 1000.0  # mg/L -> umol/L divides by this


@njit(cache=True)
def _friberg(prol, t1, t2, t3, circ, ktr, base, gamma, effect):
    feedback = (base / max(circ, 1e-3)) ** gamma
    return (ktr * prol * ((1.0 - effect) * feedback - 1.0),
            ktr * (prol - t1), ktr * (t1 - t2), ktr * (t2 - t3), ktr * (t3 - circ))


@njit(cache=True)
def _tumour(h, d1, d2, d3, kgrow, kshrink, ktrans):
    return (kgrow - kshrink * h, kshrink * h - ktrans * d1,
            ktrans * (d1 - d2), ktrans * (d2 - d3))


@njit(cache=True, parallel=True)
def simulate(theta, pop, hazard_threshold, u_diar, is_cbc, dcon, pkcon, n_days, out, trace):
    n = pop.shape[0]
    tate_pk = pkcon[0] > 0.5
    want_trace = trace.shape[0] >= n_days
    n_steps = n_days * _SPD
    start_level = int(theta[T_START_LEVEL])
    target_level = int(theta[T_TARGET_LEVEL])
    esc_days = theta[T_ESC_DAYS]
    anc_min = theta[T_ANC_MIN]
    diar_free_days = theta[T_DIAR_FREE_DAYS]
    n_pre = int(theta[T_N_PRE])
    re_days = theta[T_RE_DAYS]
    r_max = int(theta[T_R_MAX])
    sched_mode = theta[T_MODE] > 0.5
    kh, beta, c_ref = dcon[6], dcon[7], dcon[8]
    tol_exposure = dcon[9] > 0.5
    kc = dcon[10]
    oth_red, oth_disc, oth_k = dcon[11], dcon[12], dcon[13]

    for i in prange(n):
        ka, ke, vol, fmult = pop[i, C_KA], pop[i, C_KE], pop[i, C_V], pop[i, C_FMULT]
        e_ka, e_ke = math.exp(-ka * _DT), math.exp(-ke * _DT)
        gain = ka / (ka - ke)
        int_ke, int_ka = (1.0 - e_ke) / ke, (1.0 - e_ka) / ka
        base, ktr = pop[i, C_ANC_BASE], pop[i, C_KTR]
        gamma, slope = pop[i, C_GAMMA], pop[i, C_SLOPE]
        measurable = pop[i, C_MEAS] > 0.5
        s0, kgrow, ktrans = pop[i, C_S0], pop[i, C_KGROW], pop[i, C_KTRANS]
        e_et, e_abe = pop[i, C_E_ET], pop[i, C_E_ABE]
        resist, delay = pop[i, C_RESIST], pop[i, C_DELAY]
        hz_base, hz_cfb = pop[i, C_HZ_BASE], pop[i, C_HZ_CFB]
        hz_conc, hz_decay = pop[i, C_HZ_CONC], pop[i, C_HZ_DECAY]
        dmult = pop[i, C_DI_MULT]

        a_gut = 0.0
        a_cen = 0.0
        prol = t1 = t2 = t3 = circ = base
        th, td1, td2, td3 = s0, 0.0, 0.0, 0.0
        cum_hazard = 0.0
        grade = 0

        level = min(start_level, target_level)
        cap = target_level
        if sched_mode:
            cap = 3
            level = min(int(theta[T_SCHED]), cap)    # week 1 (the weekly update sets the same value)
        if pop[i, C_START_LEVEL] > 0.5:          # trial settings: per-patient starting dose
            level = int(pop[i, C_START_LEVEL])
            cap = level
        force_day = pop[i, C_FORCE_DAY]          # protocol amendment (MONARCH 2)
        g2_strict = pop[i, C_G2_STRICT] > 0.5     # grade-2 diarrhoea rule applied to this patient
        anc3_strict = pop[i, C_ANC3_STRICT] > 0.5  # grade-3 neutropenia rule applied to this patient
        force_level = int(pop[i, C_FORCE_LEVEL])
        reason_diar = False
        reason_anc = False
        anc4_detected = False
        first_anc3_day = -1.0
        max_grade = 0
        onset_day = -1.0
        held_diar = held_anc = False
        n_red_diar = n_red_anc = n_red_other = 0
        hold_diar = False
        hold_anc = False
        reduce_on_resume = False
        discontinued = False
        g2_steps = 0
        cum_exp = 0.0                            # mg.h/L
        anc3_true_start = -1
        anc3_true_dur = -1.0
        hold_anc_day = -1
        disc_day = -1.0
        last_diar_day = -1.0e9
        pr_run = 0
        pr_best = 0
        anc3_lab_dur = -1.0
        max_level = 0
        cum_oth_red = 0.0
        cum_oth_disc = 0.0
        j_oth = 0
        n_red_ae_other = 0
        disc_ae_other = False
        first_change_day = -1.0
        n_red_pre = 0
        last_dosed = 0                           # level of the last dose actually given
        g2_prev_level = -1                       # schedule mode: dose level at the previous grade-2 hold
        g2_holds_at_level = 0
        n_grade3_anc = 0
        last_anc = base
        last_tox_day = -1.0e9
        last_change_day = 0.0
        r_used = 0
        pre_count = 0
        pre_done = False

        anc3 = anc4 = anc3_detected = False
        diar_steps = 0
        dose_given = 0.0
        dose_slots = 0
        level_day84 = level
        day_conc = 0.0
        pfs_days = float(n_days)
        cfb = 0.0
        end_step = n_steps

        for k in range(n_steps):
            t_h = k * _DT
            day = k // _SPD

            # ---- weekly schedule (P3): planned level of the week, limited by the label-reduction cap
            if sched_mode and k % _SPD == 0 and day % 7 == 0 and not discontinued:
                week = day // 7
                planned = int(theta[T_SCHED + week]) if week < N_SCHED_WEEKS else 3
                level = min(planned, cap)

            # ---- dosing, every 12 hours
            if k % 2 == 0:
                dose_slots += 1
                if level > 0 and not (hold_diar or hold_anc or discontinued):
                    last_dosed = level
                    dose = level * DOSE_PER_LEVEL
                    if level > max_level:
                        max_level = level
                    if tate_pk:
                        f_ss = 1.0 - dose / (pkcon[1] + dose)
                        f_rel = fmult * (f_ss + (1.0 - f_ss) * math.exp(-pkcon[3] * t_h))
                    else:
                        f_rel = fmult * (pkcon[1] + pkcon[2] * dose)
                    a_gut += dose * f_rel
                    dose_given += dose

            # ---- PK, exact over the step; conc = step-average concentration, mg/L
            absorbed = a_gut * gain
            auc = a_cen * int_ke + absorbed * (int_ke - int_ka)
            a_cen = a_cen * e_ke + absorbed * (e_ke - e_ka)
            a_gut *= e_ka
            conc = auc / (_DT * vol)
            day_conc += conc
            cum_exp += auc / vol
            if conc > 0.0 and not discontinued:
                w_oth = conc / c_ref * _DT
                cum_oth_red += oth_red * w_oth * math.exp(-oth_k * t_h)   # reductions: mostly early
                cum_oth_disc += oth_disc * w_oth                          # discontinuation: constant

            # ---- neutrophils, RK4
            eff = slope * conc
            k1 = _friberg(prol, t1, t2, t3, circ, ktr, base, gamma, eff)
            h2 = 0.5 * _DT
            k2 = _friberg(prol + h2 * k1[0], t1 + h2 * k1[1], t2 + h2 * k1[2], t3 + h2 * k1[3],
                          circ + h2 * k1[4], ktr, base, gamma, eff)
            k3 = _friberg(prol + h2 * k2[0], t1 + h2 * k2[1], t2 + h2 * k2[2], t3 + h2 * k2[3],
                          circ + h2 * k2[4], ktr, base, gamma, eff)
            k4 = _friberg(prol + _DT * k3[0], t1 + _DT * k3[1], t2 + _DT * k3[2], t3 + _DT * k3[3],
                          circ + _DT * k3[4], ktr, base, gamma, eff)
            w = _DT / 6.0
            prol += w * (k1[0] + 2.0 * k2[0] + 2.0 * k3[0] + k4[0])
            t1 += w * (k1[1] + 2.0 * k2[1] + 2.0 * k3[1] + k4[1])
            t2 += w * (k1[2] + 2.0 * k2[2] + 2.0 * k3[2] + k4[2])
            t3 += w * (k1[3] + 2.0 * k2[3] + 2.0 * k3[3] + k4[3])
            circ += w * (k1[4] + 2.0 * k2[4] + 2.0 * k3[4] + k4[4])
            if prol < 0.0:
                prol = 0.0
            if circ < 1.0:
                anc3 = True
                if anc3_true_start < 0:
                    anc3_true_start = k
                if circ < 0.5:
                    anc4 = True
            elif anc3_true_start >= 0 and anc3_true_dur < 0.0:
                anc3_true_dur = (k - anc3_true_start) / _SPD

            # ---- diarrhoea grade chain
            prev_grade = grade
            u = u_diar[i, k]
            p_up = 0.0
            if grade < 3 and conc > 0.0:
                if tol_exposure:
                    tol = math.exp(-kc * cum_exp)
                else:
                    tol = math.exp(-kh * t_h)
                rate = dcon[grade] * dmult * tol * (conc / c_ref) ** beta
                p_up = 1.0 - math.exp(-rate * _DT)
            p_down = 0.0
            if grade > 0:
                p_down = 1.0 - math.exp(-dcon[2 + grade] * _DT)
            if u < p_up:
                grade += 1
            elif u < p_up + p_down:
                grade -= 1
            if grade >= 2 and day < DIARRHOEA_WINDOW_DAYS:
                diar_steps += 1
            if grade > max_grade:
                max_grade = grade
                if onset_day < 0.0:
                    onset_day = t_h / 24.0

            # ---- tumour size and progression hazard, every step (RK4, step-average concentration)
            c_step = conc / _MW                      # umol/L
            t_mid = (k + 0.5) * _DT / 168.0          # week, middle of the step
            if measurable:
                decay = 1.0
                if t_mid > delay:
                    decay = math.exp(-resist * (t_mid - delay))
                ks = (e_et + e_abe * c_step) * decay
                hw = _DT / 168.0
                q1 = _tumour(th, td1, td2, td3, kgrow, ks, ktrans)
                q2 = _tumour(th + 0.5 * hw * q1[0], td1 + 0.5 * hw * q1[1], td2 + 0.5 * hw * q1[2],
                             td3 + 0.5 * hw * q1[3], kgrow, ks, ktrans)
                q3 = _tumour(th + 0.5 * hw * q2[0], td1 + 0.5 * hw * q2[1], td2 + 0.5 * hw * q2[2],
                             td3 + 0.5 * hw * q2[3], kgrow, ks, ktrans)
                q4 = _tumour(th + hw * q3[0], td1 + hw * q3[1], td2 + hw * q3[2],
                             td3 + hw * q3[3], kgrow, ks, ktrans)
                th += hw / 6.0 * (q1[0] + 2.0 * q2[0] + 2.0 * q3[0] + q4[0])
                td1 += hw / 6.0 * (q1[1] + 2.0 * q2[1] + 2.0 * q3[1] + q4[1])
                td2 += hw / 6.0 * (q1[2] + 2.0 * q2[2] + 2.0 * q3[2] + q4[2])
                td3 += hw / 6.0 * (q1[3] + 2.0 * q2[3] + 2.0 * q3[3] + q4[3])
                cfb = th + td1 + td2 + td3 - s0
            hazard = hz_base * math.exp(hz_cfb * cfb - hz_conc * c_step * math.exp(-hz_decay * t_mid))
            cum_hazard += hazard * _DT / 168.0

            # ---- once a day: response run, landmarks, trace, progression check
            if k % _SPD == _SPD - 1:
                c_um = day_conc / _SPD / _MW
                day_conc = 0.0
                if measurable:
                    if th + td1 + td2 + td3 <= 0.7 * s0:
                        pr_run += 1
                        if pr_run > pr_best:
                            pr_best = pr_run
                    else:
                        pr_run = 0
                if day + 1 == 84:
                    level_day84 = 0 if discontinued else level
                if want_trace and i == 0:
                    trace[day, TR_CONC] = c_um * _MW
                    trace[day, TR_ANC] = circ
                    trace[day, TR_TUMOUR] = s0 + cfb
                    trace[day, TR_LEVEL] = level
                    trace[day, TR_GRADE] = grade
                    trace[day, TR_ON_HOLD] = hold_diar or hold_anc or discontinued
                if cum_hazard >= hazard_threshold[i]:
                    pfs_days = day + 1.0
                    end_step = k + 1
                    break

            # ---- label rules and policy, acting on the next dose
            if discontinued:
                continue
            if cum_oth_disc > pop[i, C_OTH_DISC]:
                discontinued = True
                disc_ae_other = True
                disc_day = day
                if first_change_day < 0.0:
                    first_change_day = day
                level = 0
                continue
            if j_oth < 4 and cum_oth_red > pop[i, C_OTH_RED1 + j_oth]:
                j_oth += 1
                # weekly schedule: reduce from the dose that was being given (a hold may cross into a week
                # with another planned dose, or into a holiday)
                ref = (min(last_dosed, cap) if last_dosed > 0 else cap) if sched_mode else level
                if reduce_on_resume:
                    pass                                 # a label reduction is pending: one reduction serves both
                elif ref <= 1:
                    discontinued = True                  # not tolerated at 50 mg
                    disc_day = day
                    if first_change_day < 0.0:
                        first_change_day = day
                    level = 0
                    continue
                else:
                    n_red_ae_other += 1
                    cap = ref - 1
                    level = min(level, cap)
                    g2_holds_at_level = 0
                    last_change_day = day
                    if first_change_day < 0.0:
                        first_change_day = day
            if grade >= 2:
                last_tox_day = day
                last_diar_day = day
                if prev_grade < 2 and day < PREVENTIVE_WINDOW_DAYS:
                    pre_count += 1
            if grade >= 3:
                hold_diar = True
                held_diar = True
                reduce_on_resume = True
                reason_diar = True
            elif grade == 2:
                g2_steps += 1
                if g2_strict and g2_steps >= _SPD and not hold_diar:   # not back to grade 1 within 24 h
                    hold_diar = True
                    held_diar = True
                    # persists or recurs at the same dose. Schedule mode: compare the dose actually given at
                    # this hold and at the previous one (the planned level changes from week to week).
                    if sched_mode:
                        recur = g2_prev_level == last_dosed
                        g2_prev_level = last_dosed
                    else:
                        recur = g2_holds_at_level >= 1
                    if recur:
                        reduce_on_resume = True
                        reason_diar = True
                    g2_holds_at_level += 1
            else:
                g2_steps = 0
                hold_diar = False

            recheck = hold_anc and day > hold_anc_day and (day - hold_anc_day) % HOLD_RECHECK_DAYS == 0
            if k % _SPD == 0 and (is_cbc[day] or recheck):
                was_holding = hold_anc
                if anc3_detected and anc3_lab_dur < 0.0 and circ >= 1.0:
                    anc3_lab_dur = day - first_anc3_day
                last_anc = circ
                if circ < 1.5:                       # grade >= 2 neutropenia restarts the re-escalation clock
                    last_tox_day = day
                if circ < 1.0:
                    if not anc3_detected:
                        first_anc3_day = day
                    anc3_detected = True
                if circ < 0.5:
                    if not was_holding:
                        hold_anc_day = day
                    hold_anc = True
                    reduce_on_resume = True
                    reason_anc = True
                    anc4_detected = True
                    held_anc = True
                elif circ < 1.0 and (anc3_strict or hold_anc):
                    held_anc = True
                    if not hold_anc:
                        n_grade3_anc += 1
                        if n_grade3_anc >= 2:            # recurrent grade 3
                            reduce_on_resume = True
                            reason_anc = True
                    if not was_holding:
                        hold_anc_day = day
                    hold_anc = True
                else:
                    hold_anc = False

            if day >= force_day and level > force_level:
                level = force_level
                cap = force_level
                n_red_other += 1
                g2_holds_at_level = 0
                last_change_day = day
                reduce_on_resume = False                 # resuming at the mandated dose serves a pending reduction
                reason_diar = False
                reason_anc = False
                if first_change_day < 0.0:
                    first_change_day = day
            if hold_diar or hold_anc:
                continue
            if reduce_on_resume:
                reduce_on_resume = False
                by_diar, by_anc = reason_diar, reason_anc
                reason_diar = False
                reason_anc = False
                if first_change_day < 0.0:
                    first_change_day = day
                ref = (min(last_dosed, cap) if last_dosed > 0 else cap) if sched_mode else level
                if ref <= 1:
                    discontinued = True                  # not tolerated at 50 mg: discontinuation, not a reduction
                    disc_day = day
                    level = 0
                    continue
                if by_diar:
                    n_red_diar += 1
                elif by_anc:
                    n_red_anc += 1
                cap = ref - 1
                level = min(level, cap)
                g2_holds_at_level = 0
                last_change_day = day
                if n_pre > 0 and pre_count >= n_pre:
                    pre_done = True                      # the label reduction already lowered the dose
            if sched_mode:
                continue                                 # no adaptive policy rules on a fixed schedule
            if (n_pre > 0 and not pre_done and day < PREVENTIVE_WINDOW_DAYS and pre_count >= n_pre
                    and grade < 2):                       # applied once the episode is back to grade <= 1
                # Preventive reduction: the dose plan goes down one level. The ceiling drops by one level
                # (not below 50 mg) and the current dose is limited by it; at 50 mg, or while still
                # escalating below the new ceiling, the current dose is unchanged and escalation goes on.
                pre_done = True
                cap = max(1, cap - 1)
                if level > cap:
                    level = cap
                    n_red_pre += 1
                    g2_holds_at_level = 0
                    last_change_day = day
                    if first_change_day < 0.0:
                        first_change_day = day
            if (cap < target_level and r_used < r_max and day - last_tox_day >= re_days
                    and day - last_change_day >= re_days):
                cap += 1
                r_used += 1
            if (level < cap and day - last_change_day >= esc_days and last_anc >= anc_min
                    and day - last_diar_day >= diar_free_days):
                level += 1
                g2_holds_at_level = 0
                last_change_day = day

        out[i, O_PFS_DAYS] = pfs_days
        out[i, O_ANC3] = anc3
        out[i, O_ANC4] = anc4
        out[i, O_ANC3_DETECTED] = anc3_detected
        out[i, O_DIAR_DAYS_6M] = diar_steps / _SPD
        out[i, O_RDI] = dose_given / (dose_slots * REFERENCE_DOSE)
        out[i, O_DISCONTINUED] = discontinued
        out[i, O_LEVEL_DAY84] = level_day84
        out[i, O_ANC4_DETECTED] = anc4_detected
        out[i, O_FIRST_ANC3_DAY] = first_anc3_day
        out[i, O_MAX_DIAR] = max_grade
        out[i, O_DIAR_ONSET_DAY] = onset_day
        out[i, O_HELD_DIAR] = held_diar
        out[i, O_HELD_ANC] = held_anc
        out[i, O_N_RED_DIAR] = n_red_diar
        out[i, O_N_RED_ANC] = n_red_anc
        out[i, O_N_RED_OTHER] = n_red_other
        if anc3_true_start >= 0:
            out[i, O_ANC3_ONSET_TRUE] = anc3_true_start / _SPD
            out[i, O_ANC3_DUR_TRUE] = anc3_true_dur if anc3_true_dur >= 0.0 else (end_step - anc3_true_start) / _SPD
        else:
            out[i, O_ANC3_ONSET_TRUE] = -1.0
            out[i, O_ANC3_DUR_TRUE] = -1.0
        out[i, O_DAYS_6M] = min(pfs_days, float(DIARRHOEA_WINDOW_DAYS))
        out[i, O_DISC_DAY] = disc_day
        out[i, O_PR_DAYS] = pr_best
        out[i, O_ANC3_DUR_LAB] = anc3_lab_dur
        out[i, O_MAX_LEVEL] = max_level
        out[i, O_N_RED_AE_OTHER] = n_red_ae_other
        out[i, O_DISC_AE_OTHER] = disc_ae_other
        out[i, O_FIRST_CHANGE_DAY] = first_change_day
        out[i, O_N_RED] = n_red_diar + n_red_anc + n_red_other + n_red_ae_other + n_red_pre


def standard_policy():
    """150 mg twice daily with label rules only."""
    theta = np.zeros(N_THETA)
    theta[T_START_LEVEL] = 3
    theta[T_TARGET_LEVEL] = 3
    theta[T_ESC_DAYS] = 14
    theta[T_ANC_MIN] = 1.0
    theta[T_RE_DAYS] = 28
    return theta


NO_TRACE = np.zeros((0, N_TRACE))


def objectives(out):
    """f1 = -RMST in months, f2 = P(true grade >= 3 neutropenia), f3 = mean days of grade >= 2 diarrhoea in 6 months."""
    f1 = -float(np.mean(out[:, O_PFS_DAYS])) / P.DAYS_PER_MONTH
    f2 = float(np.mean(out[:, O_ANC3]))
    f3 = float(np.mean(out[:, O_DIAR_DAYS_6M]))
    return f1, f2, f3
