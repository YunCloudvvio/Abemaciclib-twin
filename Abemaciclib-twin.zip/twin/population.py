"""Virtual patients and the fixed random numbers of one SAA batch."""
import math

import numpy as np

from . import params as P

# Column indices of the patient matrix.
(C_KA, C_KE, C_V, C_FMULT,
 C_ANC_BASE, C_KTR, C_GAMMA, C_SLOPE,
 C_MEAS, C_S0, C_KGROW, C_KTRANS, C_E_ET, C_E_ABE, C_RESIST, C_DELAY,
 C_HZ_BASE, C_HZ_CFB, C_HZ_CONC, C_HZ_DECAY,
 C_DI_MULT, C_START_LEVEL, C_FORCE_DAY, C_FORCE_LEVEL, C_G2_STRICT, C_ANC3_STRICT,
 C_OTH_RED1, C_OTH_RED2, C_OTH_RED3, C_OTH_RED4, C_OTH_DISC,
 N_COLS) = range(32)
# C_OTH_RED1..4: cumulative unit-exponential thresholds of the 1st..4th dose reduction for
# other adverse reactions; C_OTH_DISC: threshold of discontinuation for other adverse reactions.

PK_CHIGUTSA = "chigutsa"   # main analysis
PK_TATE = "tate"           # sensitivity scenario


def _omega(cv):
    return math.sqrt(math.log(1.0 + cv * cv))


def _lognormal(rng, typical, cv, n):
    return typical * np.exp(_omega(cv) * rng.standard_normal(n))


def _truncated_lognormal(rng, typical, cv, lower, n):
    """Lognormal truncated below at `lower` (eligibility), by inverse-CDF mapping of the same
    standard normal draws, so the random stream is unchanged."""
    from scipy.stats import norm
    omega = _omega(cv)
    z = rng.standard_normal(n)
    a = norm.cdf(math.log(lower / typical) / omega)
    zt = norm.ppf(a + norm.cdf(z) * (1.0 - a))
    return typical * np.exp(omega * zt)


def _nearest_correlation(corr):
    """Clip negative eigenvalues; the published matrix is rounded and may not be PD."""
    w, v = np.linalg.eigh(np.asarray(corr, dtype=float))
    fixed = (v * np.clip(w, 1e-6, None)) @ v.T
    d = np.sqrt(np.diag(fixed))
    return fixed / np.outer(d, d)


def _correlated_lognormal(rng, typical, cv, corr, n):
    omega = np.array([_omega(c) for c in cv])
    chol = np.linalg.cholesky(_nearest_correlation(corr))
    eta = rng.standard_normal((n, len(cv))) @ chol.T
    return np.asarray(typical) * np.exp(eta * omega)


def pk_constants(pk_model=PK_CHIGUTSA):
    """[mode, a, b, lambda]. mode 0: F = a + b * dose. mode 1: Tate 2017."""
    if pk_model == PK_TATE:
        return np.array([1.0, P.TATE_D50, 0.0, P.TATE_LAMBDA_F])
    return np.array([0.0, P.PK_F_INTERCEPT, P.PK_F_SLOPE, 0.0])


def sample_patients(n, seed, e_endocrine=P.TS_E_FULV, pk_model=PK_CHIGUTSA, control_arm=False,
                    frac_measurable=P.FRAC_MEASURABLE, frac_ecog1=P.FRAC_ECOG1, frac_hepatic=P.FRAC_HEPATIC):
    """Draw n virtual patients (MONARCH 2-like population by default).

    control_arm=True uses the drug-effect half-life estimated for the
    fulvestrant-alone arm. The covariate fractions do not change the random
    stream, so the same seed gives the same draws for every population.
    """
    rng = np.random.default_rng(seed)
    pop = np.empty((n, N_COLS))

    ka = _lognormal(rng, P.PK_KA, P.PK_CV_KA, n)
    if pk_model == PK_TATE:
        ke = _lognormal(rng, P.TATE_CL, P.TATE_CV_CL, n) / P.TATE_V
        pop[:, C_V] = P.TATE_V
        pop[:, C_FMULT] = _lognormal(rng, 1.0, P.TATE_CV_F, n)
    else:
        ke = _lognormal(rng, P.PK_CL, P.PK_CV_CL, n) / P.PK_V
        pop[:, C_V] = P.PK_V
        rng.standard_normal(n)  # keep the random stream aligned between PK models
        pop[:, C_FMULT] = 1.0
    close = np.abs(ka - ke) < 1e-4   # the closed-form PK step needs ka != ke
    ka[close] = ke[close] + 1e-4
    pop[:, C_KA] = ka
    pop[:, C_KE] = ke

    pop[:, C_ANC_BASE] = _truncated_lognormal(rng, P.ANC_BASE, P.ANC_CV_BASE, P.ANC_MIN_ELIGIBLE, n)
    pop[:, C_KTR] = 4.0 / _lognormal(rng, P.ANC_MTT_H, P.ANC_CV_MTT, n)
    pop[:, C_GAMMA] = P.ANC_GAMMA
    pop[:, C_SLOPE] = _lognormal(rng, P.ANC_SLOPE, P.ANC_CV_SLOPE, n)

    meas = rng.random(n) < frac_measurable
    pop[:, C_MEAS] = meas
    size = _correlated_lognormal(rng, (P.TS_BASE, P.TS_KGROW), (P.TS_CV_BASE, P.TS_CV_KGROW),
                                 ((1.0, P.TS_CORR_BASE_KGROW), (P.TS_CORR_BASE_KGROW, 1.0)), n)
    pop[:, C_S0] = size[:, 0]
    pop[:, C_KGROW] = size[:, 1]
    pop[:, C_KTRANS] = _lognormal(rng, P.TS_KTRANS, P.TS_CV_KTRANS, n)
    drug = _correlated_lognormal(
        rng,
        (e_endocrine, P.TS_E_ABE, P.TS_THALF_CTRL_ARM, P.TS_THALF_ABE_ARM, P.TS_T_DELAY),
        (P.TS_CV_E_FULV, P.TS_CV_E_ABE, P.TS_CV_THALF_CTRL, P.TS_CV_THALF_ABE, P.TS_CV_DELAY),
        P.TS_CORR_DRUG, n)
    pop[:, C_E_ET] = drug[:, 0]
    pop[:, C_E_ABE] = drug[:, 1]
    pop[:, C_RESIST] = math.log(2.0) / (drug[:, 2] if control_arm else drug[:, 3])
    pop[:, C_DELAY] = drug[:, 4]

    cov = np.where(rng.random(n) < frac_hepatic, 1.0 + P.HZ_HEPATIC, 1.0)
    cov *= np.where(rng.random(n) < frac_ecog1, 1.0 + P.HZ_ECOG1, 1.0)
    high = rng.random(n) < P.HZ_FRAC_HIGH
    pop[:, C_HZ_BASE] = np.where(meas, P.HZ_BASE_MEAS, P.HZ_BASE_NONMEAS) * cov
    pop[:, C_HZ_CFB] = np.where(meas, P.HZ_CFB * np.where(high, P.HZ_CFB_HIGH_FACTOR, 1.0), 0.0)
    pop[:, C_HZ_CONC] = P.HZ_CONC
    pop[:, C_HZ_DECAY] = np.where(meas, math.log(2.0) / P.HZ_THALF_CONC, 0.0)

    pop[:, C_DI_MULT] = _lognormal(rng, 1.0, P.DI_CV_Q, n)
    pop[:, C_START_LEVEL] = 0.0       # 0: the policy decides the starting dose
    pop[:, C_FORCE_DAY] = np.inf      # no protocol-mandated reduction
    pop[:, C_FORCE_LEVEL] = 0.0
    # Dose-rule adherence (see params): uniform draws, thresholded when parameters are applied.
    pop[:, C_G2_STRICT] = rng.random(n) < P.RULE_G2_DIARRHOEA_FRAC
    pop[:, C_ANC3_STRICT] = rng.random(n) < P.RULE_G3_NEUTROPENIA_FRAC
    # Other adverse reactions: a separate stream, so the draws above do not change.
    rng_other = np.random.default_rng([seed, 17])
    pop[:, C_OTH_RED1:C_OTH_RED4 + 1] = np.cumsum(rng_other.exponential(1.0, (n, 4)), axis=1)
    pop[:, C_OTH_DISC] = rng_other.exponential(1.0, n)
    return pop


def sample_noise(n, n_days, seed):
    """Random numbers fixed for a whole optimisation run (SAA)."""
    rng = np.random.default_rng(seed)
    hazard_threshold = -np.log(rng.random(n))
    u_diarrhoea = rng.random((n, n_days * P.STEPS_PER_DAY), dtype=np.float32)
    return hazard_threshold, u_diarrhoea


def cbc_schedule(n_days):
    """Blood-count days per the label: baseline, every 2 weeks for 2 months,
    monthly for 2 months, then every 12 weeks (the last part is an assumption)."""
    is_cbc = np.zeros(n_days + 1, dtype=np.bool_)
    for d in (0, 14, 28, 42, 56, 84, 112):
        if d <= n_days:
            is_cbc[d] = True
    is_cbc[np.arange(196, n_days + 1, 84)] = True
    return is_cbc


def diarrhoea_constants():
    """[q01, q12, q23 per hour, r10, r21, r32 per hour, kh per hour, beta, c_ref,
    tolerance structure (0 time, 1 cumulative exposure), kc per mg.h/L,
    other adverse reactions: reduction rate, discontinuation rate, decline rate (per hour)]."""
    up = [q / 24.0 for q in P.DI_Q_UP_PER_DAY]
    down = [math.log(2.0) / (d * 24.0) for d in P.DI_MEDIAN_DAYS]
    return np.array(up + down + [P.DI_KH_PER_DAY / 24.0, P.DI_BETA, P.DI_C_REF,
                                 float(P.DI_TOLERANCE), P.DI_KC,
                                 P.OTH_RED_PER_DAY / 24.0, P.OTH_DISC_PER_DAY / 24.0, P.OTH_K_PER_DAY / 24.0])
