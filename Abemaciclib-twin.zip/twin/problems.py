"""Optimisation problem instances on the twin.

An instance fixes, for one optimisation run (sample average approximation, SAA), a batch
of virtual patients drawn from the twin ensemble (n_per_member patients from each of the M
ensemble members), their random numbers and the blood-count schedule. Objectives and
constraints are then deterministic functions of the policy vector theta.

Instances: P1 first line, aromatase inhibitor partner (MONARCH 3 population, stage-3 parameters); P2 second line,
fulvestrant partner (MONARCH 2 population, Chigutsa 2026 parameters as published); P4 as P1 with
f1 = -CVaR_0.2, the mean 24-month-capped PFS of the worst 20% of the virtual patients;
P3 as P1 with a fixed weekly schedule: 24 integer variables, the dose level of weeks 1-24
(0 = drug holiday, 1-3 = 50/100/150 mg twice daily); afterwards 150 mg. The label rules withhold
and reduce throughout; a reduction lowers the cap of every later week.

Decision vector of P1/P2/P4 (8 variables, PlatEMO encoding in brackets: 1 real, 2 integer):
  d0 start level 1-3 [2], d_tgt target level 2-3 [2], tau_esc 7-28 d [2], theta_ANC 1.0-2.0 [1],
  w_diar 0-14 d [2], n_pre 0-3 [2] (0 = off), tau_re 28-84 d [2], r_max 0-2 [2] (0 = not allowed).
Objectives (minimised): f1 = -RMST(24 months) in months, f2 = P(true grade >= 3 neutropenia),
  f3 = mean days with grade >= 2 diarrhoea in the first 6 months.
Constraints (<= 0 feasible): 0.6 - median RDI; P(true grade 4 neutropenia) - standard;
  P(discontinuation) - standard, the standard policy evaluated on the same patients and random numbers.
"""
import json

import numpy as np

from . import kernel as K
from . import params as P
from . import population as pm
from . import scenarios as SC
from . import trials as T

LOWER = np.array([1, 2, 7, 1.0, 0, 0, 28, 0], dtype=float)
UPPER = np.array([3, 3, 28, 2.0, 14, 3, 84, 2], dtype=float)
ENCODING = np.array([2, 2, 2, 1, 2, 2, 2, 2])
N_OBJ = 3
N_CON = 3
RDI_MIN = 0.6
CVAR_ALPHA = 0.2
INSTANCES = ("P1", "P2", "P3", "P4")
P3_LOWER = np.zeros(K.N_SCHED_WEEKS)
P3_UPPER = np.full(K.N_SCHED_WEEKS, 3.0)


def bounds(name):
    """(lower, upper, encoding) of the decision vector of an instance."""
    if name == "P3":
        return P3_LOWER, P3_UPPER, np.full(K.N_SCHED_WEEKS, 2)
    return LOWER, UPPER, ENCODING


def decode_schedule(x):
    theta = np.zeros(K.N_THETA)
    theta[K.T_MODE] = 1
    theta[K.T_SCHED:K.T_SCHED + K.N_SCHED_WEEKS] = np.round(np.clip(np.asarray(x, dtype=float), 0, 3))
    return theta


def decode(x):
    """Decision vector (PlatEMO order) -> kernel policy vector."""
    x = np.clip(np.asarray(x, dtype=float), LOWER, UPPER)
    theta = np.zeros(K.N_THETA)
    theta[K.T_START_LEVEL] = round(x[0])
    theta[K.T_TARGET_LEVEL] = round(x[1])
    theta[K.T_ESC_DAYS] = round(x[2])
    theta[K.T_ANC_MIN] = x[3]
    theta[K.T_DIAR_FREE_DAYS] = round(x[4])
    theta[K.T_N_PRE] = round(x[5])
    theta[K.T_RE_DAYS] = round(x[6])
    theta[K.T_R_MAX] = round(x[7])
    return theta


def cvar_months(pfs_days, alpha=CVAR_ALPHA):
    """Mean PFS (months) of the worst alpha fraction of patients (lowest PFS)."""
    k = max(1, int(round(alpha * pfs_days.size)))
    return float(np.mean(np.sort(pfs_days)[:k])) / P.DAYS_PER_MONTH


class Instance:
    """One SAA instance of P1, P2 or P4 (see the module docstring)."""

    def __init__(self, ensemble_file, stage3_file, seed, n_per_member=10, n_days=T.N_DAYS, name="P1", scenario=None):
        if name not in INSTANCES:
            raise ValueError(f"instance {name} not implemented")
        self.name = name
        # E4 scenario (twin/scenarios.py): from TWIN_SCENARIO unless given; "base" changes nothing
        if scenario is None:
            self.scenario, sc = SC.current()
        else:
            self.scenario, sc = scenario, dict(SC.SCENARIOS[scenario])
        if set(sc) - SC.KEYS:
            raise ValueError(f"unknown scenario keys {set(sc) - SC.KEYS}")
        if "months" in sc:
            n_days = SC.window_days(sc["months"])
        self.rdi_min = sc.get("rdi_min", RDI_MIN)
        import calibrate_stage12 as C          # scripts/ must be on sys.path
        with open(ensemble_file, encoding="utf-8") as f:
            ens = json.load(f)
        with open(stage3_file, encoding="utf-8") as f:
            s3 = json.load(f)["parameters"]
        structure = C.STRUCTURE[ens["structure"]]
        self.n_days = n_days
        self.cbc = pm.cbc_schedule(n_days)
        self.pkcon = pm.pk_constants()
        self.groups = []
        for j, member in enumerate(ens["members"]):
            par = dict(member["parameters"])
            if "tol_mult" in sc:
                par["tolerance"] *= sc["tol_mult"]
            if "anc_mult" in sc:
                par["anc_slope"] *= sc["anc_mult"]
            n = n_per_member
            if name == "P2":
                pop = pm.sample_patients(n, seed * 1000 + j)          # MONARCH 2 covariates, fulvestrant
            else:
                pop = T.monarch3_population(n, seed * 1000 + j, e_ai=s3["e_ai"], hazard_mult=s3["hazard_mult"])
            pop[:, pm.C_START_LEVEL] = 0.0
            pop = C.apply_parameters(pop, par)
            if "e_abe" in sc:
                pop[:, pm.C_E_ABE] *= sc["e_abe"] / P.TS_E_ABE
            if "hz_conc" in sc:
                pop[:, pm.C_HZ_CONC] = sc["hz_conc"]
            rng = np.random.default_rng([seed, j, 2])
            pop[:, pm.C_G2_STRICT] = rng.random(n) < par["g2_rule_frac"]
            pop[:, pm.C_ANC3_STRICT] = rng.random(n) < par["anc3_rule_frac"]
            # Random numbers are always drawn for the main 24-month window, so that a different window (E4)
            # keeps every patient's numbers of the common days: shorter windows use the first days, longer
            # windows append an independent stream for the extra days.
            thr, u = pm.sample_noise(n, T.N_DAYS, seed * 1000 + j + 500)
            if n_days < T.N_DAYS:
                u = np.ascontiguousarray(u[:, :n_days * P.STEPS_PER_DAY])
            elif n_days > T.N_DAYS:
                _, extra = pm.sample_noise(n, n_days - T.N_DAYS, [seed, j, 501])
                u = np.ascontiguousarray(np.concatenate([u, extra], axis=1))
            self.groups.append((pop, thr, u, C.toxicity_constants(par, structure)))
        self.n = sum(g[0].shape[0] for g in self.groups)
        self.std = self._summary(K.standard_policy())

    def _simulate(self, theta):
        outs = []
        for pop, thr, u, dcon in self.groups:
            out = np.zeros((pop.shape[0], K.N_OUT))
            K.simulate(theta, pop, thr, u, self.cbc, dcon, self.pkcon, self.n_days, out, K.NO_TRACE)
            outs.append(out)
        return np.concatenate(outs)

    def _summary(self, theta):
        out = self._simulate(theta)
        f1, f2, f3 = K.objectives(out)
        if self.name == "P4":
            f1 = -cvar_months(out[:, K.O_PFS_DAYS])
        return {"f": (f1, f2, f3), "rdi": float(np.median(out[:, K.O_RDI])),
                "anc4": float(np.mean(out[:, K.O_ANC4] > 0)), "disc": float(np.mean(out[:, K.O_DISCONTINUED] > 0))}

    def evaluate(self, X):
        X = np.atleast_2d(X)
        F = np.empty((X.shape[0], N_OBJ))
        G = np.empty((X.shape[0], N_CON))
        dec = decode_schedule if self.name == "P3" else decode
        for i, x in enumerate(X):
            s = self._summary(dec(x))
            F[i] = s["f"]
            G[i] = (self.rdi_min - s["rdi"], s["anc4"] - self.std["anc4"], s["disc"] - self.std["disc"])
        return F, G
