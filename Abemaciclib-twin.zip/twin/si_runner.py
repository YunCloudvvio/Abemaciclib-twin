"""Run one MOSI algorithm (Python ports in mosi/codes) on a twin problem.

The algorithms come from `mosi/codes/<ID>_<Name>/impl.py`
(Python ports of the original authors' MATLAB code, see mosi/SOURCES.md) and are used unchanged through the `sicore` runner:
`optimize(problem, pop_size, rng, max_iter=None, ...)`, one evaluation per `problem(x)` call, budget
enforced by `sicore.problem.MOProblem.max_fes`.

Uniform handling of what the ports do not have:
* integer variables: x is clipped to the bounds and integer entries are rounded before evaluation
  (as PlatEMO's CalDec does for the MOEAs);
* constraints: the algorithms see F' = F for feasible solutions and F' = U + CV (CV = sum(max(0, g))
  added to every component) for infeasible ones, U being the upper bounds of the objectives
  (f1 = -RMST or -CVaR <= 0, f2 <= 1, f3 <= 182 days). Every feasible solution then strictly dominates
  every infeasible one, and infeasible solutions are ordered by their violation only: exactly Deb's
  constraint-domination rule expressed through Pareto dominance.
The output is the algorithm's last reported set, decoded (integers rounded), with duplicate policies
removed (the archives keep continuous coordinates, so several entries can map to one policy), stored
with the true objectives and constraints. Checkpoints: the reported set at the first report after
every max_fes / n_ckpt evaluations (as PlatEMO's 'save' option), stored row-wise as ckpt_X / ckpt_F /
ckpt_G with ckpt_id (checkpoint index of each row) and ckpt_fe (evaluations at each checkpoint).
Checkpoints an algorithm never reaches (it may stop short of the budget) repeat its final set.

Run from the project root:
  python -m twin.si_runner --alg M001_MOGWO --instance P1 --seed 1 --max-fes 10000 --out run.npz
"""
import argparse
import importlib.util
import inspect
import os
import sys
import time

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SI_ROOT = os.environ.get("MOSI_ROOT", os.path.join(ROOT, "mosi"))
SI_CODES = os.path.join(SI_ROOT, "codes")
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, ROOT)
sys.path.insert(1, SI_ROOT)

from sicore.problem import MOProblem, run_mo  # noqa: E402

from twin import problems  # noqa: E402

OBJ_UPPER = np.array([0.0, 1.0, 182.0])     # upper bounds of f1, f2, f3 (see problems.py)
MOSI = ["M001_MOGWO", "M004_MSSA", "M014_MOAVOA", "M103_MOCGO", "M105_MOEOSMA", "M212_MOGNDO",
        "M231_MORIME", "M306_MaOMPA", "M315_MOSRS", "M323_C-MOBRO"]


def load_algorithm(alg_dir):
    path = os.path.join(SI_CODES, alg_dir, "impl.py")
    spec = importlib.util.spec_from_file_location(f"mosi_{alg_dir.replace('-', '_')}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.optimize


def constrained_objectives(F, G):
    """Objectives seen by an unconstrained MOSI algorithm (Deb's rule through dominance)."""
    cv = float(np.sum(np.maximum(G, 0.0)))
    return np.array(F, dtype=float) if cv == 0.0 else OBJ_UPPER + cv


def unique_rows_first(X):
    """Rows of X without repeats, in order of first occurrence."""
    seen, keep = set(), []
    for j, x in enumerate(X):
        key = x.tobytes()
        if key not in seen:
            seen.add(key)
            keep.append(j)
    return X[keep]


class TwinMO:
    """Penalised objective function for the sicore wrapper, with a cache of the true values."""

    def __init__(self, inst):
        self.inst = inst
        self.lower, self.upper, enc = problems.bounds(inst.name)
        self.integer = enc == 2
        self.cache = {}

    def decode(self, x):
        x = np.clip(np.asarray(x, dtype=float), self.lower, self.upper)
        x[self.integer] = np.round(x[self.integer])
        return x

    def __call__(self, x):
        x = self.decode(x)
        key = x.tobytes()
        if key not in self.cache:
            F, G = self.inst.evaluate(x)
            self.cache[key] = (F[0], G[0])
        F, G = self.cache[key]
        return constrained_objectives(F, G)


class CheckpointProblem(MOProblem):
    """sicore MOProblem that also keeps the reported set at evaluation checkpoints."""

    def __init__(self, *args, n_ckpt=20, **kwargs):
        super().__init__(*args, **kwargs)
        self.n_ckpt = n_ckpt
        self.ckpts = []                                # (evaluations, reported X)

    def report(self, X, F):
        super().report(X, F)
        while (len(self.ckpts) < self.n_ckpt
               and self.fes >= (len(self.ckpts) + 1) * self.max_fes / self.n_ckpt):
            self.ckpts.append((self.fes, np.array(X, dtype=float, copy=True)))


def true_values(f, inst, X):
    """Decoded unique rows of X with their true objectives and constraints (from the cache)."""
    X = unique_rows_first(np.array([f.decode(x) for x in X])) if len(X) else np.zeros((0, len(f.lower)))
    F = np.zeros((len(X), problems.N_OBJ))
    G = np.zeros((len(X), problems.N_CON))
    missing = 0
    for j, x in enumerate(X):
        hit = f.cache.get(x.tobytes())
        if hit is None:                               # reported but never evaluated (should not happen)
            missing += 1
            Fx, Gx = inst.evaluate(x)
            hit = (Fx[0], Gx[0])
        F[j], G[j] = hit
    return X, F, G, missing


def run(alg_dir, inst, seed, max_fes, pop_size=100, n_ckpt=20):
    optimize = load_algorithm(alg_dir)
    f = TwinMO(inst)
    prob = CheckpointProblem(f, f.lower, f.upper, problems.N_OBJ, max_fes=max_fes, n_ckpt=n_ckpt)
    params = {}                                       # pop_size = 100 for every algorithm (MOSRS: 1000, C-MOBRO: 80 by default)
    sig = inspect.signature(optimize)
    if "archive_size" in sig.parameters and sig.parameters["archive_size"].default is not None:
        params["archive_size"] = 100
    t0 = time.perf_counter()
    res = run_mo(optimize, prob, seed, pop_size=pop_size, **params)
    runtime = time.perf_counter() - t0
    final = res["X"] if res["X"] is not None else np.zeros((0, len(f.lower)))
    n_reported = len(final)
    X, F, G, missing = true_values(f, inst, final)
    ckpts = list(prob.ckpts)
    while len(ckpts) < n_ckpt:                         # algorithm stopped before the budget was used up
        ckpts.append((res["fes"], np.array(final, dtype=float)))
    cX, cF, cG, cid = [], [], [], []
    for i, (_, Xi) in enumerate(ckpts):
        Xi, Fi, Gi, mi = true_values(f, inst, Xi)
        missing += mi
        cX.append(Xi), cF.append(Fi), cG.append(Gi), cid.append(np.full(len(Xi), i))
    return {"X": X, "F": F, "G": G, "fes": res["fes"], "runtime": runtime, "missing": missing,
            "n_reported": n_reported,
            "ckpt_X": np.concatenate(cX), "ckpt_F": np.concatenate(cF), "ckpt_G": np.concatenate(cG),
            "ckpt_id": np.concatenate(cid).astype(int), "ckpt_fe": np.array([c[0] for c in ckpts]),
            "nonfinite": res["nonfinite"], "n_unique": len(f.cache)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alg", required=True, choices=MOSI)
    ap.add_argument("--instance", default="P1", choices=problems.INSTANCES)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--max-fes", type=int, default=10000)
    ap.add_argument("--structure", default="time")
    ap.add_argument("--calibration", default=os.path.join(ROOT, "calibration"))
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    inst = problems.Instance(os.path.join(args.calibration, f"ensemble_{args.structure}.json"),
                             os.path.join(args.calibration, f"stage3_{args.structure}.json"),
                             args.seed, name=args.instance)
    r = run(args.alg, inst, args.seed, args.max_fes)
    np.savez_compressed(args.out, **r, alg=args.alg, instance=args.instance, seed=args.seed)
    feas = np.all(r["G"] <= 0, axis=1)
    print(f"{args.alg} {args.instance} seed {args.seed}: FE {r['fes']}, runtime {r['runtime']:.1f} s, "
          f"output {len(r['X'])}, feasible {int(feas.sum())}, not in cache {r['missing']}, "
          f"unique evaluated {r['n_unique']}", flush=True)


if __name__ == "__main__":
    main()
