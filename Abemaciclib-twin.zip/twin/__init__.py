"""Abemaciclib digital twin: PK, neutrophils, tumour size and PFS, diarrhoea, label rules."""
