"""Model constants for the abemaciclib digital twin.

Every value carries its source. Values marked as initial values are replaced by the
staged calibration (scripts/calibrate_stage12.py, scripts/calibrate_stage3.py); the
calibrated values are stored in calibration/*.json.
"""

MW_ABEMA = 506.6  # g/mol; Chigutsa 2026 supplement divides the dose by 0.5066

# ---------------------------------------------------------------- PK
# Main model: one compartment, first-order absorption, exposure calibrated to
# the mechanistic model of Chigutsa 2020 (CPT:PSP), which supplied the
# concentrations behind the Chigutsa 2026 efficacy parameters.
#   CL/F: 150 mg / 2960 ng.h/mL, the geometric-mean single-dose AUC(0-inf) of
#         MONARCH 2 patients (Chigutsa 2020, Table 3) -> Cavg,ss 247 ng/mL.
#   V/F:  gives the 17.5 h half-life of the same table (label: 18.3 h).
#   F(D): near dose-proportional; typical AUC 1200/2350/3430/4500 ng.h/mL at
#         50/100/150/200 mg read from Chigutsa 2020 Figure 3 (figure reading).
#   The single-dose Cmax of the table (123 ng/mL) is not reproduced by a
#   one-compartment model with this half-life; only averages are used here.
PK_KA = 0.197              # 1/h, Tate 2017
PK_CL = 150.0 / 2.960      # L/h (CL/F) = 50.7
PK_V = PK_CL * 17.5 / 0.6931  # L (V/F) = 1280
PK_F_INTERCEPT = 1.075     # F_rel(D) = intercept + slope * D, equal to 1 at 150 mg
PK_F_SLOPE = -0.0005       # per mg
PK_CV_KA = 0.776           # Tate 2017
PK_CV_CL = 0.51            # label, section 12.3 (hepatic clearance, 51% CV)

# Alternative model for the sensitivity scenario: Tate 2017 (phase I, n = 224),
# Table 3. Bioavailability falls with dose and with time on treatment, which
# conflicts with Chigutsa 2020 and with the label (approximately dose
# proportional, accumulation ratio 3.2).
TATE_CL = 35.9
TATE_V = 1050.0
TATE_D50 = 101.0           # F_ss(D) = 1 - D / (D50 + D)
TATE_LAMBDA_F = 0.00197    # 1/h; F(t) = F_ss + (1 - F_ss) * exp(-lambda * t)
TATE_CV_CL = 0.296
TATE_CV_F = 0.734

# ---------------------------------------------------------------- neutrophils
# Friberg structure with k_prol = k_tr = k_circ = 4 / MTT.
# System parameters: palbociclib in breast-cancer patients,
# Le Marouille 2021 (Pharmaceutics 13:1708), Table 4.
ANC_BASE = 2.92      # 1e9/L
ANC_MTT_H = 5.29 * 24.0  # h
ANC_GAMMA = 0.103
ANC_CV_BASE = 0.296
ANC_CV_MTT = 0.179
ANC_CV_SLOPE = 0.288
ANC_SLOPE = 0.45     # per mg/L. Initial value, calibrated in stage 1
ANC_MIN_ELIGIBLE = 1.5   # 1e9/L; MONARCH eligibility, baseline ANC truncated below

# ---------------------------------------------------------------- tumour and PFS
# Chigutsa 2026 (Clin Pharmacol Ther), Tables 1 and 2. Time unit: week.
# Concentration unit: umol/L (confirmed by the NONMEM code in the supplement).
TS_BASE = 36.7       # mm
TS_KGROW = 0.00715   # mm/week
TS_KTRANS = 0.934    # 1/week
TS_E_FULV = 0.00647  # 1/week
TS_E_ABE = 0.0399    # 1/week per umol/L
TS_T_DELAY = 7.11    # week
TS_THALF_ABE_ARM = 8.44   # week
TS_THALF_CTRL_ARM = 2.51  # week
TS_CV_BASE = 0.79
TS_CV_KGROW = 114.0
TS_CV_KTRANS = 0.151
TS_CV_E_FULV = 2.68
TS_CV_E_ABE = 2.93
TS_CV_THALF_ABE = 2.03
TS_CV_THALF_CTRL = 0.197
TS_CV_DELAY = 4.73
# Correlations between random effects, Table 1.
TS_CORR_BASE_KGROW = 0.265
# Order: fulvestrant effect, abemaciclib effect, half-life control arm,
# half-life abemaciclib arm, delay.
TS_CORR_DRUG = (
    (1.0, -0.140, -0.380, 0.213, 0.412),
    (-0.140, 1.0, -0.636, -0.880, -0.507),
    (-0.380, -0.636, 1.0, 0.235, -0.0862),
    (0.213, -0.880, 0.235, 1.0, 0.632),
    (0.412, -0.507, -0.0862, 0.632, 1.0),
)

HZ_BASE_MEAS = 0.0157     # 1/week
HZ_BASE_NONMEAS = 0.0103  # 1/week
HZ_CFB = 0.0156           # per mm change from baseline
HZ_CFB_HIGH_FACTOR = 1.0 + 13.6
HZ_FRAC_HIGH = 0.479
HZ_CONC = 1.42            # per umol/L
HZ_THALF_CONC = 12.2      # week; no decline for non-measurable disease
HZ_HEPATIC = 1.23         # baseline hazard multiplied by (1 + value)
HZ_ECOG1 = 0.479

# Baseline covariates, MONARCH 2 (Sledge 2017, Figure 3 subgroup counts, n = 669):
# measurable disease 482 / 669, ECOG 1 263 / 669 (Table 1: 71.3% / 73.5% and 39.5% / 39.0%).
FRAC_MEASURABLE = 482.0 / 669.0
FRAC_ECOG1 = 263.0 / 669.0
# Liver metastases 174 / 669: Di Leo 2018 (npj Breast Cancer 4:41), Figure 2a numbers at risk
# (115 / 446 abemaciclib, 59 / 223 placebo); the OS subgroup plot of Neven (SABCS 2019) gives 174 / 669 too.
FRAC_HEPATIC = 174.0 / 669.0
# MONARCH 3 (Goetz 2017, Figure 3 subgroup counts, n = 493): measurable 397, ECOG 1 197,
# liver metastases 78.
M3_FRAC_MEASURABLE = 397.0 / 493.0
M3_FRAC_ECOG1 = 197.0 / 493.0
M3_FRAC_HEPATIC = 78.0 / 493.0
# MONARCH 1 (Dickler 2017, Table 1, n = 132): all measurable, ECOG 1 59, liver 93.
M1_FRAC_MEASURABLE = 1.0
M1_FRAC_ECOG1 = 59.0 / 132.0
M1_FRAC_HEPATIC = 93.0 / 132.0

# ---------------------------------------------------------------- diarrhoea
# Grade chain 0-3. Everything except the durations is an initial value
# (calibrated in stage 2).
DI_Q_UP_PER_DAY = (0.12, 0.08, 0.03)  # 0->1, 1->2, 2->3 at C_REF and t = 0
DI_C_REF = 0.2            # mg/L
DI_BETA = 1.0
DI_KH_PER_DAY = 0.02      # tolerance rate
DI_MEDIAN_DAYS = (7.0, 9.0, 6.0)  # grade 1 assumed; grades 2 and 3 from the label ranges
DI_CV_Q = 0.5
# Alternative tolerance structure: rates multiplied by exp(-DI_KC * AUC(t)),
# AUC(t) the cumulative exposure in mg.h/L. Initial value, calibrated in stage 2.
# At 150 mg (Cavg 0.247 mg/L) DI_KC = DI_KH_PER_DAY / 24 / 0.247 gives the same decay as the time structure.
DI_TOLERANCE = 0          # 0: time on study (main analysis), 1: cumulative exposure
DI_KC = 0.02 / 24.0 / 0.247  # per mg.h/L

# ---------------------------------------------------------------- other adverse reactions
# Dose reductions and discontinuations for adverse reactions other than diarrhoea and
# neutropenia (fatigue, ALT increase, infection, ...): label, 43-49% of patients reduced for
# any adverse reaction but only about 30% for diarrhoea or neutropenia; 8-19% discontinued.
# Rates per day at C = C_REF, proportional to the concentration. The reduction rate declines
# as exp(-k t); the discontinuation rate is constant (label: discontinuation grows with the
# duration of treatment, 8% in MONARCH 1 at 4.5 months to 19% in monarchE at 24 months).
# Initial values, calibrated in stage 2.
OTH_RED_PER_DAY = 0.002
OTH_DISC_PER_DAY = 0.0005
OTH_K_PER_DAY = 0.003

# ---------------------------------------------------------------- rule adherence
# Fraction of patients in whom the label rule is actually applied. In the
# trials far fewer patients had abemaciclib withheld than the label rules
# would imply from the reported grades, so strict application over-predicts
# dose interruptions. 1.0 = label rule always applied. Initial values,
# calibrated together with the toxicity parameters.
RULE_G2_DIARRHOEA_FRAC = 1.0    # grade 2 lasting more than 24 h -> withhold
RULE_G3_NEUTROPENIA_FRAC = 1.0  # first grade 3 at a blood count -> withhold

# ---------------------------------------------------------------- simulation grid
STEP_H = 6.0
STEPS_PER_DAY = 4
N_DAYS_DEFAULT = 730      # 24 months
DAYS_PER_MONTH = 30.4375
