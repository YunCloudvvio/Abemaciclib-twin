"""Tests of the post-run true-value step for PlatEMO algorithms run with Deb's rule (twin/true_values.py)."""
import os
import subprocess
import sys

import numpy as np
import pytest
from scipy.io import loadmat, savemat

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

ENS = os.path.join(ROOT, "calibration", "ensemble_time.json")
pytestmark = pytest.mark.skipif(not os.path.exists(ENS), reason="no calibration")

from twin import problems  # noqa: E402
from twin.true_values import deb  # noqa: E402

SEED = 4242


def fake_run(path, corrupt=False):
    inst = problems.Instance(ENS, os.path.join(ROOT, "calibration", "stage3_time.json"), SEED, name="P1")
    rng = np.random.default_rng(0)
    X = np.column_stack([rng.integers(1, 4, 6), rng.integers(2, 4, 6), rng.integers(7, 29, 6),
                         rng.uniform(1, 2, 6), rng.integers(0, 15, 6), rng.integers(0, 4, 6),
                         rng.integers(28, 85, 6), rng.integers(0, 3, 6)]).astype(float)
    X[0, :] = [1, 2, 7, 1.0, 0, 0, 28, 0]                 # low dose: violates the RDI constraint
    F, G = inst.evaluate(X)
    Fa = deb(F, G)
    if corrupt:
        Fa[1, 2] += 0.01
    ck = np.empty((1, 2), dtype=object)
    ck[0, 0], ck[0, 1] = Fa[:3], Fa
    cd = np.empty((1, 2), dtype=object)
    cd[0, 0], cd[0, 1] = X[:3], X
    cc = np.empty((1, 2), dtype=object)
    cc[0, 0], cc[0, 1] = np.zeros((3, 3)), np.zeros((6, 3))
    savemat(path, {"Dec": X, "Obj": Fa, "Con": np.zeros_like(G), "ckpt_FE": np.array([[500, 1000]]),
                   "ckpt_Dec": cd, "ckpt_Obj": ck, "ckpt_Con": cc})
    return X, F, G


def run_step(inp, out):
    return subprocess.run([sys.executable, "-m", "twin.true_values", "--inp", inp, "--out", out, "--instance", "P1",
                           "--seed", str(SEED)], cwd=ROOT, capture_output=True, text=True)


def test_true_values_are_restored(tmp_path):
    inp, out = str(tmp_path / "a.mat"), str(tmp_path / "b.mat")
    X, F, G = fake_run(inp)
    assert np.any(np.any(G > 0, axis=1))                  # the case includes an infeasible policy
    r = run_step(inp, out)
    assert r.returncode == 0, r.stdout + r.stderr
    d = loadmat(out)
    assert np.array_equal(d["Obj"], F) and np.array_equal(d["Con"], G)
    assert np.array_equal(np.asarray(d["ckpt_Obj"].ravel()[1]), F)
    assert np.array_equal(np.asarray(d["ckpt_Con"].ravel()[0]), G[:3])
    assert np.array_equal(d["ObjAlg"], deb(F, G))


def test_a_mismatch_is_an_error_and_writes_nothing(tmp_path):
    inp, out = str(tmp_path / "a.mat"), str(tmp_path / "b.mat")
    fake_run(inp, corrupt=True)
    r = run_step(inp, out)
    assert r.returncode != 0 and not os.path.exists(out)
