"""Tests of the E4 scenarios (twin/scenarios.py and their use in twin/problems.Instance)."""
import os
import sys

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from twin import population as pm  # noqa: E402
from twin import problems  # noqa: E402
from twin import scenarios as SC  # noqa: E402

ENS = os.path.join(ROOT, "calibration", "ensemble_time.json")
S3 = os.path.join(ROOT, "calibration", "stage3_time.json")
pytestmark = pytest.mark.skipif(not (os.path.exists(ENS) and os.path.exists(S3)), reason="no calibration")

STANDARD = [3, 3, 14, 1.0, 0, 0, 28, 0]
POLICIES = np.array([STANDARD, [1, 3, 14, 1.0, 0, 0, 28, 0], [2, 3, 21, 1.5, 7, 2, 56, 1], [3, 2, 7, 1.2, 3, 1, 28, 2]],
                    dtype=float)


def make(scenario=None, seed=7):
    return problems.Instance(ENS, S3, seed, n_per_member=5, name="P1", scenario=scenario)


@pytest.fixture(scope="module")
def base():
    old = os.environ.pop("TWIN_SCENARIO", None)
    inst = make()
    if old is not None:
        os.environ["TWIN_SCENARIO"] = old
    return inst, inst.evaluate(POLICIES)


def test_scenario_list():
    grid = [k for k in SC.SCENARIOS if k.startswith("eff_")]
    assert len(grid) == 8 and "eff_mid_tol_mid" not in grid
    assert len(SC.SCENARIOS) == 15 and "base" in SC.SCENARIOS
    for v in SC.SCENARIOS.values():
        assert set(v) <= SC.KEYS
    assert SC.SCENARIOS["eff_low_tol_high"] == {"e_abe": 0.0259, "hz_conc": 0.820, "tol_mult": 1.5}


def test_unset_and_base_are_identical(base, monkeypatch):
    inst0, (F0, G0) = base
    assert inst0.scenario == "base" and inst0.n_days == 730 and inst0.rdi_min == 0.6
    F1, G1 = make("base").evaluate(POLICIES)
    assert np.array_equal(F0, F1) and np.array_equal(G0, G1)
    monkeypatch.setenv("TWIN_SCENARIO", "base")
    F2, G2 = make().evaluate(POLICIES)
    assert np.array_equal(F0, F2) and np.array_equal(G0, G2)
    monkeypatch.setenv("TWIN_SCENARIO", "")
    assert make().scenario == "base"


def test_environment_selects_the_scenario(monkeypatch):
    monkeypatch.setenv("TWIN_SCENARIO", "rdi_0.7")
    assert make().scenario == "rdi_0.7" and make().rdi_min == 0.7
    monkeypatch.setenv("TWIN_SCENARIO", "no_such_scenario")
    with pytest.raises(ValueError):
        make()


def test_efficacy_scenarios_change_only_the_efficacy_columns(base):
    inst0, _ = base
    for name, e_abe, hz in (("eff_low_tol_mid", 0.0259, 0.820), ("eff_high_tol_mid", 0.0661, 2.34)):
        inst = make(name)
        for (p0, t0, u0, d0), (p1, t1, u1, d1) in zip(inst0.groups, inst.groups):
            assert np.allclose(p1[:, pm.C_E_ABE], p0[:, pm.C_E_ABE] * e_abe / 0.0399, rtol=1e-12)
            assert np.all(p1[:, pm.C_HZ_CONC] == hz)
            other = np.ones(p0.shape[1], bool)
            other[[pm.C_E_ABE, pm.C_HZ_CONC]] = False
            assert np.array_equal(p0[:, other], p1[:, other])
            assert np.array_equal(t0, t1) and np.array_equal(u0, u1) and np.array_equal(d0, d1)


def test_efficacy_direction(base):
    _, (F0, _) = base
    Flo, _ = make("eff_low_tol_mid").evaluate(POLICIES)
    Fhi, _ = make("eff_high_tol_mid").evaluate(POLICIES)
    assert np.all(Fhi[:, 0] < F0[:, 0]) and np.all(Flo[:, 0] > F0[:, 0])   # f1 = -RMST


def test_tolerance_scenario_scales_only_the_tolerance_rate(base):
    inst0, (F0, _) = base
    for name, mult in (("eff_mid_tol_high", 1.5), ("eff_mid_tol_low", 1.0 / 1.5)):
        inst = make(name)
        for (p0, _, _, d0), (p1, _, _, d1) in zip(inst0.groups, inst.groups):
            assert np.array_equal(p0, p1)
            diff = np.nonzero(d0 != d1)[0]
            assert diff.tolist() == [6]            # kh per hour (time structure)
            assert d1[6] == pytest.approx(mult * d0[6], rel=1e-12)
    F1, _ = make("eff_mid_tol_high").evaluate(POLICIES)
    assert F1[:, 2].mean() < F0[:, 2].mean() and F1[0, 2] < F0[0, 2]   # faster tolerance, fewer diarrhoea days


def test_neutrophil_scenarios(base):
    inst0, (F0, _) = base
    hi, lo = make("anc_high"), make("anc_low")
    for (p0, *_), (p1, *_), (p2, *_) in zip(inst0.groups, hi.groups, lo.groups):
        assert np.allclose(p1[:, pm.C_SLOPE], 1.5 * p0[:, pm.C_SLOPE], rtol=1e-12)
        assert np.allclose(p2[:, pm.C_SLOPE], p0[:, pm.C_SLOPE] / 1.5, rtol=1e-12)
    Fh, _ = hi.evaluate(POLICIES)
    Fl, _ = lo.evaluate(POLICIES)
    assert Fh[:, 1].mean() > F0[:, 1].mean() > Fl[:, 1].mean()
    assert Fh[0, 1] > F0[0, 1] > Fl[0, 1]


def test_rdi_bound_changes_only_constraint_1(base):
    _, (F0, G0) = base
    for name, bound in (("rdi_0.5", 0.5), ("rdi_0.7", 0.7)):
        F1, G1 = make(name).evaluate(POLICIES)
        assert np.array_equal(F0, F1) and np.array_equal(G0[:, 1:], G1[:, 1:])
        assert np.allclose(G1[:, 0], G0[:, 0] + (bound - 0.6), atol=1e-12)


def test_window_scenarios(base):
    _, (F0, _) = base
    i18, i36 = make("window_18"), make("window_36")
    assert i18.n_days == 548 and i36.n_days == 1096
    F18, _ = i18.evaluate(POLICIES)
    F36, _ = i36.evaluate(POLICIES)
    assert np.all(F18[:, 0] >= -548 / 30.4375 - 1e-12) and np.all(F18[:, 0] > F0[:, 0])
    assert np.all(F36[:, 0] < F0[:, 0])
    assert np.all(F36[:, 0] >= -1096 / 30.4375 - 1e-12)


def test_window_scenarios_keep_the_random_numbers_of_the_common_days(base):
    inst0, _ = base
    i18, i36 = make("window_18"), make("window_36")
    for (p0, t0, u0, d0), (p1, t1, u1, d1), (p2, t2, u2, d2) in zip(inst0.groups, i18.groups, i36.groups):
        assert np.array_equal(p0, p1) and np.array_equal(p0, p2)
        assert np.array_equal(t0, t1) and np.array_equal(t0, t2)
        assert u1.shape[1] == 548 * 4 and u2.shape[1] == 1096 * 4
        assert np.array_equal(u0[:, :548 * 4], u1)
        assert np.array_equal(u0, u2[:, :730 * 4])
        assert u1.flags["C_CONTIGUOUS"] and u2.flags["C_CONTIGUOUS"]
