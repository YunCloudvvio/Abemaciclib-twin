"""Unit tests of the simulation kernel: PK, numerical accuracy, label rules, policy rules.

Run from the project root:  python -m pytest tests -q
"""
import math
import os
import sys

import numpy as np
from scipy.integrate import solve_ivp

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from twin import kernel as K  # noqa: E402
from twin import params as P  # noqa: E402
from twin import population as pm  # noqa: E402

N_DAYS = 120
N_STEPS = N_DAYS * P.STEPS_PER_DAY
STAY = 0.9   # random number that leaves the diarrhoea grade unchanged
DROP = 0.2   # random number that lowers the grade by one
RISE = 0.0   # random number that raises the grade by one


def typical_patient(slope=0.0, diarrhoea=1.0):
    pop = np.zeros((1, pm.N_COLS))
    pop[0, pm.C_KA] = P.PK_KA
    pop[0, pm.C_KE] = P.PK_CL / P.PK_V
    pop[0, pm.C_V] = P.PK_V
    pop[0, pm.C_FMULT] = 1.0
    pop[0, pm.C_ANC_BASE] = P.ANC_BASE
    pop[0, pm.C_KTR] = 4.0 / P.ANC_MTT_H
    pop[0, pm.C_GAMMA] = P.ANC_GAMMA
    pop[0, pm.C_SLOPE] = slope
    pop[0, pm.C_MEAS] = 1.0
    pop[0, pm.C_S0] = P.TS_BASE
    pop[0, pm.C_KGROW] = P.TS_KGROW
    pop[0, pm.C_KTRANS] = P.TS_KTRANS
    pop[0, pm.C_E_ET] = P.TS_E_FULV
    pop[0, pm.C_E_ABE] = P.TS_E_ABE
    pop[0, pm.C_RESIST] = math.log(2.0) / P.TS_THALF_ABE_ARM
    pop[0, pm.C_DELAY] = P.TS_T_DELAY
    pop[0, pm.C_HZ_BASE] = P.HZ_BASE_MEAS
    pop[0, pm.C_HZ_CFB] = P.HZ_CFB
    pop[0, pm.C_HZ_CONC] = P.HZ_CONC
    pop[0, pm.C_HZ_DECAY] = math.log(2.0) / P.HZ_THALF_CONC
    pop[0, pm.C_DI_MULT] = diarrhoea
    pop[0, pm.C_FORCE_DAY] = np.inf
    pop[0, pm.C_G2_STRICT] = 1.0
    pop[0, pm.C_ANC3_STRICT] = 1.0
    return pop


def diarrhoea_test_constants():
    """Tiny upward rates (a draw of 0 still raises the grade) and a 50% chance of recovery per step."""
    down = math.log(2.0) / P.STEP_H
    return np.array([1e-7, 1e-7, 1e-7, down, down, down, 0.0, 1.0, P.DI_C_REF, 0.0, 0.0, 0.0, 0.0, 0.0])


def run(theta, pop, u=None, cbc=True, n_days=N_DAYS):
    if u is None:
        u = np.full((1, n_days * P.STEPS_PER_DAY), STAY, dtype=np.float32)
    is_cbc = pm.cbc_schedule(n_days) if cbc else np.zeros(n_days + 1, dtype=np.bool_)
    out = np.zeros((1, K.N_OUT))
    trace = np.zeros((n_days, K.N_TRACE))
    K.simulate(theta, pop, np.array([1e9]), u, is_cbc, diarrhoea_test_constants(),
               pm.pk_constants(), n_days, out, trace)
    return out[0], trace


def policy(start=3, target=3, esc=14, anc_min=1.0, diar_free=0, n_pre=0, re_days=28, r_max=0):
    theta = np.zeros(K.N_THETA)
    theta[K.T_START_LEVEL] = start
    theta[K.T_TARGET_LEVEL] = target
    theta[K.T_ESC_DAYS] = esc
    theta[K.T_ANC_MIN] = anc_min
    theta[K.T_DIAR_FREE_DAYS] = diar_free
    theta[K.T_N_PRE] = n_pre
    theta[K.T_RE_DAYS] = re_days
    theta[K.T_R_MAX] = r_max
    return theta


def draws(**segments):
    """Random numbers for the diarrhoea chain: STAY everywhere except the given step ranges."""
    u = np.full((1, N_STEPS), STAY, dtype=np.float32)
    for value, ranges in segments.items():
        for lo, hi in ranges:
            u[0, lo:hi] = {"rise": RISE, "drop": DROP}[value]
    return u


# ------------------------------------------------------------------ PK and numerics

def test_pk_steady_state_average_matches_dose_over_clearance():
    _, trace = run(policy(), typical_patient())
    expected = 150.0 / (P.PK_CL * 12.0)   # mg/L, F_rel = 1 at 150 mg
    assert abs(trace[60, K.TR_CONC] / expected - 1.0) < 0.005
    assert abs(expected * 1000.0 - 247.0) < 1.0   # ng/mL, Chigutsa 2020 Table 3


def test_exposure_is_nearly_dose_proportional():
    _, t50 = run(policy(start=1, target=1), typical_patient())
    _, t150 = run(policy(), typical_patient())
    ratio = t50[60, K.TR_CONC] / t150[60, K.TR_CONC]
    assert abs(ratio - 1200.0 / 3430.0) < 0.01   # Chigutsa 2020 Figure 3


def test_no_toxicity_keeps_full_dose():
    out, trace = run(policy(), typical_patient())
    assert out[K.O_RDI] == 1.0
    assert not out[K.O_DISCONTINUED] and not out[K.O_ANC3]
    assert np.all(trace[:, K.TR_LEVEL] == 3) and not trace[:, K.TR_ON_HOLD].any()


def test_kernel_matches_reference_ode_solution():
    """Fixed-step kernel against an adaptive solver, no dose modification."""
    slope = 0.3
    pop = typical_patient(slope=slope)
    _, trace = run(policy(), pop, cbc=False, n_days=180)

    ka, ke, vol = pop[0, pm.C_KA], pop[0, pm.C_KE], pop[0, pm.C_V]
    ktr, base, gamma = pop[0, pm.C_KTR], P.ANC_BASE, P.ANC_GAMMA
    resist = math.log(2.0) / P.TS_THALF_ABE_ARM

    def rhs(t, y):
        gut, cen, prol, t1, t2, t3, circ, h, d1, d2, d3 = y
        conc = cen / vol
        fb = (base / max(circ, 1e-3)) ** gamma
        t_wk = t / 168.0
        decay = math.exp(-resist * max(0.0, t_wk - P.TS_T_DELAY))
        ks = (P.TS_E_FULV + P.TS_E_ABE * conc / (P.MW_ABEMA / 1000.0)) * decay / 168.0
        ktrans = P.TS_KTRANS / 168.0
        return [-ka * gut, ka * gut - ke * cen,
                ktr * prol * ((1.0 - slope * conc) * fb - 1.0),
                ktr * (prol - t1), ktr * (t1 - t2), ktr * (t2 - t3), ktr * (t3 - circ),
                P.TS_KGROW / 168.0 - ks * h, ks * h - ktrans * d1,
                ktrans * (d1 - d2), ktrans * (d2 - d3)]

    y = np.array([0.0, 0.0] + [base] * 5 + [P.TS_BASE, 0.0, 0.0, 0.0])
    reference = {}
    for dose_index in range(180 * 2):
        y[0] += 150.0
        sol = solve_ivp(rhs, (dose_index * 12.0, dose_index * 12.0 + 12.0), y, method="LSODA",
                        rtol=1e-9, atol=1e-12)
        y = sol.y[:, -1]
        if dose_index % 2 == 1:
            reference[dose_index // 2] = (y[6], y[7:].sum())

    for day in (13, 29, 59, 119, 179):
        anc_ref, tumour_ref = reference[day]
        assert abs(trace[day, K.TR_ANC] / anc_ref - 1.0) < 0.01
        assert abs(trace[day, K.TR_TUMOUR] / tumour_ref - 1.0) < 0.01


# ------------------------------------------------------------------ label rules

def test_grade3_diarrhoea_withholds_then_resumes_one_level_lower():
    u = draws(rise=[(0, 3)], drop=[(3, 6)])
    out, trace = run(policy(), typical_patient(), u)
    assert trace[0, K.TR_LEVEL] == 3
    assert trace[2, K.TR_LEVEL] == 2 and not trace[2, K.TR_ON_HOLD]
    assert out[K.O_LEVEL_DAY84] == 2 and not out[K.O_DISCONTINUED]


def test_grade2_under_24h_does_not_withhold():
    u = draws(rise=[(0, 2)], drop=[(3, 5)])       # grade 2 for two steps only
    out, trace = run(policy(), typical_patient(), u)
    assert out[K.O_RDI] == 1.0 and out[K.O_LEVEL_DAY84] == 3


def test_grade2_over_24h_withholds_without_reduction_then_recurrence_reduces():
    # First episode: grade 2 from step 1, lasting beyond 24 h, recovers at step 8.
    # Second episode: the same pattern from step 40.
    u = draws(rise=[(0, 2), (40, 42)], drop=[(8, 10), (48, 50)])
    out, trace = run(policy(), typical_patient(), u)
    assert trace[1, K.TR_ON_HOLD] == 1          # withheld during the first episode
    assert trace[5, K.TR_LEVEL] == 3            # resumed at the same dose
    assert trace[11, K.TR_ON_HOLD] == 1         # withheld again
    assert trace[14, K.TR_LEVEL] == 2           # recurrence at the same dose -> one level lower
    assert out[K.O_LEVEL_DAY84] == 2


def test_lowest_dose_not_tolerated_means_discontinuation():
    u = draws(rise=[(0, 3)], drop=[(3, 6)])
    out, _ = run(policy(start=1, target=1), typical_patient(), u)
    assert out[K.O_DISCONTINUED] == 1 and out[K.O_LEVEL_DAY84] == 0


def test_neutropenia_acts_only_when_a_blood_count_sees_it():
    out, trace = run(policy(), typical_patient(slope=3.0))
    assert trace[12, K.TR_ANC] < 1.0            # already grade 3 before the day-14 count
    assert not trace[:14, K.TR_ON_HOLD].any()   # nobody knows yet
    assert trace[14, K.TR_ON_HOLD] == 1         # day-14 blood count
    assert out[K.O_ANC3] == 1 and out[K.O_ANC3_DETECTED] == 1


def test_undetected_neutropenia_counts_as_true_event_only():
    out, trace = run(policy(), typical_patient(slope=3.0), cbc=False)
    assert out[K.O_ANC3] == 1 and out[K.O_ANC3_DETECTED] == 0
    assert out[K.O_RDI] == 1.0


def test_grade4_neutropenia_resumes_one_level_lower():
    out, trace = run(policy(), typical_patient(slope=3.0))
    assert trace[14, K.TR_ANC] < 0.5
    resumed = np.where((trace[:, K.TR_ON_HOLD] == 0) & (np.arange(N_DAYS) > 14))[0]
    assert resumed.size > 0 and trace[resumed[0], K.TR_LEVEL] == 2


# ------------------------------------------------------------------ policy rules

def test_escalation_follows_the_interval():
    out, trace = run(policy(start=1, target=3, esc=14), typical_patient())
    assert trace[13, K.TR_LEVEL] == 1 and trace[14, K.TR_LEVEL] == 2
    assert trace[27, K.TR_LEVEL] == 2 and trace[28, K.TR_LEVEL] == 3
    assert out[K.O_LEVEL_DAY84] == 3
    assert trace[:, K.TR_LEVEL].max() == 3      # never above the target


def test_escalation_waits_for_the_anc_threshold():
    out, _ = run(policy(start=1, target=3, esc=14, anc_min=5.0), typical_patient())
    assert out[K.O_LEVEL_DAY84] == 1            # baseline ANC 2.92 never reaches 5.0


def test_escalation_waits_for_diarrhoea_free_days():
    u = draws(rise=[(40, 42)], drop=[(43, 45)])  # short grade 2 on day 10
    _, late = run(policy(start=1, target=3, esc=14, diar_free=10), typical_patient(), u)
    _, plain = run(policy(start=1, target=3, esc=14, diar_free=0), typical_patient(), u)
    assert plain[14, K.TR_LEVEL] == 2
    assert late[14, K.TR_LEVEL] == 1 and late[21, K.TR_LEVEL] == 2


def test_preventive_reduction_after_early_grade2_episodes():
    u = draws(rise=[(0, 2)], drop=[(3, 5)])       # one short grade-2 episode
    off, _ = run(policy(n_pre=0), typical_patient(), u)
    on, _ = run(policy(n_pre=1), typical_patient(), u)
    two, _ = run(policy(n_pre=2), typical_patient(), u)
    assert off[K.O_LEVEL_DAY84] == 3 and on[K.O_LEVEL_DAY84] == 2 and two[K.O_LEVEL_DAY84] == 3


def test_re_escalation_is_allowed_only_when_enabled():
    u = draws(rise=[(0, 3)], drop=[(3, 6)])       # grade 3 -> reduced to level 2
    never, _ = run(policy(r_max=0), typical_patient(), u)
    once, trace = run(policy(r_max=1, re_days=28, esc=14), typical_patient(), u)
    assert never[K.O_LEVEL_DAY84] == 2
    assert trace[27, K.TR_LEVEL] == 2 and once[K.O_LEVEL_DAY84] == 3


# ------------------------------------------------------------------ label rules, blood counts and policy rules

def _run_custom(theta, pop, u, is_cbc, dcon, n_days=N_DAYS):
    out = np.zeros((1, K.N_OUT))
    trace = np.zeros((n_days, K.N_TRACE))
    K.simulate(theta, pop, np.array([1e9]), u, is_cbc, dcon, pm.pk_constants(), n_days, out, trace)
    return out[0], trace


def test_exposure_tolerance_switches_off_diarrhoea_after_large_exposure():
    u = draws(rise=[(20, 22)])
    no_tol = diarrhoea_test_constants()
    no_tol[9], no_tol[10] = K.TOL_EXPOSURE, 0.0
    strong = no_tol.copy()
    strong[10] = 1e6          # any cumulative exposure removes the upward rates
    cbc = pm.cbc_schedule(N_DAYS)
    out0, _ = _run_custom(policy(), typical_patient(), u, cbc, no_tol)
    out1, _ = _run_custom(policy(), typical_patient(), u, cbc, strong)
    assert out0[K.O_MAX_DIAR] >= 1 and out1[K.O_MAX_DIAR] == 0


def test_anc_recheck_is_weekly_from_the_start_of_the_hold():
    is_cbc = np.zeros(N_DAYS + 1, dtype=np.bool_)
    is_cbc[10] = True                                  # a single scheduled count on day 10
    u = np.full((1, N_STEPS), STAY, dtype=np.float32)
    out, trace = _run_custom(policy(), typical_patient(slope=2.0), u, is_cbc, diarrhoea_test_constants())
    assert trace[10, K.TR_ON_HOLD] == 1
    resumed = np.where((trace[:, K.TR_ON_HOLD] == 0) & (np.arange(N_DAYS) > 10))[0]
    assert resumed.size > 0 and (resumed[0] - 10) % 7 == 0


def test_true_grade3_onset_and_duration_are_recorded():
    out, trace = run(policy(), typical_patient(slope=3.0))
    below = np.where(trace[:, K.TR_ANC] < 1.0)[0]
    assert abs(out[K.O_ANC3_ONSET_TRUE] - below[0]) <= 1.0
    assert out[K.O_ANC3_DUR_TRUE] > 0.0


def test_results_do_not_depend_on_the_number_of_threads():
    import numba
    n = 300
    pop = pm.sample_patients(n, seed=5)
    thr, u = pm.sample_noise(n, N_DAYS, seed=6)
    args = (K.standard_policy(), pop, thr, u, pm.cbc_schedule(N_DAYS), pm.diarrhoea_constants(),
            pm.pk_constants(), N_DAYS)
    outs = []
    import pytest
    if numba.config.NUMBA_NUM_THREADS < 2:
        pytest.skip("needs at least 2 threads")
    for threads in (1, min(3, numba.config.NUMBA_NUM_THREADS)):
        numba.set_num_threads(threads)
        out = np.zeros((n, K.N_OUT))
        K.simulate(*args, out, K.NO_TRACE)
        outs.append(out)
    numba.set_num_threads(numba.config.NUMBA_NUM_THREADS)
    assert np.array_equal(outs[0], outs[1])


def test_imaging_rounding_and_km_median():
    from twin import trials as T
    obs, event = T.observed_pfs_days(np.array([1.0, 30.0, 70.0, 730.0]), "monarch3", 730, window=0.0)
    assert list(obs[:3]) == [56.0, 56.0, 112.0] and not event[3]
    obs, _ = T.observed_pfs_days(np.full(1000, 30.0), "monarch3", 730)
    assert obs.min() >= 49.0 and obs.max() <= 63.0
    times = np.array([10.0, 20.0, 30.0, 40.0])
    assert T.km_median_months(times, np.ones(4, bool)) * P.DAYS_PER_MONTH == 20.0
    assert np.isnan(T.km_median_months(times, np.array([True, False, False, False])))


def test_other_adverse_reactions_reduce_and_discontinue():
    dcon = diarrhoea_test_constants()
    pop = typical_patient()
    pop[0, pm.C_OTH_RED1:pm.C_OTH_RED4 + 1] = [1.0, 2.0, 3.0, 4.0]
    pop[0, pm.C_OTH_DISC] = 1e9
    dcon[11] = 1.0 / 24.0 / 30.0     # about one reduction event per 30 days at C_REF
    u = np.full((1, N_STEPS), STAY, dtype=np.float32)
    out, trace = _run_custom(policy(), pop, u, pm.cbc_schedule(N_DAYS), dcon)
    assert out[K.O_N_RED_AE_OTHER] >= 2 and trace[-1, K.TR_LEVEL] < 3
    pop[0, pm.C_OTH_DISC] = 0.5
    dcon[12] = dcon[11]
    out, _ = _run_custom(policy(), pop, u, pm.cbc_schedule(N_DAYS), dcon)
    assert out[K.O_DISC_AE_OTHER] == 1 and out[K.O_DISCONTINUED] == 1


def test_grade2_neutropenia_delays_re_escalation():
    u = draws(rise=[(0, 3)], drop=[(3, 6)])       # grade 3 diarrhoea -> reduced to level 2 on day 1
    _, clean = run(policy(r_max=1, re_days=28, esc=14), typical_patient(), u)
    _, trace = run(policy(r_max=1, re_days=28, esc=14), typical_patient(slope=0.6), u)
    assert clean[40, K.TR_LEVEL] == 3             # no neutropenia: back to 150 mg after 28 days
    anc_counts = trace[[28, 42, 56], K.TR_ANC]
    assert np.all((anc_counts >= 1.0) & (anc_counts < 1.5))   # grade 2 at every blood count
    assert trace[80, K.TR_LEVEL] == 2             # so the re-escalation clock never reaches 28 days


# ------------------------------------------------------------------ edge cases of the dose rules

def test_discontinuation_at_lowest_dose_is_not_a_reduction():
    u = draws(rise=[(0, 3)], drop=[(3, 6)])
    out, _ = run(policy(start=1, target=1), typical_patient(), u)
    assert out[K.O_DISCONTINUED] == 1 and out[K.O_N_RED] == 0 and out[K.O_N_RED_DIAR] == 0
    assert out[K.O_FIRST_CHANGE_DAY] >= 0


def test_mandated_reduction_during_a_hold_serves_the_pending_reduction():
    pop = typical_patient()
    pop[0, pm.C_START_LEVEL] = 4
    pop[0, pm.C_FORCE_DAY] = 0.5
    pop[0, pm.C_FORCE_LEVEL] = 3
    u = draws(rise=[(0, 3)], drop=[(3, 6)])       # grade 3 diarrhoea on day 0 while at 200 mg
    theta = policy(target=4)
    out, trace = run(theta, pop, u)
    assert trace[5, K.TR_LEVEL] == 3              # resumes at 150 mg, not 100 mg
    assert out[K.O_N_RED] == 1


def test_preventive_reduction_waits_for_the_episode_and_does_not_stack():
    u = draws(rise=[(0, 3)], drop=[(3, 6)])       # one episode reaching grade 3
    out, trace = run(policy(n_pre=1), typical_patient(), u)
    assert trace[10, K.TR_LEVEL] == 2             # one level lower, not two
    assert out[K.O_N_RED] == 1


def test_baseline_anc_respects_eligibility():
    pop = pm.sample_patients(20000, seed=3)
    assert pop[:, pm.C_ANC_BASE].min() >= P.ANC_MIN_ELIGIBLE - 1e-9


# ------------------------------------------------------------------ weekly schedule (problem P3)

def schedule(levels):
    theta = np.zeros(K.N_THETA)
    theta[K.T_MODE] = 1
    theta[K.T_SCHED:K.T_SCHED + K.N_SCHED_WEEKS] = levels
    return theta


def test_full_dose_schedule_equals_the_standard_policy():
    pop = pm.sample_patients(300, seed=11)
    thr, u = pm.sample_noise(300, 400, seed=12)
    args = (pop, thr, u, pm.cbc_schedule(400), pm.diarrhoea_constants(), pm.pk_constants(), 400)
    a = np.zeros((300, K.N_OUT))
    b = np.zeros((300, K.N_OUT))
    K.simulate(K.standard_policy(), *args, a, K.NO_TRACE)
    K.simulate(schedule(np.full(K.N_SCHED_WEEKS, 3)), *args, b, K.NO_TRACE)
    assert np.array_equal(a, b)


def test_schedule_follows_the_planned_weeks_and_holidays():
    levels = np.full(K.N_SCHED_WEEKS, 2)
    levels[1] = 0                                     # drug holiday in week 2
    levels[2] = 1
    _, trace = run(schedule(levels), typical_patient(), n_days=200)
    assert trace[3, K.TR_LEVEL] == 2 and trace[10, K.TR_LEVEL] == 0 and trace[16, K.TR_LEVEL] == 1
    assert trace[13, K.TR_CONC] < 0.2 * trace[6, K.TR_CONC]   # concentration falls during the holiday
    assert trace[170, K.TR_LEVEL] == 3                # after 24 weeks: 150 mg


def test_label_reduction_caps_the_later_schedule():
    u = draws(rise=[(0, 3)], drop=[(3, 6)])           # grade 3 diarrhoea on day 0
    out, trace = run(schedule(np.full(K.N_SCHED_WEEKS, 3)), typical_patient(), u)
    assert trace[20, K.TR_LEVEL] == 2 and trace[100, K.TR_LEVEL] == 2
    assert out[K.O_N_RED_DIAR] == 1


def test_reduction_during_a_holiday_lowers_the_cap_without_discontinuation():
    levels = np.full(K.N_SCHED_WEEKS, 3)
    levels[1] = 0                                     # week 2 (days 7-13) off
    dcon = diarrhoea_test_constants()
    pop = typical_patient()
    pop[0, pm.C_OTH_RED1:pm.C_OTH_RED4 + 1] = [4.0, 1e9, 1e9, 1e9]
    pop[0, pm.C_OTH_DISC] = 1e9
    dcon[11] = 1.0 / 24.0 / 0.247 / 8.0
    u = np.full((1, N_STEPS), STAY, dtype=np.float32)
    out, trace = _run_custom(schedule(levels), pop, u, pm.cbc_schedule(N_DAYS), dcon)
    assert 7 <= out[K.O_FIRST_CHANGE_DAY] <= 13       # the event really falls in the holiday week
    assert out[K.O_DISCONTINUED] == 0 and out[K.O_N_RED_AE_OTHER] == 1
    assert trace[20, K.TR_LEVEL] == 2                 # week 3 planned 150 mg, capped at 100 mg


def test_schedule_reduces_from_the_dose_given_when_a_hold_crosses_weeks():
    levels = np.full(K.N_SCHED_WEEKS, 3)
    levels[1] = 1                                     # week 2 planned 50 mg
    u = draws(rise=[(20, 23)], drop=[(31, 34)])       # grade 3 diarrhoea on day 5 at 150 mg, back on day 8
    out, trace = run(schedule(levels), typical_patient(), u)
    assert out[K.O_DISCONTINUED] == 0                 # 150 mg -> cap 100 mg, not "50 mg not tolerated"
    assert trace[10, K.TR_LEVEL] == 1 and trace[16, K.TR_LEVEL] == 2


def test_schedule_grade2_recurrence_counts_only_at_the_same_dose():
    levels = np.full(K.N_SCHED_WEEKS, 3)
    levels[2:] = 2                                    # 150 mg in weeks 1-2, then 100 mg
    u = draws(rise=[(0, 2), (60, 62)], drop=[(8, 10), (68, 70)])   # grade 2 > 24 h in week 1 and in week 3
    out, trace = run(schedule(levels), typical_patient(), u)
    assert out[K.O_N_RED_DIAR] == 0                   # different doses: hold, no reduction
    assert trace[25, K.TR_LEVEL] == 2

def test_schedule_reduces_from_the_dose_given_not_from_the_cap():
    levels = np.full(K.N_SCHED_WEEKS, 3)
    levels[1] = 2                                     # week 2: 100 mg while the cap is still 150 mg
    u = draws(rise=[(36, 39)], drop=[(40, 43)])       # grade 3 diarrhoea on day 9 at 100 mg
    out, trace = run(schedule(levels), typical_patient(), u)
    assert trace[16, K.TR_LEVEL] == 1                 # 100 mg -> 50 mg; week 3 (planned 150) capped at 50
    assert out[K.O_DISCONTINUED] == 0


def test_schedule_recurrence_at_the_same_dose_reduces():
    u = draws(rise=[(0, 2), (60, 62)], drop=[(8, 10), (68, 70)])   # grade 2 > 24 h in weeks 1 and 3
    out, trace = run(schedule(np.full(K.N_SCHED_WEEKS, 3)), typical_patient(), u)
    assert out[K.O_N_RED_DIAR] == 1 and trace[25, K.TR_LEVEL] == 2


def test_schedule_holiday_does_not_hide_a_recurrence():
    levels = np.full(K.N_SCHED_WEEKS, 3)
    levels[1] = 0                                     # 150 / holiday / 150
    u = draws(rise=[(0, 2), (60, 62)], drop=[(8, 10), (68, 70)])
    out, trace = run(schedule(levels), typical_patient(), u)
    assert out[K.O_N_RED_DIAR] == 1 and trace[25, K.TR_LEVEL] == 2


def test_schedule_two_reductions_without_a_dose_in_between_drop_two_levels():
    dcon = diarrhoea_test_constants()
    pop = typical_patient()
    pop[0, pm.C_OTH_RED1:pm.C_OTH_RED4 + 1] = [1.01, 1.01 + 1e-7, 1e9, 1e9]
    pop[0, pm.C_OTH_DISC] = 1e9
    dcon[11] = 1.0 / 24.0 / 0.247 / 8.0
    u = np.full((1, N_STEPS), STAY, dtype=np.float32)
    a, ta = _run_custom(K.standard_policy(), pop, u, pm.cbc_schedule(N_DAYS), dcon)
    b, tb = _run_custom(schedule(np.full(K.N_SCHED_WEEKS, 3)), pop, u, pm.cbc_schedule(N_DAYS), dcon)
    assert a[K.O_N_RED_AE_OTHER] == 2 and ta[-1, K.TR_LEVEL] == 1
    assert np.array_equal(a, b) and np.array_equal(ta, tb)


# ------------------------------------------------------------------ boundary conditions

def test_first_grade3_neutropenia_holds_without_reduction_and_recurrence_reduces():
    out, trace = run(policy(), typical_patient(slope=0.85), n_days=120)
    hold = trace[:, K.TR_ON_HOLD]
    assert hold[14] == 1 and hold[42] == 1           # grade 3 seen at the day-14 and day-42 counts
    assert trace[30, K.TR_LEVEL] == 3                # first episode: resumed at the same dose
    assert trace[60, K.TR_LEVEL] == 2                # recurrence: one level lower


def test_neutropenia_recheck_is_every_7_days():
    is_cbc = np.zeros(N_DAYS + 1, dtype=np.bool_)
    is_cbc[10] = True
    u = np.full((1, N_STEPS), STAY, dtype=np.float32)
    _, trace = _run_custom(policy(), typical_patient(slope=2.0), u, is_cbc, diarrhoea_test_constants())
    assert trace[16, K.TR_ANC] < 1.0 and trace[23, K.TR_ANC] < 1.0 and trace[30, K.TR_ANC] >= 1.0
    resumed = np.where((trace[:, K.TR_ON_HOLD] == 0) & (np.arange(N_DAYS) > 10))[0]
    assert resumed[0] == 31                           # rechecks on days 17, 24, 31


def test_true_grade3_and_grade4_thresholds():
    lo, _ = run(policy(), typical_patient(slope=0.4), cbc=False)     # nadir about 1.05
    hi, _ = run(policy(), typical_patient(slope=0.44), cbc=False)    # nadir about 0.95
    assert lo[K.O_ANC3] == 0 and hi[K.O_ANC3] == 1
    a, _ = run(policy(), typical_patient(slope=0.65), cbc=False)     # nadir about 0.53
    b, _ = run(policy(), typical_patient(slope=0.7), cbc=False)      # nadir about 0.45
    assert a[K.O_ANC4] == 0 and b[K.O_ANC4] == 1


def test_diarrhoea_days_count_only_the_first_6_months():
    u = np.full((1, 200 * 4), STAY, dtype=np.float32)
    u[0, 190 * 4:190 * 4 + 2] = RISE                  # grade 2 from day 190
    out, _ = run(policy(), typical_patient(), u, n_days=200)
    assert out[K.O_MAX_DIAR] == 2 and out[K.O_DIAR_DAYS_6M] == 0
    u2 = np.full((1, 200 * 4), STAY, dtype=np.float32)
    u2[0, 100 * 4:100 * 4 + 2] = RISE                 # grade 2 from day 100 (never drops: STAY)
    out2, _ = run(policy(), typical_patient(), u2, n_days=200)
    assert out2[K.O_DIAR_DAYS_6M] > 0


def test_start_level_above_target_is_limited_to_the_target():
    _, trace = run(policy(start=3, target=2), typical_patient())
    assert trace[0, K.TR_LEVEL] == 2 and trace[:, K.TR_LEVEL].max() == 2


def test_other_adverse_reaction_at_50_mg_discontinues_without_a_reduction():
    dcon = diarrhoea_test_constants()
    pop = typical_patient()
    pop[0, pm.C_OTH_RED1:pm.C_OTH_RED4 + 1] = [0.5, 1e9, 1e9, 1e9]
    pop[0, pm.C_OTH_DISC] = 1e9
    dcon[11] = 1.0 / 24.0 / 0.247 / 8.0
    u = np.full((1, N_STEPS), STAY, dtype=np.float32)
    out, _ = _run_custom(policy(start=1, target=1), pop, u, pm.cbc_schedule(N_DAYS), dcon)
    assert out[K.O_DISCONTINUED] == 1 and out[K.O_N_RED] == 0 and out[K.O_N_RED_AE_OTHER] == 0


def test_other_adverse_reaction_during_a_pending_label_reduction_is_merged():
    dcon = diarrhoea_test_constants()
    dcon[11] = 1.0 / 24.0 / 0.247 / 8.0               # without diarrhoea the threshold 6.5 is crossed on day 11
    pop = typical_patient()
    pop[0, pm.C_OTH_RED1:pm.C_OTH_RED4 + 1] = [6.5, 1e9, 1e9, 1e9]
    pop[0, pm.C_OTH_DISC] = 1e9
    u = draws(rise=[(40, 43)], drop=[(52, 55)])       # grade 3 diarrhoea on day 10: hold days 10-12, reduction pending
    out, trace = _run_custom(policy(), pop, u, pm.cbc_schedule(N_DAYS), dcon)
    assert trace[10, K.TR_ON_HOLD] == 1 and trace[11, K.TR_ON_HOLD] == 1
    assert trace[20, K.TR_LEVEL] == 2 and trace[-1, K.TR_LEVEL] == 2      # one level lower, not two
    # the threshold is certainly crossed within 120 days; no other-AE reduction and no discontinuation
    # means the event was absorbed by the pending label reduction
    assert out[K.O_N_RED_DIAR] == 1 and out[K.O_N_RED_AE_OTHER] == 0 and out[K.O_DISCONTINUED] == 0


def test_rule_adherence_switches():
    u = draws(rise=[(0, 2)], drop=[(8, 10)])          # grade 2 for about 2 days
    pop = typical_patient()
    pop[0, pm.C_G2_STRICT] = 0.0
    out, trace = run(policy(), pop, u)
    assert trace[1, K.TR_ON_HOLD] == 0 and out[K.O_HELD_DIAR] == 0      # grade-2 rule not applied
    pop = typical_patient(slope=0.85)
    pop[0, pm.C_ANC3_STRICT] = 0.0
    out, trace = run(policy(), pop, n_days=120)
    assert trace[14, K.TR_ON_HOLD] == 0 and out[K.O_ANC3_DETECTED] == 1  # grade 3 seen but not acted on


def test_preventive_reduction_at_50_mg_lowers_the_ceiling():
    u = draws(rise=[(4, 6)], drop=[(7, 9)])           # one short grade-2 episode on day 1 at 50 mg
    out, trace = run(policy(start=1, target=3, esc=14, n_pre=1), typical_patient(), u)
    assert trace[14, K.TR_LEVEL] == 2                 # escalation goes on ...
    assert trace[:, K.TR_LEVEL].max() == 2            # ... up to the lowered ceiling (100 mg)
    assert out[K.O_N_RED] == 0                        # no dose was ever reduced


def test_preventive_reduction_while_escalating_keeps_the_dose():
    u = draws(rise=[(64, 66)], drop=[(67, 69)])       # short grade-2 episode on day 16 at 100 mg (ceiling 150)
    out, trace = run(policy(start=1, target=3, esc=14, n_pre=1), typical_patient(), u)
    assert trace[15, K.TR_LEVEL] == 2 and trace[20, K.TR_LEVEL] == 2
    assert trace[:, K.TR_LEVEL].max() == 2 and out[K.O_N_RED] == 0


# ------------------------------------------------------------------ preventive reduction

def test_preventive_reduction_after_a_label_reduction_never_goes_below_50_mg():
    u = draws(rise=[(0, 3), (80, 82)], drop=[(3, 6), (83, 85)])   # grade 3 at 100 mg -> 50 mg, then a grade-2 episode
    out, trace = run(policy(start=2, target=2, n_pre=2), typical_patient(), u)
    assert np.all(trace[2:, K.TR_LEVEL] == 1) and out[K.O_DISCONTINUED] == 0
    assert abs(out[K.O_RDI] - 0.335) < 0.002


def test_preventive_reduction_at_full_dose_counts_one_reduction():
    u = draws(rise=[(0, 2)], drop=[(3, 5)])
    out, trace = run(policy(n_pre=1), typical_patient(), u)
    assert out[K.O_N_RED] == 1 and trace[10, K.TR_LEVEL] == 2


def test_preventive_reduction_resets_the_grade2_recurrence_count():
    u = draws(rise=[(0, 2), (120, 122)], drop=[(10, 12), (130, 132)])   # grade 2 > 24 h on day 0 and day 30
    out, trace = run(policy(n_pre=1), typical_patient(), u)
    assert np.all(trace[[2, 20, 32, 40, 100], K.TR_LEVEL] == 2)    # new dose: the second hold is not a recurrence
    assert out[K.O_N_RED] == 1 and out[K.O_N_RED_DIAR] == 0


def test_preventive_reduction_only_within_8_weeks():
    early = draws(rise=[(200, 202)], drop=[(203, 205)])          # episode on day 50
    late = draws(rise=[(240, 242)], drop=[(243, 245)])           # episode on day 60
    a, ta = run(policy(n_pre=1), typical_patient(), early)
    b, tb = run(policy(n_pre=1), typical_patient(), late)
    assert ta[70, K.TR_LEVEL] == 2 and a[K.O_N_RED] == 1
    assert tb[70, K.TR_LEVEL] == 3 and b[K.O_N_RED] == 0


def test_diarrhoea_days_window_ends_on_day_182():
    counted = []
    for start in (181, 182):
        u = np.full((1, 200 * 4), STAY, dtype=np.float32)
        u[0, start * 4:start * 4 + 2] = RISE
        u[0, start * 4 + 8:start * 4 + 10] = DROP
        out, _ = run(policy(), typical_patient(), u, n_days=200)
        counted.append(out[K.O_DIAR_DAYS_6M])
    assert counted[0] > 0 and counted[1] == 0
