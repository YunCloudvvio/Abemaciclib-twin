"""Tests of the MOSI adapter (twin/si_runner.py): constraint handling and output de-duplication."""
import os
import sys

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

si = pytest.importorskip("twin.si_runner")


def dominates(a, b):
    return np.all(a <= b) and np.any(a < b)


def test_feasible_objectives_are_unchanged():
    F = np.array([-16.0, 0.2, 9.0])
    assert np.array_equal(si.constrained_objectives(F, np.array([-0.1, 0.0, -0.01])), F)


def test_every_feasible_dominates_every_infeasible_even_for_tiny_violations():
    rng = np.random.default_rng(0)
    for _ in range(2000):
        Ff = np.array([-rng.uniform(0, 24), rng.uniform(0, 1), rng.uniform(0, 182)])
        Fi = np.array([-rng.uniform(0, 24), rng.uniform(0, 1), rng.uniform(0, 182)])
        g = np.array([rng.choice([1e-9, 2e-5, 0.3]), 0.0, -0.1])
        assert dominates(si.constrained_objectives(Ff, np.zeros(3)), si.constrained_objectives(Fi, g))


def test_infeasible_solutions_are_ordered_by_violation_only():
    a = si.constrained_objectives(np.array([-20.0, 0.0, 0.0]), np.array([0.02, 0.0, 0.0]))
    b = si.constrained_objectives(np.array([-1.0, 1.0, 100.0]), np.array([0.01, 0.0, 0.0]))
    assert dominates(b, a)                            # smaller violation wins whatever the objectives


def test_unique_rows_keeps_first_occurrence_order():
    X = np.array([[1, 2], [3, 4], [1, 2], [5, 6], [3, 4]], dtype=float)
    assert np.array_equal(si.unique_rows_first(X), np.array([[1, 2], [3, 4], [5, 6]], dtype=float))


class FakeInstance:
    """Cheap stand-in for problems.Instance (same decision space as P1)."""
    name = "P1"

    def evaluate(self, X):
        X = np.atleast_2d(X)
        F = np.stack([-X.sum(1), X[:, 3] / 2, X[:, 4] + X[:, 5]], axis=1)
        G = np.stack([X[:, 2] - 20.0, -np.ones(len(X)), X[:, 6] - 80.0], axis=1)
        return F, G


@pytest.mark.parametrize("alg", ["M212_MOGNDO", "M103_MOCGO"])
def test_checkpoints_are_complete_and_consistent(alg):
    inst = FakeInstance()
    r = si.run(alg, inst, seed=5, max_fes=2000)
    fe = r["ckpt_fe"]
    assert len(fe) == 20 and np.all(np.diff(fe) >= 0) and fe[-1] <= 2000
    for k in range(20):
        if fe[k] != r["fes"]:
            assert fe[k] >= (k + 1) * 100            # recorded at or after its threshold
    last = r["ckpt_X"][r["ckpt_id"] == 19]
    assert np.array_equal(last, r["X"])               # the last checkpoint is the final set
    F, G = inst.evaluate(r["ckpt_X"])
    assert np.array_equal(F, r["ckpt_F"]) and np.array_equal(G, r["ckpt_G"])
    for k in range(20):                               # no duplicates inside a checkpoint
        Xk = r["ckpt_X"][r["ckpt_id"] == k]
        assert len(np.unique(Xk, axis=0)) == len(Xk)
    assert r["missing"] == 0


def test_deb_transform_fixed_values():
    F = np.array([-10.0, 0.2, 5.0])
    assert np.allclose(si.constrained_objectives(F, np.array([0.1, 0.0, -1.0])), [0.1, 1.1, 182.1])
    assert np.array_equal(si.constrained_objectives(F, np.array([0.0, -0.2, -1.0])), F)


def test_octave_and_python_deb_transforms_agree():
    import subprocess
    import shutil
    octave = shutil.which(os.environ.get("OCTAVE_CLI", "octave-cli"))
    if octave is None:
        pytest.skip("octave not available")
    rng = np.random.default_rng(1)
    F = np.column_stack([-rng.uniform(0, 24, 50), rng.uniform(0, 1, 50), rng.uniform(0, 182, 50)])
    G = rng.normal(0, 0.05, (50, 3))
    G[:10] = -np.abs(G[:10])                         # some feasible rows
    script = (f"addpath('{os.path.join(ROOT, 'platemo')}'); setenv('TWIN_DEB','1'); "
              f"F=dlmread('{{f}}'); G=dlmread('{{g}}'); [a,b]=twin_constraints(F,G); "
              f"A=zeros(size(F)); B=zeros(size(G)); for i=1:rows(F), [A(i,:),B(i,:)]=twin_constraints(F(i,:),G(i,:)); end; "
              f"dlmwrite('{{o}}', [a b A B], 'precision', '%.17g');")
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        fF, fG, fO = (os.path.join(d, n) for n in ("F.txt", "G.txt", "O.txt"))
        np.savetxt(fF, F, delimiter=",", fmt="%.17g")
        np.savetxt(fG, G, delimiter=",", fmt="%.17g")
        env = dict(os.environ)
        r = subprocess.run([octave, "--no-gui", "--quiet", "--eval", script.format(f=fF, g=fG, o=fO)],
                           env=env, capture_output=True, text=True, timeout=60)
        assert r.returncode == 0, r.stderr
        out = np.loadtxt(fO, delimiter=",")
    expected = np.array([si.constrained_objectives(f, g) for f, g in zip(F, G)])
    assert np.allclose(out[:, :3], expected, rtol=0, atol=1e-12)        # whole matrix at once
    assert np.allclose(out[:, 6:9], expected, rtol=0, atol=1e-12)       # one row at a time (MOEA/D-DE)
    assert np.all(out[:, 3:6] == 0) and np.all(out[:, 9:12] == 0)
