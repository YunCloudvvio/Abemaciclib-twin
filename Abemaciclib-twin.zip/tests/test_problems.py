"""Tests of the optimisation problem instances (twin/problems.py) on the calibrated twin.

Needs calibration/ensemble_time.json and calibration/stage3_time.json (skipped otherwise).
"""
import os
import sys

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from twin import kernel as K  # noqa: E402
from twin import problems  # noqa: E402

ENS = os.path.join(ROOT, "calibration", "ensemble_time.json")
S3 = os.path.join(ROOT, "calibration", "stage3_time.json")
pytestmark = pytest.mark.skipif(not (os.path.exists(ENS) and os.path.exists(S3)), reason="no calibration")

STANDARD = [3, 3, 14, 1.0, 0, 0, 28, 0]
LOW_START = [1, 3, 14, 1.0, 0, 0, 28, 0]


def make(name, seed=1):
    return problems.Instance(ENS, S3, seed, n_per_member=5, name=name)


def test_decode_matches_the_standard_policy():
    assert np.array_equal(problems.decode(STANDARD), K.standard_policy())


def test_decode_clips_and_rounds():
    theta = problems.decode([9, 0, 7.4, 5.0, -3, 2.6, 100, 1.2])
    assert theta[K.T_START_LEVEL] == 3 and theta[K.T_TARGET_LEVEL] == 2 and theta[K.T_ESC_DAYS] == 7
    assert theta[K.T_ANC_MIN] == 2.0 and theta[K.T_N_PRE] == 3 and theta[K.T_RE_DAYS] == 84


def test_standard_policy_is_feasible_with_zero_paired_constraints():
    inst = make("P1")
    F, G = inst.evaluate(STANDARD)
    assert G[0, 1] == 0.0 and G[0, 2] == 0.0          # paired with itself
    assert G[0, 0] < 0.0                              # median RDI above 0.6
    assert -F[0, 0] > 10.0 and 0.0 <= F[0, 1] <= 1.0 and F[0, 2] >= 0.0


def test_instances_are_deterministic_and_seed_dependent():
    a, b, c = make("P1", 1), make("P1", 1), make("P1", 2)
    X = np.array([STANDARD, LOW_START], dtype=float)
    Fa, Ga = a.evaluate(X)
    Fb, Gb = b.evaluate(X)
    Fc, _ = c.evaluate(X)
    assert np.array_equal(Fa, Fb) and np.array_equal(Ga, Gb)
    assert not np.array_equal(Fa, Fc)


def test_p4_cvar_is_below_the_mean_and_p2_is_second_line():
    F1, _ = make("P1").evaluate(STANDARD)
    F4, _ = make("P4").evaluate(STANDARD)
    F2, _ = make("P2").evaluate(STANDARD)
    assert F4[0, 0] > F1[0, 0]                        # -CVaR > -RMST: the worst 20% do worse
    assert F2[0, 0] > F1[0, 0]                        # second line: shorter RMST than first line
    assert F4[0, 1] == F1[0, 1] and F4[0, 2] == F1[0, 2]


def test_low_start_lowers_toxicity_in_p1():
    F, _ = make("P1").evaluate(np.array([STANDARD, LOW_START], dtype=float))
    assert F[1, 2] <= F[0, 2]                         # fewer diarrhoea days when starting at 50 mg


def test_p3_full_schedule_equals_the_standard_policy_in_p1():
    F1, G1 = make("P1").evaluate(STANDARD)
    F3, G3 = make("P3").evaluate(np.full(24, 3.0))
    assert np.array_equal(F1, F3) and np.array_equal(G1, G3)


def test_p3_holidays_lower_dose_intensity():
    inst = make("P3")
    x = np.full(24, 3.0)
    x[::2] = 0                                        # every other week off
    F, G = inst.evaluate(np.array([np.full(24, 3.0), x]))
    assert G[1, 0] > G[0, 0]                          # lower median RDI -> larger RDI constraint value
    assert F[1, 2] < F[0, 2]                          # fewer diarrhoea days
